<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;

class AddressMappingInfo {
	
	static $_TSPEC;
	public $outerAreaId = null;
	public $outerAddrName = null;
	public $level = null;
	public $outerParentName = null;
	public $topOuterParentName = null;
	public $vipAddressCode = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'outerAreaId'
			),
			2 => array(
			'var' => 'outerAddrName'
			),
			3 => array(
			'var' => 'level'
			),
			4 => array(
			'var' => 'outerParentName'
			),
			5 => array(
			'var' => 'topOuterParentName'
			),
			6 => array(
			'var' => 'vipAddressCode'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['outerAreaId'])){
				
				$this->outerAreaId = $vals['outerAreaId'];
			}
			
			
			if (isset($vals['outerAddrName'])){
				
				$this->outerAddrName = $vals['outerAddrName'];
			}
			
			
			if (isset($vals['level'])){
				
				$this->level = $vals['level'];
			}
			
			
			if (isset($vals['outerParentName'])){
				
				$this->outerParentName = $vals['outerParentName'];
			}
			
			
			if (isset($vals['topOuterParentName'])){
				
				$this->topOuterParentName = $vals['topOuterParentName'];
			}
			
			
			if (isset($vals['vipAddressCode'])){
				
				$this->vipAddressCode = $vals['vipAddressCode'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'AddressMappingInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("outerAreaId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outerAreaId);
				
			}
			
			
			
			
			if ("outerAddrName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outerAddrName);
				
			}
			
			
			
			
			if ("level" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->level); 
				
			}
			
			
			
			
			if ("outerParentName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outerParentName);
				
			}
			
			
			
			
			if ("topOuterParentName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->topOuterParentName);
				
			}
			
			
			
			
			if ("vipAddressCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipAddressCode);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->outerAreaId !== null) {
			
			$xfer += $output->writeFieldBegin('outerAreaId');
			$xfer += $output->writeString($this->outerAreaId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->outerAddrName !== null) {
			
			$xfer += $output->writeFieldBegin('outerAddrName');
			$xfer += $output->writeString($this->outerAddrName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->level !== null) {
			
			$xfer += $output->writeFieldBegin('level');
			$xfer += $output->writeI32($this->level);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->outerParentName !== null) {
			
			$xfer += $output->writeFieldBegin('outerParentName');
			$xfer += $output->writeString($this->outerParentName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->topOuterParentName !== null) {
			
			$xfer += $output->writeFieldBegin('topOuterParentName');
			$xfer += $output->writeString($this->topOuterParentName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->vipAddressCode !== null) {
			
			$xfer += $output->writeFieldBegin('vipAddressCode');
			$xfer += $output->writeString($this->vipAddressCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>