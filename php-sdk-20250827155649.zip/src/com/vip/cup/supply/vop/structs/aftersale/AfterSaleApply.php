<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class AfterSaleApply {
	
	static $_TSPEC;
	public $afterSaleType = null;
	public $extApplyId = null;
	public $orderSn = null;
	public $extOrderSn = null;
	public $addTime = null;
	public $reasonDesc = null;
	public $adminRemark = null;
	public $returnRefundStatus = null;
	public $afterSaleStatus = null;
	public $afterSaleStatusUpdTm = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'afterSaleType'
			),
			2 => array(
			'var' => 'extApplyId'
			),
			3 => array(
			'var' => 'orderSn'
			),
			4 => array(
			'var' => 'extOrderSn'
			),
			6 => array(
			'var' => 'addTime'
			),
			7 => array(
			'var' => 'reasonDesc'
			),
			8 => array(
			'var' => 'adminRemark'
			),
			9 => array(
			'var' => 'returnRefundStatus'
			),
			10 => array(
			'var' => 'afterSaleStatus'
			),
			11 => array(
			'var' => 'afterSaleStatusUpdTm'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['afterSaleType'])){
				
				$this->afterSaleType = $vals['afterSaleType'];
			}
			
			
			if (isset($vals['extApplyId'])){
				
				$this->extApplyId = $vals['extApplyId'];
			}
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['addTime'])){
				
				$this->addTime = $vals['addTime'];
			}
			
			
			if (isset($vals['reasonDesc'])){
				
				$this->reasonDesc = $vals['reasonDesc'];
			}
			
			
			if (isset($vals['adminRemark'])){
				
				$this->adminRemark = $vals['adminRemark'];
			}
			
			
			if (isset($vals['returnRefundStatus'])){
				
				$this->returnRefundStatus = $vals['returnRefundStatus'];
			}
			
			
			if (isset($vals['afterSaleStatus'])){
				
				$this->afterSaleStatus = $vals['afterSaleStatus'];
			}
			
			
			if (isset($vals['afterSaleStatusUpdTm'])){
				
				$this->afterSaleStatusUpdTm = $vals['afterSaleStatusUpdTm'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'AfterSaleApply';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("afterSaleType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterSaleType); 
				
			}
			
			
			
			
			if ("extApplyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extApplyId);
				
			}
			
			
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("addTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->addTime); 
				
			}
			
			
			
			
			if ("reasonDesc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->reasonDesc);
				
			}
			
			
			
			
			if ("adminRemark" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adminRemark);
				
			}
			
			
			
			
			if ("returnRefundStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->returnRefundStatus); 
				
			}
			
			
			
			
			if ("afterSaleStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterSaleStatus); 
				
			}
			
			
			
			
			if ("afterSaleStatusUpdTm" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->afterSaleStatusUpdTm); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->afterSaleType !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleType');
			$xfer += $output->writeI32($this->afterSaleType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extApplyId !== null) {
			
			$xfer += $output->writeFieldBegin('extApplyId');
			$xfer += $output->writeString($this->extApplyId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('extOrderSn');
			$xfer += $output->writeString($this->extOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->addTime !== null) {
			
			$xfer += $output->writeFieldBegin('addTime');
			$xfer += $output->writeI64($this->addTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->reasonDesc !== null) {
			
			$xfer += $output->writeFieldBegin('reasonDesc');
			$xfer += $output->writeString($this->reasonDesc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->adminRemark !== null) {
			
			$xfer += $output->writeFieldBegin('adminRemark');
			$xfer += $output->writeString($this->adminRemark);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->returnRefundStatus !== null) {
			
			$xfer += $output->writeFieldBegin('returnRefundStatus');
			$xfer += $output->writeI32($this->returnRefundStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleStatus !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleStatus');
			$xfer += $output->writeI32($this->afterSaleStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleStatusUpdTm !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleStatusUpdTm');
			$xfer += $output->writeI64($this->afterSaleStatusUpdTm);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>