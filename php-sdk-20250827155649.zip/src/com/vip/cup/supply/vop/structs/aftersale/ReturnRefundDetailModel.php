<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class ReturnRefundDetailModel {
	
	static $_TSPEC;
	public $refundMoney = null;
	public $refundTime = null;
	public $payType = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'refundMoney'
			),
			2 => array(
			'var' => 'refundTime'
			),
			3 => array(
			'var' => 'payType'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['refundMoney'])){
				
				$this->refundMoney = $vals['refundMoney'];
			}
			
			
			if (isset($vals['refundTime'])){
				
				$this->refundTime = $vals['refundTime'];
			}
			
			
			if (isset($vals['payType'])){
				
				$this->payType = $vals['payType'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ReturnRefundDetailModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("refundMoney" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundMoney);
				
			}
			
			
			
			
			if ("refundTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->refundTime); 
				
			}
			
			
			
			
			if ("payType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->payType); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->refundMoney !== null) {
			
			$xfer += $output->writeFieldBegin('refundMoney');
			$xfer += $output->writeString($this->refundMoney);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundTime !== null) {
			
			$xfer += $output->writeFieldBegin('refundTime');
			$xfer += $output->writeI64($this->refundTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->payType !== null) {
			
			$xfer += $output->writeFieldBegin('payType');
			$xfer += $output->writeI32($this->payType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>