<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class CupSupplyNotifyCancelOrderRefundRequest {
	
	static $_TSPEC;
	public $extOrderSn = null;
	public $extApplyId = null;
	public $extraData = null;
	public $refundAmount = null;
	public $refundFinishDate = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'extOrderSn'
			),
			2 => array(
			'var' => 'extApplyId'
			),
			3 => array(
			'var' => 'extraData'
			),
			4 => array(
			'var' => 'refundAmount'
			),
			5 => array(
			'var' => 'refundFinishDate'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['extApplyId'])){
				
				$this->extApplyId = $vals['extApplyId'];
			}
			
			
			if (isset($vals['extraData'])){
				
				$this->extraData = $vals['extraData'];
			}
			
			
			if (isset($vals['refundAmount'])){
				
				$this->refundAmount = $vals['refundAmount'];
			}
			
			
			if (isset($vals['refundFinishDate'])){
				
				$this->refundFinishDate = $vals['refundFinishDate'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyNotifyCancelOrderRefundRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("extApplyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extApplyId);
				
			}
			
			
			
			
			if ("extraData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extraData);
				
			}
			
			
			
			
			if ("refundAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundAmount);
				
			}
			
			
			
			
			if ("refundFinishDate" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->refundFinishDate); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('extOrderSn');
		$xfer += $output->writeString($this->extOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('extApplyId');
		$xfer += $output->writeString($this->extApplyId);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->extraData !== null) {
			
			$xfer += $output->writeFieldBegin('extraData');
			$xfer += $output->writeString($this->extraData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundAmount !== null) {
			
			$xfer += $output->writeFieldBegin('refundAmount');
			$xfer += $output->writeString($this->refundAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('refundFinishDate');
		$xfer += $output->writeI64($this->refundFinishDate);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>