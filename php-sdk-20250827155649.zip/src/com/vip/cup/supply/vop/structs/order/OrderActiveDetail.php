<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class OrderActiveDetail {
	
	static $_TSPEC;
	public $prodSkuId = null;
	public $extActNo = null;
	public $skuDiscountMoney = null;
	public $skuDiscountMoneySubtotal = null;
	public $extraData = null;
	public $extActType = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'prodSkuId'
			),
			2 => array(
			'var' => 'extActNo'
			),
			3 => array(
			'var' => 'skuDiscountMoney'
			),
			4 => array(
			'var' => 'skuDiscountMoneySubtotal'
			),
			5 => array(
			'var' => 'extraData'
			),
			6 => array(
			'var' => 'extActType'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['prodSkuId'])){
				
				$this->prodSkuId = $vals['prodSkuId'];
			}
			
			
			if (isset($vals['extActNo'])){
				
				$this->extActNo = $vals['extActNo'];
			}
			
			
			if (isset($vals['skuDiscountMoney'])){
				
				$this->skuDiscountMoney = $vals['skuDiscountMoney'];
			}
			
			
			if (isset($vals['skuDiscountMoneySubtotal'])){
				
				$this->skuDiscountMoneySubtotal = $vals['skuDiscountMoneySubtotal'];
			}
			
			
			if (isset($vals['extraData'])){
				
				$this->extraData = $vals['extraData'];
			}
			
			
			if (isset($vals['extActType'])){
				
				$this->extActType = $vals['extActType'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'OrderActiveDetail';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("prodSkuId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->prodSkuId);
				
			}
			
			
			
			
			if ("extActNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extActNo);
				
			}
			
			
			
			
			if ("skuDiscountMoney" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->skuDiscountMoney);
				
			}
			
			
			
			
			if ("skuDiscountMoneySubtotal" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->skuDiscountMoneySubtotal);
				
			}
			
			
			
			
			if ("extraData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extraData);
				
			}
			
			
			
			
			if ("extActType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extActType);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->prodSkuId !== null) {
			
			$xfer += $output->writeFieldBegin('prodSkuId');
			$xfer += $output->writeString($this->prodSkuId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extActNo !== null) {
			
			$xfer += $output->writeFieldBegin('extActNo');
			$xfer += $output->writeString($this->extActNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->skuDiscountMoney !== null) {
			
			$xfer += $output->writeFieldBegin('skuDiscountMoney');
			$xfer += $output->writeString($this->skuDiscountMoney);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->skuDiscountMoneySubtotal !== null) {
			
			$xfer += $output->writeFieldBegin('skuDiscountMoneySubtotal');
			$xfer += $output->writeString($this->skuDiscountMoneySubtotal);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extraData !== null) {
			
			$xfer += $output->writeFieldBegin('extraData');
			$xfer += $output->writeString($this->extraData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extActType !== null) {
			
			$xfer += $output->writeFieldBegin('extActType');
			$xfer += $output->writeString($this->extActType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>