<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class TpOrderUpdateMsgVO {
	
	static $_TSPEC;
	public $orderSn = null;
	public $scenarioCode = null;
	public $extOrderStatus = null;
	public $bizUpdateTime = null;
	public $updateTime = null;
	public $extraData = null;
	public $vipOrderSn = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderSn'
			),
			3 => array(
			'var' => 'scenarioCode'
			),
			4 => array(
			'var' => 'extOrderStatus'
			),
			5 => array(
			'var' => 'bizUpdateTime'
			),
			6 => array(
			'var' => 'updateTime'
			),
			7 => array(
			'var' => 'extraData'
			),
			9 => array(
			'var' => 'vipOrderSn'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['scenarioCode'])){
				
				$this->scenarioCode = $vals['scenarioCode'];
			}
			
			
			if (isset($vals['extOrderStatus'])){
				
				$this->extOrderStatus = $vals['extOrderStatus'];
			}
			
			
			if (isset($vals['bizUpdateTime'])){
				
				$this->bizUpdateTime = $vals['bizUpdateTime'];
			}
			
			
			if (isset($vals['updateTime'])){
				
				$this->updateTime = $vals['updateTime'];
			}
			
			
			if (isset($vals['extraData'])){
				
				$this->extraData = $vals['extraData'];
			}
			
			
			if (isset($vals['vipOrderSn'])){
				
				$this->vipOrderSn = $vals['vipOrderSn'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'TpOrderUpdateMsgVO';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("scenarioCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->scenarioCode);
				
			}
			
			
			
			
			if ("extOrderStatus" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderStatus);
				
			}
			
			
			
			
			if ("bizUpdateTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->bizUpdateTime);
				
			}
			
			
			
			
			if ("updateTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->updateTime);
				
			}
			
			
			
			
			if ("extraData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extraData);
				
			}
			
			
			
			
			if ("vipOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipOrderSn);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->scenarioCode !== null) {
			
			$xfer += $output->writeFieldBegin('scenarioCode');
			$xfer += $output->writeString($this->scenarioCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extOrderStatus !== null) {
			
			$xfer += $output->writeFieldBegin('extOrderStatus');
			$xfer += $output->writeString($this->extOrderStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->bizUpdateTime !== null) {
			
			$xfer += $output->writeFieldBegin('bizUpdateTime');
			$xfer += $output->writeString($this->bizUpdateTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->updateTime !== null) {
			
			$xfer += $output->writeFieldBegin('updateTime');
			$xfer += $output->writeString($this->updateTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extraData !== null) {
			
			$xfer += $output->writeFieldBegin('extraData');
			$xfer += $output->writeString($this->extraData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->vipOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('vipOrderSn');
			$xfer += $output->writeString($this->vipOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>