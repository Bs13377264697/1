<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class CupSupplyOrderGoods {
	
	static $_TSPEC;
	public $vipSkuId = null;
	public $amount = null;
	public $extSkuId = null;
	public $distributionPrice = null;
	public $vipSpuId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'vipSkuId'
			),
			2 => array(
			'var' => 'amount'
			),
			3 => array(
			'var' => 'extSkuId'
			),
			4 => array(
			'var' => 'distributionPrice'
			),
			6 => array(
			'var' => 'vipSpuId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['vipSkuId'])){
				
				$this->vipSkuId = $vals['vipSkuId'];
			}
			
			
			if (isset($vals['amount'])){
				
				$this->amount = $vals['amount'];
			}
			
			
			if (isset($vals['extSkuId'])){
				
				$this->extSkuId = $vals['extSkuId'];
			}
			
			
			if (isset($vals['distributionPrice'])){
				
				$this->distributionPrice = $vals['distributionPrice'];
			}
			
			
			if (isset($vals['vipSpuId'])){
				
				$this->vipSpuId = $vals['vipSpuId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyOrderGoods';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("vipSkuId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipSkuId);
				
			}
			
			
			
			
			if ("amount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->amount); 
				
			}
			
			
			
			
			if ("extSkuId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extSkuId);
				
			}
			
			
			
			
			if ("distributionPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->distributionPrice);
				
			}
			
			
			
			
			if ("vipSpuId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipSpuId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('vipSkuId');
		$xfer += $output->writeString($this->vipSkuId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('amount');
		$xfer += $output->writeI32($this->amount);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->extSkuId !== null) {
			
			$xfer += $output->writeFieldBegin('extSkuId');
			$xfer += $output->writeString($this->extSkuId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('distributionPrice');
		$xfer += $output->writeString($this->distributionPrice);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('vipSpuId');
		$xfer += $output->writeString($this->vipSpuId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>