<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class CupSupplyNotifyReturnRefundResultRequest {
	
	static $_TSPEC;
	public $callScene = null;
	public $openId = null;
	public $vipOrderSn = null;
	public $refundAmount = null;
	public $refundFinishDate = null;
	public $extApplyId = null;
	public $extOrderSn = null;
	public $returnRefundDetailModels = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			100 => array(
			'var' => 'callScene'
			),
			101 => array(
			'var' => 'openId'
			),
			1 => array(
			'var' => 'vipOrderSn'
			),
			2 => array(
			'var' => 'refundAmount'
			),
			3 => array(
			'var' => 'refundFinishDate'
			),
			5 => array(
			'var' => 'extApplyId'
			),
			6 => array(
			'var' => 'extOrderSn'
			),
			7 => array(
			'var' => 'returnRefundDetailModels'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['callScene'])){
				
				$this->callScene = $vals['callScene'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['vipOrderSn'])){
				
				$this->vipOrderSn = $vals['vipOrderSn'];
			}
			
			
			if (isset($vals['refundAmount'])){
				
				$this->refundAmount = $vals['refundAmount'];
			}
			
			
			if (isset($vals['refundFinishDate'])){
				
				$this->refundFinishDate = $vals['refundFinishDate'];
			}
			
			
			if (isset($vals['extApplyId'])){
				
				$this->extApplyId = $vals['extApplyId'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['returnRefundDetailModels'])){
				
				$this->returnRefundDetailModels = $vals['returnRefundDetailModels'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyNotifyReturnRefundResultRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("callScene" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->callScene); 
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("vipOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipOrderSn);
				
			}
			
			
			
			
			if ("refundAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundAmount);
				
			}
			
			
			
			
			if ("refundFinishDate" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->refundFinishDate); 
				
			}
			
			
			
			
			if ("extApplyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extApplyId);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("returnRefundDetailModels" == $schemeField){
				
				$needSkip = false;
				
				$this->returnRefundDetailModels = array();
				$_size1 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem1 = null;
						
						$elem1 = new \com\vip\cup\supply\vop\structs\aftersale\ReturnRefundDetailModel();
						$elem1->read($input);
						
						$this->returnRefundDetailModels[$_size1++] = $elem1;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->callScene !== null) {
			
			$xfer += $output->writeFieldBegin('callScene');
			$xfer += $output->writeI32($this->callScene);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('vipOrderSn');
		$xfer += $output->writeString($this->vipOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('refundAmount');
		$xfer += $output->writeString($this->refundAmount);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('refundFinishDate');
		$xfer += $output->writeI64($this->refundFinishDate);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('extApplyId');
		$xfer += $output->writeString($this->extApplyId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('extOrderSn');
		$xfer += $output->writeString($this->extOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->returnRefundDetailModels !== null) {
			
			$xfer += $output->writeFieldBegin('returnRefundDetailModels');
			
			if (!is_array($this->returnRefundDetailModels)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->returnRefundDetailModels as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>