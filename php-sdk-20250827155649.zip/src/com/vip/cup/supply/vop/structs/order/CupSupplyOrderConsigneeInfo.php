<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class CupSupplyOrderConsigneeInfo {
	
	static $_TSPEC;
	public $addrType = null;
	public $consignee = null;
	public $areaId = null;
	public $postCode = null;
	public $mobile = null;
	public $tel = null;
	public $address = null;
	public $thirdAreaId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'addrType'
			),
			2 => array(
			'var' => 'consignee'
			),
			3 => array(
			'var' => 'areaId'
			),
			4 => array(
			'var' => 'postCode'
			),
			5 => array(
			'var' => 'mobile'
			),
			6 => array(
			'var' => 'tel'
			),
			7 => array(
			'var' => 'address'
			),
			8 => array(
			'var' => 'thirdAreaId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['addrType'])){
				
				$this->addrType = $vals['addrType'];
			}
			
			
			if (isset($vals['consignee'])){
				
				$this->consignee = $vals['consignee'];
			}
			
			
			if (isset($vals['areaId'])){
				
				$this->areaId = $vals['areaId'];
			}
			
			
			if (isset($vals['postCode'])){
				
				$this->postCode = $vals['postCode'];
			}
			
			
			if (isset($vals['mobile'])){
				
				$this->mobile = $vals['mobile'];
			}
			
			
			if (isset($vals['tel'])){
				
				$this->tel = $vals['tel'];
			}
			
			
			if (isset($vals['address'])){
				
				$this->address = $vals['address'];
			}
			
			
			if (isset($vals['thirdAreaId'])){
				
				$this->thirdAreaId = $vals['thirdAreaId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyOrderConsigneeInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("addrType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->addrType);
				
			}
			
			
			
			
			if ("consignee" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->consignee);
				
			}
			
			
			
			
			if ("areaId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->areaId);
				
			}
			
			
			
			
			if ("postCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->postCode);
				
			}
			
			
			
			
			if ("mobile" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mobile);
				
			}
			
			
			
			
			if ("tel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->tel);
				
			}
			
			
			
			
			if ("address" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->address);
				
			}
			
			
			
			
			if ("thirdAreaId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->thirdAreaId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->addrType !== null) {
			
			$xfer += $output->writeFieldBegin('addrType');
			$xfer += $output->writeString($this->addrType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('consignee');
		$xfer += $output->writeString($this->consignee);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->areaId !== null) {
			
			$xfer += $output->writeFieldBegin('areaId');
			$xfer += $output->writeString($this->areaId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->postCode !== null) {
			
			$xfer += $output->writeFieldBegin('postCode');
			$xfer += $output->writeString($this->postCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('mobile');
		$xfer += $output->writeString($this->mobile);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->tel !== null) {
			
			$xfer += $output->writeFieldBegin('tel');
			$xfer += $output->writeString($this->tel);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('address');
		$xfer += $output->writeString($this->address);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->thirdAreaId !== null) {
			
			$xfer += $output->writeFieldBegin('thirdAreaId');
			$xfer += $output->writeString($this->thirdAreaId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>