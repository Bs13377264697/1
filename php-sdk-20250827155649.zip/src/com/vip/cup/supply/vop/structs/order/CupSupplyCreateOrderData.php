<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class CupSupplyCreateOrderData {
	
	static $_TSPEC;
	public $vipOrderSn = null;
	public $validTime = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'vipOrderSn'
			),
			2 => array(
			'var' => 'validTime'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['vipOrderSn'])){
				
				$this->vipOrderSn = $vals['vipOrderSn'];
			}
			
			
			if (isset($vals['validTime'])){
				
				$this->validTime = $vals['validTime'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyCreateOrderData';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("vipOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipOrderSn);
				
			}
			
			
			
			
			if ("validTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->validTime); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->vipOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('vipOrderSn');
			$xfer += $output->writeString($this->vipOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->validTime !== null) {
			
			$xfer += $output->writeFieldBegin('validTime');
			$xfer += $output->writeI64($this->validTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>