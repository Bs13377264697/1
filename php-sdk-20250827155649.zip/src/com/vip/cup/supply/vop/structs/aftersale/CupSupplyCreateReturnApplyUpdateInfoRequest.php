<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class CupSupplyCreateReturnApplyUpdateInfoRequest {
	
	static $_TSPEC;
	public $callScene = null;
	public $openId = null;
	public $extApplyId = null;
	public $updateTime = null;
	public $transportNo = null;
	public $carrierName = null;
	public $extraData = null;
	public $extOrderSn = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			100 => array(
			'var' => 'callScene'
			),
			101 => array(
			'var' => 'openId'
			),
			1 => array(
			'var' => 'extApplyId'
			),
			2 => array(
			'var' => 'updateTime'
			),
			3 => array(
			'var' => 'transportNo'
			),
			4 => array(
			'var' => 'carrierName'
			),
			5 => array(
			'var' => 'extraData'
			),
			6 => array(
			'var' => 'extOrderSn'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['callScene'])){
				
				$this->callScene = $vals['callScene'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['extApplyId'])){
				
				$this->extApplyId = $vals['extApplyId'];
			}
			
			
			if (isset($vals['updateTime'])){
				
				$this->updateTime = $vals['updateTime'];
			}
			
			
			if (isset($vals['transportNo'])){
				
				$this->transportNo = $vals['transportNo'];
			}
			
			
			if (isset($vals['carrierName'])){
				
				$this->carrierName = $vals['carrierName'];
			}
			
			
			if (isset($vals['extraData'])){
				
				$this->extraData = $vals['extraData'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyCreateReturnApplyUpdateInfoRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("callScene" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->callScene); 
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("extApplyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extApplyId);
				
			}
			
			
			
			
			if ("updateTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->updateTime); 
				
			}
			
			
			
			
			if ("transportNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->transportNo);
				
			}
			
			
			
			
			if ("carrierName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->carrierName);
				
			}
			
			
			
			
			if ("extraData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extraData);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->callScene !== null) {
			
			$xfer += $output->writeFieldBegin('callScene');
			$xfer += $output->writeI32($this->callScene);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('extApplyId');
		$xfer += $output->writeString($this->extApplyId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('updateTime');
		$xfer += $output->writeI64($this->updateTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('transportNo');
		$xfer += $output->writeString($this->transportNo);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('carrierName');
		$xfer += $output->writeString($this->carrierName);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->extraData !== null) {
			
			$xfer += $output->writeFieldBegin('extraData');
			$xfer += $output->writeString($this->extraData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('extOrderSn');
		$xfer += $output->writeString($this->extOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>