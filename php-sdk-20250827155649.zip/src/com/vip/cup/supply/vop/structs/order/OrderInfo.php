<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class OrderInfo {
	
	static $_TSPEC;
	public $orderSn = null;
	public $extOrderSn = null;
	public $addTime = null;
	public $extAddTime = null;
	public $adminRemark = null;
	public $orderStatus = null;
	public $transportNo = null;
	public $parentOrderSn = null;
	public $splitFlag = null;
	public $signTime = null;
	public $payTime = null;
	public $invoiceStatus = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderSn'
			),
			2 => array(
			'var' => 'extOrderSn'
			),
			4 => array(
			'var' => 'addTime'
			),
			5 => array(
			'var' => 'extAddTime'
			),
			6 => array(
			'var' => 'adminRemark'
			),
			7 => array(
			'var' => 'orderStatus'
			),
			8 => array(
			'var' => 'transportNo'
			),
			9 => array(
			'var' => 'parentOrderSn'
			),
			10 => array(
			'var' => 'splitFlag'
			),
			11 => array(
			'var' => 'signTime'
			),
			12 => array(
			'var' => 'payTime'
			),
			13 => array(
			'var' => 'invoiceStatus'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['addTime'])){
				
				$this->addTime = $vals['addTime'];
			}
			
			
			if (isset($vals['extAddTime'])){
				
				$this->extAddTime = $vals['extAddTime'];
			}
			
			
			if (isset($vals['adminRemark'])){
				
				$this->adminRemark = $vals['adminRemark'];
			}
			
			
			if (isset($vals['orderStatus'])){
				
				$this->orderStatus = $vals['orderStatus'];
			}
			
			
			if (isset($vals['transportNo'])){
				
				$this->transportNo = $vals['transportNo'];
			}
			
			
			if (isset($vals['parentOrderSn'])){
				
				$this->parentOrderSn = $vals['parentOrderSn'];
			}
			
			
			if (isset($vals['splitFlag'])){
				
				$this->splitFlag = $vals['splitFlag'];
			}
			
			
			if (isset($vals['signTime'])){
				
				$this->signTime = $vals['signTime'];
			}
			
			
			if (isset($vals['payTime'])){
				
				$this->payTime = $vals['payTime'];
			}
			
			
			if (isset($vals['invoiceStatus'])){
				
				$this->invoiceStatus = $vals['invoiceStatus'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'OrderInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("addTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->addTime); 
				
			}
			
			
			
			
			if ("extAddTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->extAddTime); 
				
			}
			
			
			
			
			if ("adminRemark" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adminRemark);
				
			}
			
			
			
			
			if ("orderStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderStatus); 
				
			}
			
			
			
			
			if ("transportNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->transportNo);
				
			}
			
			
			
			
			if ("parentOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->parentOrderSn);
				
			}
			
			
			
			
			if ("splitFlag" == $schemeField){
				
				$needSkip = false;
				$input->readByte($this->splitFlag); 
				
			}
			
			
			
			
			if ("signTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->signTime); 
				
			}
			
			
			
			
			if ("payTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->payTime); 
				
			}
			
			
			
			
			if ("invoiceStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->invoiceStatus); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('extOrderSn');
			$xfer += $output->writeString($this->extOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->addTime !== null) {
			
			$xfer += $output->writeFieldBegin('addTime');
			$xfer += $output->writeI64($this->addTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extAddTime !== null) {
			
			$xfer += $output->writeFieldBegin('extAddTime');
			$xfer += $output->writeI64($this->extAddTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->adminRemark !== null) {
			
			$xfer += $output->writeFieldBegin('adminRemark');
			$xfer += $output->writeString($this->adminRemark);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderStatus !== null) {
			
			$xfer += $output->writeFieldBegin('orderStatus');
			$xfer += $output->writeI32($this->orderStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->transportNo !== null) {
			
			$xfer += $output->writeFieldBegin('transportNo');
			$xfer += $output->writeString($this->transportNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->parentOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('parentOrderSn');
			$xfer += $output->writeString($this->parentOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->splitFlag !== null) {
			
			$xfer += $output->writeFieldBegin('splitFlag');
			$xfer += $output->writeByte($this->splitFlag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->signTime !== null) {
			
			$xfer += $output->writeFieldBegin('signTime');
			$xfer += $output->writeI64($this->signTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->payTime !== null) {
			
			$xfer += $output->writeFieldBegin('payTime');
			$xfer += $output->writeI64($this->payTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->invoiceStatus !== null) {
			
			$xfer += $output->writeFieldBegin('invoiceStatus');
			$xfer += $output->writeI32($this->invoiceStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>