<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class CupSupplyGetAfterSaleInfoListRequest {
	
	static $_TSPEC;
	public $page = null;
	public $pageSize = null;
	public $afterSaleStatus = null;
	public $afterSaleType = null;
	public $orderSnSet = null;
	public $callScene = null;
	public $openId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'page'
			),
			2 => array(
			'var' => 'pageSize'
			),
			4 => array(
			'var' => 'afterSaleStatus'
			),
			5 => array(
			'var' => 'afterSaleType'
			),
			6 => array(
			'var' => 'orderSnSet'
			),
			7 => array(
			'var' => 'callScene'
			),
			8 => array(
			'var' => 'openId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['page'])){
				
				$this->page = $vals['page'];
			}
			
			
			if (isset($vals['pageSize'])){
				
				$this->pageSize = $vals['pageSize'];
			}
			
			
			if (isset($vals['afterSaleStatus'])){
				
				$this->afterSaleStatus = $vals['afterSaleStatus'];
			}
			
			
			if (isset($vals['afterSaleType'])){
				
				$this->afterSaleType = $vals['afterSaleType'];
			}
			
			
			if (isset($vals['orderSnSet'])){
				
				$this->orderSnSet = $vals['orderSnSet'];
			}
			
			
			if (isset($vals['callScene'])){
				
				$this->callScene = $vals['callScene'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyGetAfterSaleInfoListRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("page" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->page); 
				
			}
			
			
			
			
			if ("pageSize" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->pageSize); 
				
			}
			
			
			
			
			if ("afterSaleStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterSaleStatus); 
				
			}
			
			
			
			
			if ("afterSaleType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterSaleType); 
				
			}
			
			
			
			
			if ("orderSnSet" == $schemeField){
				
				$needSkip = false;
				
				$this->orderSnSet = array();
				$_size0 = 0;
				$input->readSetBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->orderSnSet[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readSetEnd();
				
			}
			
			
			
			
			if ("callScene" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->callScene); 
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->page !== null) {
			
			$xfer += $output->writeFieldBegin('page');
			$xfer += $output->writeI32($this->page);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->pageSize !== null) {
			
			$xfer += $output->writeFieldBegin('pageSize');
			$xfer += $output->writeI32($this->pageSize);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleStatus !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleStatus');
			$xfer += $output->writeI32($this->afterSaleStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleType !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleType');
			$xfer += $output->writeI32($this->afterSaleType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('orderSnSet');
		
		if (!is_array($this->orderSnSet)){
			
			throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
		}
		
		$output->writeSetBegin();
		foreach ($this->orderSnSet as $iter0){
			
			$xfer += $output->writeString($iter0);
			
		}
		
		$output->writeSetEnd();
		
		$xfer += $output->writeFieldEnd();
		
		if($this->callScene !== null) {
			
			$xfer += $output->writeFieldBegin('callScene');
			$xfer += $output->writeI32($this->callScene);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>