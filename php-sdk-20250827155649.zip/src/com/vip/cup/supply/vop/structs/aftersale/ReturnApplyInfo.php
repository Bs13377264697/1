<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class ReturnApplyInfo {
	
	static $_TSPEC;
	public $extApplyId = null;
	public $extOrderSn = null;
	public $addTime = null;
	public $reason = null;
	public $adminRemark = null;
	public $vipOrderSn = null;
	public $returnsWay = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'extApplyId'
			),
			2 => array(
			'var' => 'extOrderSn'
			),
			4 => array(
			'var' => 'addTime'
			),
			5 => array(
			'var' => 'reason'
			),
			6 => array(
			'var' => 'adminRemark'
			),
			7 => array(
			'var' => 'vipOrderSn'
			),
			8 => array(
			'var' => 'returnsWay'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['extApplyId'])){
				
				$this->extApplyId = $vals['extApplyId'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['addTime'])){
				
				$this->addTime = $vals['addTime'];
			}
			
			
			if (isset($vals['reason'])){
				
				$this->reason = $vals['reason'];
			}
			
			
			if (isset($vals['adminRemark'])){
				
				$this->adminRemark = $vals['adminRemark'];
			}
			
			
			if (isset($vals['vipOrderSn'])){
				
				$this->vipOrderSn = $vals['vipOrderSn'];
			}
			
			
			if (isset($vals['returnsWay'])){
				
				$this->returnsWay = $vals['returnsWay'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ReturnApplyInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("extApplyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extApplyId);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("addTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->addTime); 
				
			}
			
			
			
			
			if ("reason" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->reason);
				
			}
			
			
			
			
			if ("adminRemark" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adminRemark);
				
			}
			
			
			
			
			if ("vipOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipOrderSn);
				
			}
			
			
			
			
			if ("returnsWay" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->returnsWay); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('extApplyId');
		$xfer += $output->writeString($this->extApplyId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('extOrderSn');
		$xfer += $output->writeString($this->extOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('addTime');
		$xfer += $output->writeI64($this->addTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('reason');
		$xfer += $output->writeString($this->reason);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->adminRemark !== null) {
			
			$xfer += $output->writeFieldBegin('adminRemark');
			$xfer += $output->writeString($this->adminRemark);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('vipOrderSn');
		$xfer += $output->writeString($this->vipOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('returnsWay');
		$xfer += $output->writeI32($this->returnsWay);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>