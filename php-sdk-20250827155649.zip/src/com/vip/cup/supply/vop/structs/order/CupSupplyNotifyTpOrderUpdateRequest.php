<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\order;

class CupSupplyNotifyTpOrderUpdateRequest {
	
	static $_TSPEC;
	public $callScene = null;
	public $openId = null;
	public $extOrderSn = null;
	public $scenarioCode = null;
	public $extOrderStatus = null;
	public $extraData = null;
	public $updateTime = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			100 => array(
			'var' => 'callScene'
			),
			101 => array(
			'var' => 'openId'
			),
			1 => array(
			'var' => 'extOrderSn'
			),
			3 => array(
			'var' => 'scenarioCode'
			),
			4 => array(
			'var' => 'extOrderStatus'
			),
			5 => array(
			'var' => 'extraData'
			),
			6 => array(
			'var' => 'updateTime'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['callScene'])){
				
				$this->callScene = $vals['callScene'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['extOrderSn'])){
				
				$this->extOrderSn = $vals['extOrderSn'];
			}
			
			
			if (isset($vals['scenarioCode'])){
				
				$this->scenarioCode = $vals['scenarioCode'];
			}
			
			
			if (isset($vals['extOrderStatus'])){
				
				$this->extOrderStatus = $vals['extOrderStatus'];
			}
			
			
			if (isset($vals['extraData'])){
				
				$this->extraData = $vals['extraData'];
			}
			
			
			if (isset($vals['updateTime'])){
				
				$this->updateTime = $vals['updateTime'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyNotifyTpOrderUpdateRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("callScene" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->callScene); 
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("extOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extOrderSn);
				
			}
			
			
			
			
			if ("scenarioCode" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->scenarioCode); 
				
			}
			
			
			
			
			if ("extOrderStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->extOrderStatus); 
				
			}
			
			
			
			
			if ("extraData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extraData);
				
			}
			
			
			
			
			if ("updateTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->updateTime); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->callScene !== null) {
			
			$xfer += $output->writeFieldBegin('callScene');
			$xfer += $output->writeI32($this->callScene);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('extOrderSn');
		$xfer += $output->writeString($this->extOrderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('scenarioCode');
		$xfer += $output->writeI32($this->scenarioCode);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('extOrderStatus');
		$xfer += $output->writeI32($this->extOrderStatus);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->extraData !== null) {
			
			$xfer += $output->writeFieldBegin('extraData');
			$xfer += $output->writeString($this->extraData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('updateTime');
		$xfer += $output->writeI64($this->updateTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>