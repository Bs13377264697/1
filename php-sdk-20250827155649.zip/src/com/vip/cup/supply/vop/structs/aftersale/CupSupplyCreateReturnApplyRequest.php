<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop\structs\aftersale;

class CupSupplyCreateReturnApplyRequest {
	
	static $_TSPEC;
	public $callScene = null;
	public $openId = null;
	public $info = null;
	public $returnApplyGoods = null;
	public $consignee = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			100 => array(
			'var' => 'callScene'
			),
			101 => array(
			'var' => 'openId'
			),
			1 => array(
			'var' => 'info'
			),
			2 => array(
			'var' => 'returnApplyGoods'
			),
			3 => array(
			'var' => 'consignee'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['callScene'])){
				
				$this->callScene = $vals['callScene'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['info'])){
				
				$this->info = $vals['info'];
			}
			
			
			if (isset($vals['returnApplyGoods'])){
				
				$this->returnApplyGoods = $vals['returnApplyGoods'];
			}
			
			
			if (isset($vals['consignee'])){
				
				$this->consignee = $vals['consignee'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyCreateReturnApplyRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("callScene" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->callScene); 
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("info" == $schemeField){
				
				$needSkip = false;
				
				$this->info = new \com\vip\cup\supply\vop\structs\aftersale\ReturnApplyInfo();
				$this->info->read($input);
				
			}
			
			
			
			
			if ("returnApplyGoods" == $schemeField){
				
				$needSkip = false;
				
				$this->returnApplyGoods = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cup\supply\vop\structs\aftersale\ReturnApplyGoodInfo();
						$elem0->read($input);
						
						$this->returnApplyGoods[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("consignee" == $schemeField){
				
				$needSkip = false;
				
				$this->consignee = new \com\vip\cup\supply\vop\structs\aftersale\ConsigneeInfo();
				$this->consignee->read($input);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->callScene !== null) {
			
			$xfer += $output->writeFieldBegin('callScene');
			$xfer += $output->writeI32($this->callScene);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('info');
		
		if (!is_object($this->info)) {
			
			throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
		}
		
		$xfer += $this->info->write($output);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('returnApplyGoods');
		
		if (!is_array($this->returnApplyGoods)){
			
			throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
		}
		
		$output->writeListBegin();
		foreach ($this->returnApplyGoods as $iter0){
			
			
			if (!is_object($iter0)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $iter0->write($output);
			
		}
		
		$output->writeListEnd();
		
		$xfer += $output->writeFieldEnd();
		
		if($this->consignee !== null) {
			
			$xfer += $output->writeFieldBegin('consignee');
			
			if (!is_object($this->consignee)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->consignee->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>