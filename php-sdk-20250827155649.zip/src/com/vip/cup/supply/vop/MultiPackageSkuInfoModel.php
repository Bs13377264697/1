<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;

class MultiPackageSkuInfoModel {
	
	static $_TSPEC;
	public $skuNum = null;
	public $barCode = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'skuNum'
			),
			2 => array(
			'var' => 'barCode'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['skuNum'])){
				
				$this->skuNum = $vals['skuNum'];
			}
			
			
			if (isset($vals['barCode'])){
				
				$this->barCode = $vals['barCode'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'MultiPackageSkuInfoModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("skuNum" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->skuNum); 
				
			}
			
			
			
			
			if ("barCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->barCode);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->skuNum !== null) {
			
			$xfer += $output->writeFieldBegin('skuNum');
			$xfer += $output->writeI32($this->skuNum);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->barCode !== null) {
			
			$xfer += $output->writeFieldBegin('barCode');
			$xfer += $output->writeString($this->barCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>