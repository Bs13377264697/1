<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;

class CupGetAddressMappingRequest {
	
	static $_TSPEC;
	public $channel = null;
	public $outerAreaId = null;
	public $vipAreaId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'channel'
			),
			2 => array(
			'var' => 'outerAreaId'
			),
			3 => array(
			'var' => 'vipAreaId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['channel'])){
				
				$this->channel = $vals['channel'];
			}
			
			
			if (isset($vals['outerAreaId'])){
				
				$this->outerAreaId = $vals['outerAreaId'];
			}
			
			
			if (isset($vals['vipAreaId'])){
				
				$this->vipAreaId = $vals['vipAreaId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupGetAddressMappingRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("channel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->channel);
				
			}
			
			
			
			
			if ("outerAreaId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outerAreaId);
				
			}
			
			
			
			
			if ("vipAreaId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipAreaId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('channel');
		$xfer += $output->writeString($this->channel);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->outerAreaId !== null) {
			
			$xfer += $output->writeFieldBegin('outerAreaId');
			$xfer += $output->writeString($this->outerAreaId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->vipAreaId !== null) {
			
			$xfer += $output->writeFieldBegin('vipAreaId');
			$xfer += $output->writeString($this->vipAreaId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>