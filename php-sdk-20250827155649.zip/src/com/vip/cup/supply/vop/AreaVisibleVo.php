<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;

class AreaVisibleVo {
	
	static $_TSPEC;
	public $isAllFlag = null;
	public $areaVisibles = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'isAllFlag'
			),
			2 => array(
			'var' => 'areaVisibles'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['isAllFlag'])){
				
				$this->isAllFlag = $vals['isAllFlag'];
			}
			
			
			if (isset($vals['areaVisibles'])){
				
				$this->areaVisibles = $vals['areaVisibles'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'AreaVisibleVo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("isAllFlag" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->isAllFlag);
				
			}
			
			
			
			
			if ("areaVisibles" == $schemeField){
				
				$needSkip = false;
				
				$this->areaVisibles = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->areaVisibles[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->isAllFlag !== null) {
			
			$xfer += $output->writeFieldBegin('isAllFlag');
			$xfer += $output->writeString($this->isAllFlag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->areaVisibles !== null) {
			
			$xfer += $output->writeFieldBegin('areaVisibles');
			
			if (!is_array($this->areaVisibles)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->areaVisibles as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>