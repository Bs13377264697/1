<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;
interface CupSupplyAfterSaleServiceIf{
	
	
	public function cancelAfterSaleApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCancelAfterSaleApplyRequest $request);
	
	public function createReturnApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyRequest $request);
	
	public function createReturnApplyUpdateInfo(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyUpdateInfoRequest $request);
	
	public function getAfterSaleInfoList(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyGetAfterSaleInfoListRequest $request);
	
	public function healthCheck();
	
	public function notifyReturnRefundResult(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyNotifyReturnRefundResultRequest $request);
	
	public function pullOutReturnUpdate(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyPullOutReturnUpdateRequest $request);
	
}

class _CupSupplyAfterSaleServiceClient extends \Osp\Base\OspStub implements \com\vip\cup\supply\vop\CupSupplyAfterSaleServiceIf{
	
	public function __construct(){
		
		parent::__construct("com.vip.cup.supply.vop.CupSupplyAfterSaleService", "1.0.0");
	}
	
	
	public function cancelAfterSaleApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCancelAfterSaleApplyRequest $request){
		
		$this->send_cancelAfterSaleApply( $request);
		return $this->recv_cancelAfterSaleApply();
	}
	
	public function send_cancelAfterSaleApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCancelAfterSaleApplyRequest $request){
		
		$this->initInvocation("cancelAfterSaleApply");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_cancelAfterSaleApply_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_cancelAfterSaleApply(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_cancelAfterSaleApply_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function createReturnApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyRequest $request){
		
		$this->send_createReturnApply( $request);
		return $this->recv_createReturnApply();
	}
	
	public function send_createReturnApply(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyRequest $request){
		
		$this->initInvocation("createReturnApply");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_createReturnApply_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_createReturnApply(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_createReturnApply_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function createReturnApplyUpdateInfo(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyUpdateInfoRequest $request){
		
		$this->send_createReturnApplyUpdateInfo( $request);
		return $this->recv_createReturnApplyUpdateInfo();
	}
	
	public function send_createReturnApplyUpdateInfo(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyUpdateInfoRequest $request){
		
		$this->initInvocation("createReturnApplyUpdateInfo");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_createReturnApplyUpdateInfo_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_createReturnApplyUpdateInfo(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_createReturnApplyUpdateInfo_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function getAfterSaleInfoList(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyGetAfterSaleInfoListRequest $request){
		
		$this->send_getAfterSaleInfoList( $request);
		return $this->recv_getAfterSaleInfoList();
	}
	
	public function send_getAfterSaleInfoList(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyGetAfterSaleInfoListRequest $request){
		
		$this->initInvocation("getAfterSaleInfoList");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_getAfterSaleInfoList_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_getAfterSaleInfoList(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_getAfterSaleInfoList_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function healthCheck(){
		
		$this->send_healthCheck();
		return $this->recv_healthCheck();
	}
	
	public function send_healthCheck(){
		
		$this->initInvocation("healthCheck");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_healthCheck_args();
		
		$this->send_base($args);
	}
	
	public function recv_healthCheck(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_healthCheck_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function notifyReturnRefundResult(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyNotifyReturnRefundResultRequest $request){
		
		$this->send_notifyReturnRefundResult( $request);
		return $this->recv_notifyReturnRefundResult();
	}
	
	public function send_notifyReturnRefundResult(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyNotifyReturnRefundResultRequest $request){
		
		$this->initInvocation("notifyReturnRefundResult");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_notifyReturnRefundResult_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_notifyReturnRefundResult(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_notifyReturnRefundResult_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
	public function pullOutReturnUpdate(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyPullOutReturnUpdateRequest $request){
		
		$this->send_pullOutReturnUpdate( $request);
		return $this->recv_pullOutReturnUpdate();
	}
	
	public function send_pullOutReturnUpdate(\com\vip\cup\supply\vop\structs\aftersale\CupSupplyPullOutReturnUpdateRequest $request){
		
		$this->initInvocation("pullOutReturnUpdate");
		$args = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_pullOutReturnUpdate_args();
		
		$args->request = $request;
		
		$this->send_base($args);
	}
	
	public function recv_pullOutReturnUpdate(){
		
		$result = new \com\vip\cup\supply\vop\CupSupplyAfterSaleService_pullOutReturnUpdate_result();
		$this->receive_base($result);
		if ($result->success !== null){
			
			return $result->success;
		}
		
	}
	
	
}




class CupSupplyAfterSaleService_cancelAfterSaleApply_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCancelAfterSaleApplyRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_createReturnApply_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_createReturnApplyUpdateInfo_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyUpdateInfoRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_getAfterSaleInfoList_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyGetAfterSaleInfoListRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_healthCheck_args {
	
	static $_TSPEC;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			
			);
			
		}
		
		if (is_array($vals)){
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_notifyReturnRefundResult_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyNotifyReturnRefundResultRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_pullOutReturnUpdate_args {
	
	static $_TSPEC;
	public $request = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'request'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['request'])){
				
				$this->request = $vals['request'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->request = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyPullOutReturnUpdateRequest();
			$this->request->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->request !== null) {
			
			$xfer += $output->writeFieldBegin('request');
			
			if (!is_object($this->request)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->request->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_cancelAfterSaleApply_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCancelAfterSaleApplyResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_createReturnApply_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_createReturnApplyUpdateInfo_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyCreateReturnApplyUpdateInfoResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_getAfterSaleInfoList_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyGetAfterSaleInfoListResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_healthCheck_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\hermes\core\health\CheckResult();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_notifyReturnRefundResult_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyNotifyReturnRefundResultResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




class CupSupplyAfterSaleService_pullOutReturnUpdate_result {
	
	static $_TSPEC;
	public $success = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			0 => array(
			'var' => 'success'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['success'])){
				
				$this->success = $vals['success'];
			}
			
			
		}
		
	}
	
	
	public function read($input){
		
		
		
		
		if(true) {
			
			
			$this->success = new \com\vip\cup\supply\vop\structs\aftersale\CupSupplyPullOutReturnUpdateResponse();
			$this->success->read($input);
			
		}
		
		
		
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->success !== null) {
			
			$xfer += $output->writeFieldBegin('success');
			
			if (!is_object($this->success)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->success->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}




?>