<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;

class CupSupplyCreateCustWorkRequest {
	
	static $_TSPEC;
	public $merchantId = null;
	public $workId = null;
	public $orderId = null;
	public $commodityId = null;
	public $custName = null;
	public $custDeviceNo = null;
	public $complainTime = null;
	public $custAddress = null;
	public $complainType = null;
	public $complainSource = null;
	public $workType = null;
	public $workStatus = null;
	public $complainLevel = null;
	public $dealTime = null;
	public $repluLogList = null;
	public $commodityNum = null;
	public $specInfo = null;
	public $templateId = null;
	public $templateName = null;
	public $afterTempName = null;
	public $afterTemRemark = null;
	public $afterTempId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'merchantId'
			),
			2 => array(
			'var' => 'workId'
			),
			3 => array(
			'var' => 'orderId'
			),
			4 => array(
			'var' => 'commodityId'
			),
			5 => array(
			'var' => 'custName'
			),
			6 => array(
			'var' => 'custDeviceNo'
			),
			7 => array(
			'var' => 'complainTime'
			),
			8 => array(
			'var' => 'custAddress'
			),
			9 => array(
			'var' => 'complainType'
			),
			10 => array(
			'var' => 'complainSource'
			),
			11 => array(
			'var' => 'workType'
			),
			12 => array(
			'var' => 'workStatus'
			),
			13 => array(
			'var' => 'complainLevel'
			),
			14 => array(
			'var' => 'dealTime'
			),
			15 => array(
			'var' => 'repluLogList'
			),
			16 => array(
			'var' => 'commodityNum'
			),
			17 => array(
			'var' => 'specInfo'
			),
			18 => array(
			'var' => 'templateId'
			),
			19 => array(
			'var' => 'templateName'
			),
			20 => array(
			'var' => 'afterTempName'
			),
			21 => array(
			'var' => 'afterTemRemark'
			),
			22 => array(
			'var' => 'afterTempId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['merchantId'])){
				
				$this->merchantId = $vals['merchantId'];
			}
			
			
			if (isset($vals['workId'])){
				
				$this->workId = $vals['workId'];
			}
			
			
			if (isset($vals['orderId'])){
				
				$this->orderId = $vals['orderId'];
			}
			
			
			if (isset($vals['commodityId'])){
				
				$this->commodityId = $vals['commodityId'];
			}
			
			
			if (isset($vals['custName'])){
				
				$this->custName = $vals['custName'];
			}
			
			
			if (isset($vals['custDeviceNo'])){
				
				$this->custDeviceNo = $vals['custDeviceNo'];
			}
			
			
			if (isset($vals['complainTime'])){
				
				$this->complainTime = $vals['complainTime'];
			}
			
			
			if (isset($vals['custAddress'])){
				
				$this->custAddress = $vals['custAddress'];
			}
			
			
			if (isset($vals['complainType'])){
				
				$this->complainType = $vals['complainType'];
			}
			
			
			if (isset($vals['complainSource'])){
				
				$this->complainSource = $vals['complainSource'];
			}
			
			
			if (isset($vals['workType'])){
				
				$this->workType = $vals['workType'];
			}
			
			
			if (isset($vals['workStatus'])){
				
				$this->workStatus = $vals['workStatus'];
			}
			
			
			if (isset($vals['complainLevel'])){
				
				$this->complainLevel = $vals['complainLevel'];
			}
			
			
			if (isset($vals['dealTime'])){
				
				$this->dealTime = $vals['dealTime'];
			}
			
			
			if (isset($vals['repluLogList'])){
				
				$this->repluLogList = $vals['repluLogList'];
			}
			
			
			if (isset($vals['commodityNum'])){
				
				$this->commodityNum = $vals['commodityNum'];
			}
			
			
			if (isset($vals['specInfo'])){
				
				$this->specInfo = $vals['specInfo'];
			}
			
			
			if (isset($vals['templateId'])){
				
				$this->templateId = $vals['templateId'];
			}
			
			
			if (isset($vals['templateName'])){
				
				$this->templateName = $vals['templateName'];
			}
			
			
			if (isset($vals['afterTempName'])){
				
				$this->afterTempName = $vals['afterTempName'];
			}
			
			
			if (isset($vals['afterTemRemark'])){
				
				$this->afterTemRemark = $vals['afterTemRemark'];
			}
			
			
			if (isset($vals['afterTempId'])){
				
				$this->afterTempId = $vals['afterTempId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CupSupplyCreateCustWorkRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("merchantId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->merchantId);
				
			}
			
			
			
			
			if ("workId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->workId);
				
			}
			
			
			
			
			if ("orderId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderId);
				
			}
			
			
			
			
			if ("commodityId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityId);
				
			}
			
			
			
			
			if ("custName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->custName);
				
			}
			
			
			
			
			if ("custDeviceNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->custDeviceNo);
				
			}
			
			
			
			
			if ("complainTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->complainTime);
				
			}
			
			
			
			
			if ("custAddress" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->custAddress);
				
			}
			
			
			
			
			if ("complainType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->complainType);
				
			}
			
			
			
			
			if ("complainSource" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->complainSource);
				
			}
			
			
			
			
			if ("workType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->workType);
				
			}
			
			
			
			
			if ("workStatus" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->workStatus);
				
			}
			
			
			
			
			if ("complainLevel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->complainLevel);
				
			}
			
			
			
			
			if ("dealTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->dealTime);
				
			}
			
			
			
			
			if ("repluLogList" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->repluLogList);
				
			}
			
			
			
			
			if ("commodityNum" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->commodityNum); 
				
			}
			
			
			
			
			if ("specInfo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->specInfo);
				
			}
			
			
			
			
			if ("templateId" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->templateId); 
				
			}
			
			
			
			
			if ("templateName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->templateName);
				
			}
			
			
			
			
			if ("afterTempName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->afterTempName);
				
			}
			
			
			
			
			if ("afterTemRemark" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->afterTemRemark);
				
			}
			
			
			
			
			if ("afterTempId" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterTempId); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('merchantId');
		$xfer += $output->writeString($this->merchantId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('workId');
		$xfer += $output->writeString($this->workId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('orderId');
		$xfer += $output->writeString($this->orderId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('commodityId');
		$xfer += $output->writeString($this->commodityId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('custName');
		$xfer += $output->writeString($this->custName);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('custDeviceNo');
		$xfer += $output->writeString($this->custDeviceNo);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('complainTime');
		$xfer += $output->writeString($this->complainTime);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->custAddress !== null) {
			
			$xfer += $output->writeFieldBegin('custAddress');
			$xfer += $output->writeString($this->custAddress);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('complainType');
		$xfer += $output->writeString($this->complainType);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('complainSource');
		$xfer += $output->writeString($this->complainSource);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('workType');
		$xfer += $output->writeString($this->workType);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('workStatus');
		$xfer += $output->writeString($this->workStatus);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('complainLevel');
		$xfer += $output->writeString($this->complainLevel);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('dealTime');
		$xfer += $output->writeString($this->dealTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('repluLogList');
		$xfer += $output->writeString($this->repluLogList);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('commodityNum');
		$xfer += $output->writeI32($this->commodityNum);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->specInfo !== null) {
			
			$xfer += $output->writeFieldBegin('specInfo');
			$xfer += $output->writeString($this->specInfo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('templateId');
		$xfer += $output->writeI32($this->templateId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('templateName');
		$xfer += $output->writeString($this->templateName);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->afterTempName !== null) {
			
			$xfer += $output->writeFieldBegin('afterTempName');
			$xfer += $output->writeString($this->afterTempName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterTemRemark !== null) {
			
			$xfer += $output->writeFieldBegin('afterTemRemark');
			$xfer += $output->writeString($this->afterTemRemark);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterTempId !== null) {
			
			$xfer += $output->writeFieldBegin('afterTempId');
			$xfer += $output->writeI32($this->afterTempId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>