<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\supply\vop;
require_once dirname(__FILE__).'/CupAddressService.php';
class CupAddressServiceHelper extends _CupAddressServiceClient{
	
	public function __construct(){
		
		parent::__construct();
	}
	
}

?>