<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\sal\vop;
final class AttributeTypeForVop{
	
	
	const Normal = 0;
	
	const Tag = 1;
	
	const Special = 2;
	
	static public $__names = array(
	
	0 => 'Normal',
	
	1 => 'Tag',
	
	2 => 'Special',
	
	);
}

?>