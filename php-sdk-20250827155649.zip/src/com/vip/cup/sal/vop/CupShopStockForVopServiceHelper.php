<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\sal\vop;
require_once dirname(__FILE__).'/CupShopStockForVopService.php';
class CupShopStockForVopServiceHelper extends _CupShopStockForVopServiceClient{
	
	public function __construct(){
		
		parent::__construct();
	}
	
}

?>