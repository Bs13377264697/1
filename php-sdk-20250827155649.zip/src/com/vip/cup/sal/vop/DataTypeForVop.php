<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\sal\vop;
final class DataTypeForVop{
	
	
	const Text = 0;
	
	const Numeric = 1;
	
	const Option = 2;
	
	const Bumble = 3;
	
	const Picture = 4;
	
	static public $__names = array(
	
	0 => 'Text',
	
	1 => 'Numeric',
	
	2 => 'Option',
	
	3 => 'Bumble',
	
	4 => 'Picture',
	
	);
}

?>