<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cup\sal\vop;
final class EventTypeForVop{
	
	
	const PROD_CREATE = 0;
	
	const ON_OFF_SHELF = 1;
	
	const PRICE_CHANGE = 2;
	
	const PDC_CHANGE = 3;
	
	const PROD_DELETE = 4;
	
	static public $__names = array(
	
	0 => 'PROD_CREATE',
	
	1 => 'ON_OFF_SHELF',
	
	2 => 'PRICE_CHANGE',
	
	3 => 'PDC_CHANGE',
	
	4 => 'PROD_DELETE',
	
	);
}

?>