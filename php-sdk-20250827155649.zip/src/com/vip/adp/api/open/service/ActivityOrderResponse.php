<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class ActivityOrderResponse {
	
	static $_TSPEC;
	public $orderList = null;
	public $nextPageOffset = null;
	public $isLast = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderList'
			),
			2 => array(
			'var' => 'nextPageOffset'
			),
			3 => array(
			'var' => 'isLast'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderList'])){
				
				$this->orderList = $vals['orderList'];
			}
			
			
			if (isset($vals['nextPageOffset'])){
				
				$this->nextPageOffset = $vals['nextPageOffset'];
			}
			
			
			if (isset($vals['isLast'])){
				
				$this->isLast = $vals['isLast'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ActivityOrderResponse';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderList" == $schemeField){
				
				$needSkip = false;
				
				$this->orderList = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\adp\api\open\service\ActivityOrderInfo();
						$elem0->read($input);
						
						$this->orderList[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("nextPageOffset" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->nextPageOffset); 
				
			}
			
			
			
			
			if ("isLast" == $schemeField){
				
				$needSkip = false;
				$input->readBool($this->isLast);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderList !== null) {
			
			$xfer += $output->writeFieldBegin('orderList');
			
			if (!is_array($this->orderList)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->orderList as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->nextPageOffset !== null) {
			
			$xfer += $output->writeFieldBegin('nextPageOffset');
			$xfer += $output->writeI64($this->nextPageOffset);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('isLast');
		$xfer += $output->writeBool($this->isLast);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>