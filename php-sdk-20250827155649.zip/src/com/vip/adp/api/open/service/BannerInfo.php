<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class BannerInfo {
	
	static $_TSPEC;
	public $adCode = null;
	public $bannerName = null;
	public $bannerImg = null;
	public $bannerUrl = null;
	public $width = null;
	public $height = null;
	public $bannerId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'adCode'
			),
			2 => array(
			'var' => 'bannerName'
			),
			3 => array(
			'var' => 'bannerImg'
			),
			4 => array(
			'var' => 'bannerUrl'
			),
			5 => array(
			'var' => 'width'
			),
			6 => array(
			'var' => 'height'
			),
			7 => array(
			'var' => 'bannerId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['adCode'])){
				
				$this->adCode = $vals['adCode'];
			}
			
			
			if (isset($vals['bannerName'])){
				
				$this->bannerName = $vals['bannerName'];
			}
			
			
			if (isset($vals['bannerImg'])){
				
				$this->bannerImg = $vals['bannerImg'];
			}
			
			
			if (isset($vals['bannerUrl'])){
				
				$this->bannerUrl = $vals['bannerUrl'];
			}
			
			
			if (isset($vals['width'])){
				
				$this->width = $vals['width'];
			}
			
			
			if (isset($vals['height'])){
				
				$this->height = $vals['height'];
			}
			
			
			if (isset($vals['bannerId'])){
				
				$this->bannerId = $vals['bannerId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'BannerInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("adCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adCode);
				
			}
			
			
			
			
			if ("bannerName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->bannerName);
				
			}
			
			
			
			
			if ("bannerImg" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->bannerImg);
				
			}
			
			
			
			
			if ("bannerUrl" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->bannerUrl);
				
			}
			
			
			
			
			if ("width" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->width); 
				
			}
			
			
			
			
			if ("height" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->height); 
				
			}
			
			
			
			
			if ("bannerId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->bannerId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->adCode !== null) {
			
			$xfer += $output->writeFieldBegin('adCode');
			$xfer += $output->writeString($this->adCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->bannerName !== null) {
			
			$xfer += $output->writeFieldBegin('bannerName');
			$xfer += $output->writeString($this->bannerName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->bannerImg !== null) {
			
			$xfer += $output->writeFieldBegin('bannerImg');
			$xfer += $output->writeString($this->bannerImg);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->bannerUrl !== null) {
			
			$xfer += $output->writeFieldBegin('bannerUrl');
			$xfer += $output->writeString($this->bannerUrl);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->width !== null) {
			
			$xfer += $output->writeFieldBegin('width');
			$xfer += $output->writeI32($this->width);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->height !== null) {
			
			$xfer += $output->writeFieldBegin('height');
			$xfer += $output->writeI32($this->height);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->bannerId !== null) {
			
			$xfer += $output->writeFieldBegin('bannerId');
			$xfer += $output->writeString($this->bannerId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>