<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class MarketingGoodsInfo {
	
	static $_TSPEC;
	public $goodsId = null;
	public $goodsName = null;
	public $goodsDesc = null;
	public $destUrl = null;
	public $goodsThumbUrl = null;
	public $goodsCarouselPictures = null;
	public $goodsMainPicture = null;
	public $categoryId = null;
	public $categoryName = null;
	public $sourceType = null;
	public $goodsDetailPictures = null;
	public $cat1stId = null;
	public $cat1stName = null;
	public $cat2ndId = null;
	public $cat2ndName = null;
	public $brandStoreSn = null;
	public $brandName = null;
	public $brandLogoFull = null;
	public $schemeEndTime = null;
	public $sellTimeFrom = null;
	public $sellTimeTo = null;
	public $weight = null;
	public $storeInfo = null;
	public $commentsInfo = null;
	public $storeServiceCapability = null;
	public $brandId = null;
	public $schemeStartTime = null;
	public $saleStockStatus = null;
	public $status = null;
	public $prepayInfo = null;
	public $haiTao = null;
	public $spuId = null;
	public $goodsIdsWithSameSpu = null;
	public $skuInfos = null;
	public $cpsInfo = null;
	public $sn = null;
	public $tagNames = null;
	public $whiteImage = null;
	public $isSubsidyActivityGoods = null;
	public $subsidyActivityAmount = null;
	public $subsidyTaskNo = null;
	public $couponPriceType = null;
	public $productSales = null;
	public $destUrlPc = null;
	public $adCode = null;
	public $goodsPromotionInfo = null;
	public $commissionRate = null;
	public $commission = null;
	public $allowance = null;
	public $allowanceStartTime = null;
	public $allowanceEndTime = null;
	public $isAllowanceGoods = null;
	public $vipPrice = null;
	public $promotionPrice = null;
	public $discount = null;
	public $marketPrice = null;
	public $campaignCommissionInfo = null;
	public $goodsStateSubsidyInfoList = null;
	public $canCreateGift = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'goodsId'
			),
			2 => array(
			'var' => 'goodsName'
			),
			3 => array(
			'var' => 'goodsDesc'
			),
			4 => array(
			'var' => 'destUrl'
			),
			5 => array(
			'var' => 'goodsThumbUrl'
			),
			6 => array(
			'var' => 'goodsCarouselPictures'
			),
			7 => array(
			'var' => 'goodsMainPicture'
			),
			8 => array(
			'var' => 'categoryId'
			),
			9 => array(
			'var' => 'categoryName'
			),
			10 => array(
			'var' => 'sourceType'
			),
			11 => array(
			'var' => 'goodsDetailPictures'
			),
			12 => array(
			'var' => 'cat1stId'
			),
			13 => array(
			'var' => 'cat1stName'
			),
			14 => array(
			'var' => 'cat2ndId'
			),
			15 => array(
			'var' => 'cat2ndName'
			),
			16 => array(
			'var' => 'brandStoreSn'
			),
			17 => array(
			'var' => 'brandName'
			),
			18 => array(
			'var' => 'brandLogoFull'
			),
			19 => array(
			'var' => 'schemeEndTime'
			),
			20 => array(
			'var' => 'sellTimeFrom'
			),
			21 => array(
			'var' => 'sellTimeTo'
			),
			22 => array(
			'var' => 'weight'
			),
			23 => array(
			'var' => 'storeInfo'
			),
			24 => array(
			'var' => 'commentsInfo'
			),
			25 => array(
			'var' => 'storeServiceCapability'
			),
			26 => array(
			'var' => 'brandId'
			),
			27 => array(
			'var' => 'schemeStartTime'
			),
			28 => array(
			'var' => 'saleStockStatus'
			),
			29 => array(
			'var' => 'status'
			),
			30 => array(
			'var' => 'prepayInfo'
			),
			31 => array(
			'var' => 'haiTao'
			),
			32 => array(
			'var' => 'spuId'
			),
			33 => array(
			'var' => 'goodsIdsWithSameSpu'
			),
			34 => array(
			'var' => 'skuInfos'
			),
			35 => array(
			'var' => 'cpsInfo'
			),
			36 => array(
			'var' => 'sn'
			),
			37 => array(
			'var' => 'tagNames'
			),
			38 => array(
			'var' => 'whiteImage'
			),
			39 => array(
			'var' => 'isSubsidyActivityGoods'
			),
			40 => array(
			'var' => 'subsidyActivityAmount'
			),
			41 => array(
			'var' => 'subsidyTaskNo'
			),
			42 => array(
			'var' => 'couponPriceType'
			),
			43 => array(
			'var' => 'productSales'
			),
			44 => array(
			'var' => 'destUrlPc'
			),
			45 => array(
			'var' => 'adCode'
			),
			46 => array(
			'var' => 'goodsPromotionInfo'
			),
			47 => array(
			'var' => 'commissionRate'
			),
			48 => array(
			'var' => 'commission'
			),
			49 => array(
			'var' => 'allowance'
			),
			50 => array(
			'var' => 'allowanceStartTime'
			),
			51 => array(
			'var' => 'allowanceEndTime'
			),
			52 => array(
			'var' => 'isAllowanceGoods'
			),
			53 => array(
			'var' => 'vipPrice'
			),
			54 => array(
			'var' => 'promotionPrice'
			),
			55 => array(
			'var' => 'discount'
			),
			56 => array(
			'var' => 'marketPrice'
			),
			57 => array(
			'var' => 'campaignCommissionInfo'
			),
			58 => array(
			'var' => 'goodsStateSubsidyInfoList'
			),
			59 => array(
			'var' => 'canCreateGift'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['goodsName'])){
				
				$this->goodsName = $vals['goodsName'];
			}
			
			
			if (isset($vals['goodsDesc'])){
				
				$this->goodsDesc = $vals['goodsDesc'];
			}
			
			
			if (isset($vals['destUrl'])){
				
				$this->destUrl = $vals['destUrl'];
			}
			
			
			if (isset($vals['goodsThumbUrl'])){
				
				$this->goodsThumbUrl = $vals['goodsThumbUrl'];
			}
			
			
			if (isset($vals['goodsCarouselPictures'])){
				
				$this->goodsCarouselPictures = $vals['goodsCarouselPictures'];
			}
			
			
			if (isset($vals['goodsMainPicture'])){
				
				$this->goodsMainPicture = $vals['goodsMainPicture'];
			}
			
			
			if (isset($vals['categoryId'])){
				
				$this->categoryId = $vals['categoryId'];
			}
			
			
			if (isset($vals['categoryName'])){
				
				$this->categoryName = $vals['categoryName'];
			}
			
			
			if (isset($vals['sourceType'])){
				
				$this->sourceType = $vals['sourceType'];
			}
			
			
			if (isset($vals['goodsDetailPictures'])){
				
				$this->goodsDetailPictures = $vals['goodsDetailPictures'];
			}
			
			
			if (isset($vals['cat1stId'])){
				
				$this->cat1stId = $vals['cat1stId'];
			}
			
			
			if (isset($vals['cat1stName'])){
				
				$this->cat1stName = $vals['cat1stName'];
			}
			
			
			if (isset($vals['cat2ndId'])){
				
				$this->cat2ndId = $vals['cat2ndId'];
			}
			
			
			if (isset($vals['cat2ndName'])){
				
				$this->cat2ndName = $vals['cat2ndName'];
			}
			
			
			if (isset($vals['brandStoreSn'])){
				
				$this->brandStoreSn = $vals['brandStoreSn'];
			}
			
			
			if (isset($vals['brandName'])){
				
				$this->brandName = $vals['brandName'];
			}
			
			
			if (isset($vals['brandLogoFull'])){
				
				$this->brandLogoFull = $vals['brandLogoFull'];
			}
			
			
			if (isset($vals['schemeEndTime'])){
				
				$this->schemeEndTime = $vals['schemeEndTime'];
			}
			
			
			if (isset($vals['sellTimeFrom'])){
				
				$this->sellTimeFrom = $vals['sellTimeFrom'];
			}
			
			
			if (isset($vals['sellTimeTo'])){
				
				$this->sellTimeTo = $vals['sellTimeTo'];
			}
			
			
			if (isset($vals['weight'])){
				
				$this->weight = $vals['weight'];
			}
			
			
			if (isset($vals['storeInfo'])){
				
				$this->storeInfo = $vals['storeInfo'];
			}
			
			
			if (isset($vals['commentsInfo'])){
				
				$this->commentsInfo = $vals['commentsInfo'];
			}
			
			
			if (isset($vals['storeServiceCapability'])){
				
				$this->storeServiceCapability = $vals['storeServiceCapability'];
			}
			
			
			if (isset($vals['brandId'])){
				
				$this->brandId = $vals['brandId'];
			}
			
			
			if (isset($vals['schemeStartTime'])){
				
				$this->schemeStartTime = $vals['schemeStartTime'];
			}
			
			
			if (isset($vals['saleStockStatus'])){
				
				$this->saleStockStatus = $vals['saleStockStatus'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
			if (isset($vals['prepayInfo'])){
				
				$this->prepayInfo = $vals['prepayInfo'];
			}
			
			
			if (isset($vals['haiTao'])){
				
				$this->haiTao = $vals['haiTao'];
			}
			
			
			if (isset($vals['spuId'])){
				
				$this->spuId = $vals['spuId'];
			}
			
			
			if (isset($vals['goodsIdsWithSameSpu'])){
				
				$this->goodsIdsWithSameSpu = $vals['goodsIdsWithSameSpu'];
			}
			
			
			if (isset($vals['skuInfos'])){
				
				$this->skuInfos = $vals['skuInfos'];
			}
			
			
			if (isset($vals['cpsInfo'])){
				
				$this->cpsInfo = $vals['cpsInfo'];
			}
			
			
			if (isset($vals['sn'])){
				
				$this->sn = $vals['sn'];
			}
			
			
			if (isset($vals['tagNames'])){
				
				$this->tagNames = $vals['tagNames'];
			}
			
			
			if (isset($vals['whiteImage'])){
				
				$this->whiteImage = $vals['whiteImage'];
			}
			
			
			if (isset($vals['isSubsidyActivityGoods'])){
				
				$this->isSubsidyActivityGoods = $vals['isSubsidyActivityGoods'];
			}
			
			
			if (isset($vals['subsidyActivityAmount'])){
				
				$this->subsidyActivityAmount = $vals['subsidyActivityAmount'];
			}
			
			
			if (isset($vals['subsidyTaskNo'])){
				
				$this->subsidyTaskNo = $vals['subsidyTaskNo'];
			}
			
			
			if (isset($vals['couponPriceType'])){
				
				$this->couponPriceType = $vals['couponPriceType'];
			}
			
			
			if (isset($vals['productSales'])){
				
				$this->productSales = $vals['productSales'];
			}
			
			
			if (isset($vals['destUrlPc'])){
				
				$this->destUrlPc = $vals['destUrlPc'];
			}
			
			
			if (isset($vals['adCode'])){
				
				$this->adCode = $vals['adCode'];
			}
			
			
			if (isset($vals['goodsPromotionInfo'])){
				
				$this->goodsPromotionInfo = $vals['goodsPromotionInfo'];
			}
			
			
			if (isset($vals['commissionRate'])){
				
				$this->commissionRate = $vals['commissionRate'];
			}
			
			
			if (isset($vals['commission'])){
				
				$this->commission = $vals['commission'];
			}
			
			
			if (isset($vals['allowance'])){
				
				$this->allowance = $vals['allowance'];
			}
			
			
			if (isset($vals['allowanceStartTime'])){
				
				$this->allowanceStartTime = $vals['allowanceStartTime'];
			}
			
			
			if (isset($vals['allowanceEndTime'])){
				
				$this->allowanceEndTime = $vals['allowanceEndTime'];
			}
			
			
			if (isset($vals['isAllowanceGoods'])){
				
				$this->isAllowanceGoods = $vals['isAllowanceGoods'];
			}
			
			
			if (isset($vals['vipPrice'])){
				
				$this->vipPrice = $vals['vipPrice'];
			}
			
			
			if (isset($vals['promotionPrice'])){
				
				$this->promotionPrice = $vals['promotionPrice'];
			}
			
			
			if (isset($vals['discount'])){
				
				$this->discount = $vals['discount'];
			}
			
			
			if (isset($vals['marketPrice'])){
				
				$this->marketPrice = $vals['marketPrice'];
			}
			
			
			if (isset($vals['campaignCommissionInfo'])){
				
				$this->campaignCommissionInfo = $vals['campaignCommissionInfo'];
			}
			
			
			if (isset($vals['goodsStateSubsidyInfoList'])){
				
				$this->goodsStateSubsidyInfoList = $vals['goodsStateSubsidyInfoList'];
			}
			
			
			if (isset($vals['canCreateGift'])){
				
				$this->canCreateGift = $vals['canCreateGift'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'MarketingGoodsInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("goodsName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsName);
				
			}
			
			
			
			
			if ("goodsDesc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsDesc);
				
			}
			
			
			
			
			if ("destUrl" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->destUrl);
				
			}
			
			
			
			
			if ("goodsThumbUrl" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsThumbUrl);
				
			}
			
			
			
			
			if ("goodsCarouselPictures" == $schemeField){
				
				$needSkip = false;
				
				$this->goodsCarouselPictures = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->goodsCarouselPictures[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("goodsMainPicture" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsMainPicture);
				
			}
			
			
			
			
			if ("categoryId" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->categoryId); 
				
			}
			
			
			
			
			if ("categoryName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->categoryName);
				
			}
			
			
			
			
			if ("sourceType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->sourceType); 
				
			}
			
			
			
			
			if ("goodsDetailPictures" == $schemeField){
				
				$needSkip = false;
				
				$this->goodsDetailPictures = array();
				$_size1 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem1 = null;
						$input->readString($elem1);
						
						$this->goodsDetailPictures[$_size1++] = $elem1;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("cat1stId" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->cat1stId); 
				
			}
			
			
			
			
			if ("cat1stName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->cat1stName);
				
			}
			
			
			
			
			if ("cat2ndId" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->cat2ndId); 
				
			}
			
			
			
			
			if ("cat2ndName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->cat2ndName);
				
			}
			
			
			
			
			if ("brandStoreSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandStoreSn);
				
			}
			
			
			
			
			if ("brandName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandName);
				
			}
			
			
			
			
			if ("brandLogoFull" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandLogoFull);
				
			}
			
			
			
			
			if ("schemeEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->schemeEndTime); 
				
			}
			
			
			
			
			if ("sellTimeFrom" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->sellTimeFrom); 
				
			}
			
			
			
			
			if ("sellTimeTo" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->sellTimeTo); 
				
			}
			
			
			
			
			if ("weight" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->weight); 
				
			}
			
			
			
			
			if ("storeInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->storeInfo = new \com\vip\adp\api\open\service\StoreInfo();
				$this->storeInfo->read($input);
				
			}
			
			
			
			
			if ("commentsInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->commentsInfo = new \com\vip\adp\api\open\service\GoodsCommentsInfo();
				$this->commentsInfo->read($input);
				
			}
			
			
			
			
			if ("storeServiceCapability" == $schemeField){
				
				$needSkip = false;
				
				$this->storeServiceCapability = new \com\vip\adp\api\open\service\StoreServiceCapability();
				$this->storeServiceCapability->read($input);
				
			}
			
			
			
			
			if ("brandId" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->brandId); 
				
			}
			
			
			
			
			if ("schemeStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->schemeStartTime); 
				
			}
			
			
			
			
			if ("saleStockStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->saleStockStatus); 
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->status); 
				
			}
			
			
			
			
			if ("prepayInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->prepayInfo = new \com\vip\adp\api\open\service\PrepayInfo();
				$this->prepayInfo->read($input);
				
			}
			
			
			
			
			if ("haiTao" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->haiTao); 
				
			}
			
			
			
			
			if ("spuId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->spuId);
				
			}
			
			
			
			
			if ("goodsIdsWithSameSpu" == $schemeField){
				
				$needSkip = false;
				
				$this->goodsIdsWithSameSpu = array();
				$_size2 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem2 = null;
						$input->readString($elem2);
						
						$this->goodsIdsWithSameSpu[$_size2++] = $elem2;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("skuInfos" == $schemeField){
				
				$needSkip = false;
				
				$this->skuInfos = array();
				$_size3 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem3 = null;
						
						$elem3 = new \com\vip\adp\api\open\service\GoodsSkuInfo();
						$elem3->read($input);
						
						$this->skuInfos[$_size3++] = $elem3;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("cpsInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->cpsInfo = array();
				$input->readMapBegin();
				while(true){
					
					try{
						
						$key4 = 0;
						$input->readI32($key4); 
						
						$val4 = '';
						$input->readString($val4);
						
						$this->cpsInfo[$key4] = $val4;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readMapEnd();
				
			}
			
			
			
			
			if ("sn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->sn);
				
			}
			
			
			
			
			if ("tagNames" == $schemeField){
				
				$needSkip = false;
				
				$this->tagNames = array();
				$_size5 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem5 = null;
						$input->readString($elem5);
						
						$this->tagNames[$_size5++] = $elem5;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("whiteImage" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->whiteImage);
				
			}
			
			
			
			
			if ("isSubsidyActivityGoods" == $schemeField){
				
				$needSkip = false;
				$input->readBool($this->isSubsidyActivityGoods);
				
			}
			
			
			
			
			if ("subsidyActivityAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->subsidyActivityAmount);
				
			}
			
			
			
			
			if ("subsidyTaskNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->subsidyTaskNo);
				
			}
			
			
			
			
			if ("couponPriceType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->couponPriceType); 
				
			}
			
			
			
			
			if ("productSales" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->productSales);
				
			}
			
			
			
			
			if ("destUrlPc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->destUrlPc);
				
			}
			
			
			
			
			if ("adCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adCode);
				
			}
			
			
			
			
			if ("goodsPromotionInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->goodsPromotionInfo = new \com\vip\adp\common\service\GoodsPromotionInfo();
				$this->goodsPromotionInfo->read($input);
				
			}
			
			
			
			
			if ("commissionRate" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commissionRate);
				
			}
			
			
			
			
			if ("commission" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commission);
				
			}
			
			
			
			
			if ("allowance" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->allowance);
				
			}
			
			
			
			
			if ("allowanceStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->allowanceStartTime); 
				
			}
			
			
			
			
			if ("allowanceEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->allowanceEndTime); 
				
			}
			
			
			
			
			if ("isAllowanceGoods" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isAllowanceGoods); 
				
			}
			
			
			
			
			if ("vipPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->vipPrice);
				
			}
			
			
			
			
			if ("promotionPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->promotionPrice);
				
			}
			
			
			
			
			if ("discount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->discount);
				
			}
			
			
			
			
			if ("marketPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->marketPrice);
				
			}
			
			
			
			
			if ("campaignCommissionInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->campaignCommissionInfo = new \com\vip\adp\common\service\CampaignCommissionInfo();
				$this->campaignCommissionInfo->read($input);
				
			}
			
			
			
			
			if ("goodsStateSubsidyInfoList" == $schemeField){
				
				$needSkip = false;
				
				$this->goodsStateSubsidyInfoList = array();
				$_size6 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem6 = null;
						
						$elem6 = new \com\vip\adp\api\open\service\GoodsStateSubsidyInfo();
						$elem6->read($input);
						
						$this->goodsStateSubsidyInfoList[$_size6++] = $elem6;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("canCreateGift" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->canCreateGift); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->goodsId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsId');
			$xfer += $output->writeString($this->goodsId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsName !== null) {
			
			$xfer += $output->writeFieldBegin('goodsName');
			$xfer += $output->writeString($this->goodsName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsDesc !== null) {
			
			$xfer += $output->writeFieldBegin('goodsDesc');
			$xfer += $output->writeString($this->goodsDesc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->destUrl !== null) {
			
			$xfer += $output->writeFieldBegin('destUrl');
			$xfer += $output->writeString($this->destUrl);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsThumbUrl !== null) {
			
			$xfer += $output->writeFieldBegin('goodsThumbUrl');
			$xfer += $output->writeString($this->goodsThumbUrl);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsCarouselPictures !== null) {
			
			$xfer += $output->writeFieldBegin('goodsCarouselPictures');
			
			if (!is_array($this->goodsCarouselPictures)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->goodsCarouselPictures as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsMainPicture !== null) {
			
			$xfer += $output->writeFieldBegin('goodsMainPicture');
			$xfer += $output->writeString($this->goodsMainPicture);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->categoryId !== null) {
			
			$xfer += $output->writeFieldBegin('categoryId');
			$xfer += $output->writeI64($this->categoryId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->categoryName !== null) {
			
			$xfer += $output->writeFieldBegin('categoryName');
			$xfer += $output->writeString($this->categoryName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sourceType !== null) {
			
			$xfer += $output->writeFieldBegin('sourceType');
			$xfer += $output->writeI32($this->sourceType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsDetailPictures !== null) {
			
			$xfer += $output->writeFieldBegin('goodsDetailPictures');
			
			if (!is_array($this->goodsDetailPictures)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->goodsDetailPictures as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cat1stId !== null) {
			
			$xfer += $output->writeFieldBegin('cat1stId');
			$xfer += $output->writeI64($this->cat1stId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cat1stName !== null) {
			
			$xfer += $output->writeFieldBegin('cat1stName');
			$xfer += $output->writeString($this->cat1stName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cat2ndId !== null) {
			
			$xfer += $output->writeFieldBegin('cat2ndId');
			$xfer += $output->writeI64($this->cat2ndId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cat2ndName !== null) {
			
			$xfer += $output->writeFieldBegin('cat2ndName');
			$xfer += $output->writeString($this->cat2ndName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandStoreSn !== null) {
			
			$xfer += $output->writeFieldBegin('brandStoreSn');
			$xfer += $output->writeString($this->brandStoreSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandName !== null) {
			
			$xfer += $output->writeFieldBegin('brandName');
			$xfer += $output->writeString($this->brandName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandLogoFull !== null) {
			
			$xfer += $output->writeFieldBegin('brandLogoFull');
			$xfer += $output->writeString($this->brandLogoFull);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->schemeEndTime !== null) {
			
			$xfer += $output->writeFieldBegin('schemeEndTime');
			$xfer += $output->writeI64($this->schemeEndTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sellTimeFrom !== null) {
			
			$xfer += $output->writeFieldBegin('sellTimeFrom');
			$xfer += $output->writeI64($this->sellTimeFrom);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sellTimeTo !== null) {
			
			$xfer += $output->writeFieldBegin('sellTimeTo');
			$xfer += $output->writeI64($this->sellTimeTo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->weight !== null) {
			
			$xfer += $output->writeFieldBegin('weight');
			$xfer += $output->writeI32($this->weight);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->storeInfo !== null) {
			
			$xfer += $output->writeFieldBegin('storeInfo');
			
			if (!is_object($this->storeInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->storeInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commentsInfo !== null) {
			
			$xfer += $output->writeFieldBegin('commentsInfo');
			
			if (!is_object($this->commentsInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->commentsInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->storeServiceCapability !== null) {
			
			$xfer += $output->writeFieldBegin('storeServiceCapability');
			
			if (!is_object($this->storeServiceCapability)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->storeServiceCapability->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandId !== null) {
			
			$xfer += $output->writeFieldBegin('brandId');
			$xfer += $output->writeI64($this->brandId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->schemeStartTime !== null) {
			
			$xfer += $output->writeFieldBegin('schemeStartTime');
			$xfer += $output->writeI64($this->schemeStartTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->saleStockStatus !== null) {
			
			$xfer += $output->writeFieldBegin('saleStockStatus');
			$xfer += $output->writeI32($this->saleStockStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeI32($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->prepayInfo !== null) {
			
			$xfer += $output->writeFieldBegin('prepayInfo');
			
			if (!is_object($this->prepayInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->prepayInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->haiTao !== null) {
			
			$xfer += $output->writeFieldBegin('haiTao');
			$xfer += $output->writeI32($this->haiTao);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->spuId !== null) {
			
			$xfer += $output->writeFieldBegin('spuId');
			$xfer += $output->writeString($this->spuId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsIdsWithSameSpu !== null) {
			
			$xfer += $output->writeFieldBegin('goodsIdsWithSameSpu');
			
			if (!is_array($this->goodsIdsWithSameSpu)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->goodsIdsWithSameSpu as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->skuInfos !== null) {
			
			$xfer += $output->writeFieldBegin('skuInfos');
			
			if (!is_array($this->skuInfos)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->skuInfos as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cpsInfo !== null) {
			
			$xfer += $output->writeFieldBegin('cpsInfo');
			
			if (!is_array($this->cpsInfo)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeMapBegin();
			foreach ($this->cpsInfo as $kiter0 => $viter0){
				
				$xfer += $output->writeI32($kiter0);
				
				$xfer += $output->writeString($viter0);
				
			}
			
			$output->writeMapEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sn !== null) {
			
			$xfer += $output->writeFieldBegin('sn');
			$xfer += $output->writeString($this->sn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->tagNames !== null) {
			
			$xfer += $output->writeFieldBegin('tagNames');
			
			if (!is_array($this->tagNames)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->tagNames as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->whiteImage !== null) {
			
			$xfer += $output->writeFieldBegin('whiteImage');
			$xfer += $output->writeString($this->whiteImage);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('isSubsidyActivityGoods');
		$xfer += $output->writeBool($this->isSubsidyActivityGoods);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->subsidyActivityAmount !== null) {
			
			$xfer += $output->writeFieldBegin('subsidyActivityAmount');
			$xfer += $output->writeString($this->subsidyActivityAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->subsidyTaskNo !== null) {
			
			$xfer += $output->writeFieldBegin('subsidyTaskNo');
			$xfer += $output->writeString($this->subsidyTaskNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->couponPriceType !== null) {
			
			$xfer += $output->writeFieldBegin('couponPriceType');
			$xfer += $output->writeI32($this->couponPriceType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->productSales !== null) {
			
			$xfer += $output->writeFieldBegin('productSales');
			$xfer += $output->writeString($this->productSales);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->destUrlPc !== null) {
			
			$xfer += $output->writeFieldBegin('destUrlPc');
			$xfer += $output->writeString($this->destUrlPc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->adCode !== null) {
			
			$xfer += $output->writeFieldBegin('adCode');
			$xfer += $output->writeString($this->adCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsPromotionInfo !== null) {
			
			$xfer += $output->writeFieldBegin('goodsPromotionInfo');
			
			if (!is_object($this->goodsPromotionInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->goodsPromotionInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commissionRate !== null) {
			
			$xfer += $output->writeFieldBegin('commissionRate');
			$xfer += $output->writeString($this->commissionRate);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commission !== null) {
			
			$xfer += $output->writeFieldBegin('commission');
			$xfer += $output->writeString($this->commission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->allowance !== null) {
			
			$xfer += $output->writeFieldBegin('allowance');
			$xfer += $output->writeString($this->allowance);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->allowanceStartTime !== null) {
			
			$xfer += $output->writeFieldBegin('allowanceStartTime');
			$xfer += $output->writeI64($this->allowanceStartTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->allowanceEndTime !== null) {
			
			$xfer += $output->writeFieldBegin('allowanceEndTime');
			$xfer += $output->writeI64($this->allowanceEndTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isAllowanceGoods !== null) {
			
			$xfer += $output->writeFieldBegin('isAllowanceGoods');
			$xfer += $output->writeI32($this->isAllowanceGoods);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->vipPrice !== null) {
			
			$xfer += $output->writeFieldBegin('vipPrice');
			$xfer += $output->writeString($this->vipPrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->promotionPrice !== null) {
			
			$xfer += $output->writeFieldBegin('promotionPrice');
			$xfer += $output->writeString($this->promotionPrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->discount !== null) {
			
			$xfer += $output->writeFieldBegin('discount');
			$xfer += $output->writeString($this->discount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->marketPrice !== null) {
			
			$xfer += $output->writeFieldBegin('marketPrice');
			$xfer += $output->writeString($this->marketPrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->campaignCommissionInfo !== null) {
			
			$xfer += $output->writeFieldBegin('campaignCommissionInfo');
			
			if (!is_object($this->campaignCommissionInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->campaignCommissionInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsStateSubsidyInfoList !== null) {
			
			$xfer += $output->writeFieldBegin('goodsStateSubsidyInfoList');
			
			if (!is_array($this->goodsStateSubsidyInfoList)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->goodsStateSubsidyInfoList as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->canCreateGift !== null) {
			
			$xfer += $output->writeFieldBegin('canCreateGift');
			$xfer += $output->writeI32($this->canCreateGift);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>