<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class MixHomeBrandFloorDetailInfo {
	
	static $_TSPEC;
	public $brand = null;
	public $topic = null;
	public $banner = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'brand'
			),
			2 => array(
			'var' => 'topic'
			),
			3 => array(
			'var' => 'banner'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['brand'])){
				
				$this->brand = $vals['brand'];
			}
			
			
			if (isset($vals['topic'])){
				
				$this->topic = $vals['topic'];
			}
			
			
			if (isset($vals['banner'])){
				
				$this->banner = $vals['banner'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'MixHomeBrandFloorDetailInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("brand" == $schemeField){
				
				$needSkip = false;
				
				$this->brand = new \com\vip\adp\api\open\service\BrandInfo();
				$this->brand->read($input);
				
			}
			
			
			
			
			if ("topic" == $schemeField){
				
				$needSkip = false;
				
				$this->topic = new \com\vip\adp\api\open\service\TopicInfo();
				$this->topic->read($input);
				
			}
			
			
			
			
			if ("banner" == $schemeField){
				
				$needSkip = false;
				
				$this->banner = new \com\vip\adp\api\open\service\BannerInfo();
				$this->banner->read($input);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->brand !== null) {
			
			$xfer += $output->writeFieldBegin('brand');
			
			if (!is_object($this->brand)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->brand->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->topic !== null) {
			
			$xfer += $output->writeFieldBegin('topic');
			
			if (!is_object($this->topic)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->topic->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->banner !== null) {
			
			$xfer += $output->writeFieldBegin('banner');
			
			if (!is_object($this->banner)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->banner->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>