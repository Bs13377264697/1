<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class UnionGiftCouponQueryDetailRequest {
	
	static $_TSPEC;
	public $requestId = null;
	public $giftCreateStartDate = null;
	public $giftOrderStartDate = null;
	public $goodsId = null;
	public $giftCode = null;
	public $openId = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'requestId'
			),
			2 => array(
			'var' => 'giftCreateStartDate'
			),
			3 => array(
			'var' => 'giftOrderStartDate'
			),
			4 => array(
			'var' => 'goodsId'
			),
			5 => array(
			'var' => 'giftCode'
			),
			6 => array(
			'var' => 'openId'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['requestId'])){
				
				$this->requestId = $vals['requestId'];
			}
			
			
			if (isset($vals['giftCreateStartDate'])){
				
				$this->giftCreateStartDate = $vals['giftCreateStartDate'];
			}
			
			
			if (isset($vals['giftOrderStartDate'])){
				
				$this->giftOrderStartDate = $vals['giftOrderStartDate'];
			}
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['giftCode'])){
				
				$this->giftCode = $vals['giftCode'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'UnionGiftCouponQueryDetailRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("requestId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->requestId);
				
			}
			
			
			
			
			if ("giftCreateStartDate" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftCreateStartDate);
				
			}
			
			
			
			
			if ("giftOrderStartDate" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftOrderStartDate);
				
			}
			
			
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("giftCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftCode);
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('requestId');
		$xfer += $output->writeString($this->requestId);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->giftCreateStartDate !== null) {
			
			$xfer += $output->writeFieldBegin('giftCreateStartDate');
			$xfer += $output->writeString($this->giftCreateStartDate);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->giftOrderStartDate !== null) {
			
			$xfer += $output->writeFieldBegin('giftOrderStartDate');
			$xfer += $output->writeString($this->giftOrderStartDate);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsId');
			$xfer += $output->writeString($this->goodsId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->giftCode !== null) {
			
			$xfer += $output->writeFieldBegin('giftCode');
			$xfer += $output->writeString($this->giftCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>