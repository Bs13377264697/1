<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class UnionGiftInfo {
	
	static $_TSPEC;
	public $giftName = null;
	public $giftCode = null;
	public $amount = null;
	public $totalCount = null;
	public $remainAmount = null;
	public $usedCount = null;
	public $enableStatus = null;
	public $giftStatus = null;
	public $useTimeType = null;
	public $activityStartTime = null;
	public $activityEndTime = null;
	public $useStartTime = null;
	public $useEndTime = null;
	public $relativeNumber = null;
	public $targetedType = null;
	public $targetedValues = null;
	public $singleClaimPerLink = null;
	public $allSkusUnderProduct = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			2 => array(
			'var' => 'giftName'
			),
			3 => array(
			'var' => 'giftCode'
			),
			4 => array(
			'var' => 'amount'
			),
			5 => array(
			'var' => 'totalCount'
			),
			6 => array(
			'var' => 'remainAmount'
			),
			7 => array(
			'var' => 'usedCount'
			),
			8 => array(
			'var' => 'enableStatus'
			),
			9 => array(
			'var' => 'giftStatus'
			),
			10 => array(
			'var' => 'useTimeType'
			),
			11 => array(
			'var' => 'activityStartTime'
			),
			12 => array(
			'var' => 'activityEndTime'
			),
			13 => array(
			'var' => 'useStartTime'
			),
			14 => array(
			'var' => 'useEndTime'
			),
			15 => array(
			'var' => 'relativeNumber'
			),
			16 => array(
			'var' => 'targetedType'
			),
			17 => array(
			'var' => 'targetedValues'
			),
			18 => array(
			'var' => 'singleClaimPerLink'
			),
			19 => array(
			'var' => 'allSkusUnderProduct'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['giftName'])){
				
				$this->giftName = $vals['giftName'];
			}
			
			
			if (isset($vals['giftCode'])){
				
				$this->giftCode = $vals['giftCode'];
			}
			
			
			if (isset($vals['amount'])){
				
				$this->amount = $vals['amount'];
			}
			
			
			if (isset($vals['totalCount'])){
				
				$this->totalCount = $vals['totalCount'];
			}
			
			
			if (isset($vals['remainAmount'])){
				
				$this->remainAmount = $vals['remainAmount'];
			}
			
			
			if (isset($vals['usedCount'])){
				
				$this->usedCount = $vals['usedCount'];
			}
			
			
			if (isset($vals['enableStatus'])){
				
				$this->enableStatus = $vals['enableStatus'];
			}
			
			
			if (isset($vals['giftStatus'])){
				
				$this->giftStatus = $vals['giftStatus'];
			}
			
			
			if (isset($vals['useTimeType'])){
				
				$this->useTimeType = $vals['useTimeType'];
			}
			
			
			if (isset($vals['activityStartTime'])){
				
				$this->activityStartTime = $vals['activityStartTime'];
			}
			
			
			if (isset($vals['activityEndTime'])){
				
				$this->activityEndTime = $vals['activityEndTime'];
			}
			
			
			if (isset($vals['useStartTime'])){
				
				$this->useStartTime = $vals['useStartTime'];
			}
			
			
			if (isset($vals['useEndTime'])){
				
				$this->useEndTime = $vals['useEndTime'];
			}
			
			
			if (isset($vals['relativeNumber'])){
				
				$this->relativeNumber = $vals['relativeNumber'];
			}
			
			
			if (isset($vals['targetedType'])){
				
				$this->targetedType = $vals['targetedType'];
			}
			
			
			if (isset($vals['targetedValues'])){
				
				$this->targetedValues = $vals['targetedValues'];
			}
			
			
			if (isset($vals['singleClaimPerLink'])){
				
				$this->singleClaimPerLink = $vals['singleClaimPerLink'];
			}
			
			
			if (isset($vals['allSkusUnderProduct'])){
				
				$this->allSkusUnderProduct = $vals['allSkusUnderProduct'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'UnionGiftInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("giftName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftName);
				
			}
			
			
			
			
			if ("giftCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftCode);
				
			}
			
			
			
			
			if ("amount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->amount);
				
			}
			
			
			
			
			if ("totalCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->totalCount); 
				
			}
			
			
			
			
			if ("remainAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->remainAmount);
				
			}
			
			
			
			
			if ("usedCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->usedCount); 
				
			}
			
			
			
			
			if ("enableStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->enableStatus); 
				
			}
			
			
			
			
			if ("giftStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->giftStatus); 
				
			}
			
			
			
			
			if ("useTimeType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->useTimeType); 
				
			}
			
			
			
			
			if ("activityStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->activityStartTime);
				
			}
			
			
			
			
			if ("activityEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->activityEndTime);
				
			}
			
			
			
			
			if ("useStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useStartTime);
				
			}
			
			
			
			
			if ("useEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useEndTime);
				
			}
			
			
			
			
			if ("relativeNumber" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->relativeNumber); 
				
			}
			
			
			
			
			if ("targetedType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->targetedType); 
				
			}
			
			
			
			
			if ("targetedValues" == $schemeField){
				
				$needSkip = false;
				
				$this->targetedValues = array();
				$_size0 = 0;
				$input->readSetBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->targetedValues[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readSetEnd();
				
			}
			
			
			
			
			if ("singleClaimPerLink" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->singleClaimPerLink); 
				
			}
			
			
			
			
			if ("allSkusUnderProduct" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->allSkusUnderProduct); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->giftName !== null) {
			
			$xfer += $output->writeFieldBegin('giftName');
			$xfer += $output->writeString($this->giftName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->giftCode !== null) {
			
			$xfer += $output->writeFieldBegin('giftCode');
			$xfer += $output->writeString($this->giftCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->amount !== null) {
			
			$xfer += $output->writeFieldBegin('amount');
			$xfer += $output->writeString($this->amount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->totalCount !== null) {
			
			$xfer += $output->writeFieldBegin('totalCount');
			$xfer += $output->writeI32($this->totalCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->remainAmount !== null) {
			
			$xfer += $output->writeFieldBegin('remainAmount');
			$xfer += $output->writeString($this->remainAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->usedCount !== null) {
			
			$xfer += $output->writeFieldBegin('usedCount');
			$xfer += $output->writeI32($this->usedCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->enableStatus !== null) {
			
			$xfer += $output->writeFieldBegin('enableStatus');
			$xfer += $output->writeI32($this->enableStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->giftStatus !== null) {
			
			$xfer += $output->writeFieldBegin('giftStatus');
			$xfer += $output->writeI32($this->giftStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useTimeType !== null) {
			
			$xfer += $output->writeFieldBegin('useTimeType');
			$xfer += $output->writeI32($this->useTimeType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->activityStartTime !== null) {
			
			$xfer += $output->writeFieldBegin('activityStartTime');
			$xfer += $output->writeString($this->activityStartTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->activityEndTime !== null) {
			
			$xfer += $output->writeFieldBegin('activityEndTime');
			$xfer += $output->writeString($this->activityEndTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useStartTime !== null) {
			
			$xfer += $output->writeFieldBegin('useStartTime');
			$xfer += $output->writeString($this->useStartTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useEndTime !== null) {
			
			$xfer += $output->writeFieldBegin('useEndTime');
			$xfer += $output->writeString($this->useEndTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->relativeNumber !== null) {
			
			$xfer += $output->writeFieldBegin('relativeNumber');
			$xfer += $output->writeI32($this->relativeNumber);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedType !== null) {
			
			$xfer += $output->writeFieldBegin('targetedType');
			$xfer += $output->writeI32($this->targetedType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedValues !== null) {
			
			$xfer += $output->writeFieldBegin('targetedValues');
			
			if (!is_array($this->targetedValues)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeSetBegin();
			foreach ($this->targetedValues as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeSetEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->singleClaimPerLink !== null) {
			
			$xfer += $output->writeFieldBegin('singleClaimPerLink');
			$xfer += $output->writeI32($this->singleClaimPerLink);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->allSkusUnderProduct !== null) {
			
			$xfer += $output->writeFieldBegin('allSkusUnderProduct');
			$xfer += $output->writeI32($this->allSkusUnderProduct);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>