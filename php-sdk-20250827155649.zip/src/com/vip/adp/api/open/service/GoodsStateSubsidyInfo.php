<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class GoodsStateSubsidyInfo {
	
	static $_TSPEC;
	public $tradeInFlag = null;
	public $isAllArea = null;
	public $provinceName = null;
	public $cityName = null;
	public $discount = null;
	public $maxDiscount = null;
	public $type = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'tradeInFlag'
			),
			2 => array(
			'var' => 'isAllArea'
			),
			3 => array(
			'var' => 'provinceName'
			),
			4 => array(
			'var' => 'cityName'
			),
			5 => array(
			'var' => 'discount'
			),
			6 => array(
			'var' => 'maxDiscount'
			),
			7 => array(
			'var' => 'type'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['tradeInFlag'])){
				
				$this->tradeInFlag = $vals['tradeInFlag'];
			}
			
			
			if (isset($vals['isAllArea'])){
				
				$this->isAllArea = $vals['isAllArea'];
			}
			
			
			if (isset($vals['provinceName'])){
				
				$this->provinceName = $vals['provinceName'];
			}
			
			
			if (isset($vals['cityName'])){
				
				$this->cityName = $vals['cityName'];
			}
			
			
			if (isset($vals['discount'])){
				
				$this->discount = $vals['discount'];
			}
			
			
			if (isset($vals['maxDiscount'])){
				
				$this->maxDiscount = $vals['maxDiscount'];
			}
			
			
			if (isset($vals['type'])){
				
				$this->type = $vals['type'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'GoodsStateSubsidyInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("tradeInFlag" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->tradeInFlag); 
				
			}
			
			
			
			
			if ("isAllArea" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isAllArea); 
				
			}
			
			
			
			
			if ("provinceName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->provinceName);
				
			}
			
			
			
			
			if ("cityName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->cityName);
				
			}
			
			
			
			
			if ("discount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->discount);
				
			}
			
			
			
			
			if ("maxDiscount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->maxDiscount);
				
			}
			
			
			
			
			if ("type" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->type);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->tradeInFlag !== null) {
			
			$xfer += $output->writeFieldBegin('tradeInFlag');
			$xfer += $output->writeI32($this->tradeInFlag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isAllArea !== null) {
			
			$xfer += $output->writeFieldBegin('isAllArea');
			$xfer += $output->writeI32($this->isAllArea);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->provinceName !== null) {
			
			$xfer += $output->writeFieldBegin('provinceName');
			$xfer += $output->writeString($this->provinceName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cityName !== null) {
			
			$xfer += $output->writeFieldBegin('cityName');
			$xfer += $output->writeString($this->cityName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->discount !== null) {
			
			$xfer += $output->writeFieldBegin('discount');
			$xfer += $output->writeString($this->discount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->maxDiscount !== null) {
			
			$xfer += $output->writeFieldBegin('maxDiscount');
			$xfer += $output->writeString($this->maxDiscount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->type !== null) {
			
			$xfer += $output->writeFieldBegin('type');
			$xfer += $output->writeString($this->type);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>