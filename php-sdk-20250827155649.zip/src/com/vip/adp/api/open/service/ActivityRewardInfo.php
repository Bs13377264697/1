<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class ActivityRewardInfo {
	
	static $_TSPEC;
	public $ucode = null;
	public $openId = null;
	public $prizeAmount = null;
	public $orderCount = null;
	public $commissionCost = null;
	public $checkStatus = null;
	public $commission = null;
	public $userCount = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'ucode'
			),
			2 => array(
			'var' => 'openId'
			),
			3 => array(
			'var' => 'prizeAmount'
			),
			4 => array(
			'var' => 'orderCount'
			),
			5 => array(
			'var' => 'commissionCost'
			),
			6 => array(
			'var' => 'checkStatus'
			),
			7 => array(
			'var' => 'commission'
			),
			8 => array(
			'var' => 'userCount'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['ucode'])){
				
				$this->ucode = $vals['ucode'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['prizeAmount'])){
				
				$this->prizeAmount = $vals['prizeAmount'];
			}
			
			
			if (isset($vals['orderCount'])){
				
				$this->orderCount = $vals['orderCount'];
			}
			
			
			if (isset($vals['commissionCost'])){
				
				$this->commissionCost = $vals['commissionCost'];
			}
			
			
			if (isset($vals['checkStatus'])){
				
				$this->checkStatus = $vals['checkStatus'];
			}
			
			
			if (isset($vals['commission'])){
				
				$this->commission = $vals['commission'];
			}
			
			
			if (isset($vals['userCount'])){
				
				$this->userCount = $vals['userCount'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ActivityRewardInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("ucode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->ucode);
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("prizeAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->prizeAmount);
				
			}
			
			
			
			
			if ("orderCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderCount); 
				
			}
			
			
			
			
			if ("commissionCost" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commissionCost);
				
			}
			
			
			
			
			if ("checkStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->checkStatus); 
				
			}
			
			
			
			
			if ("commission" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commission);
				
			}
			
			
			
			
			if ("userCount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->userCount);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->ucode !== null) {
			
			$xfer += $output->writeFieldBegin('ucode');
			$xfer += $output->writeString($this->ucode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->prizeAmount !== null) {
			
			$xfer += $output->writeFieldBegin('prizeAmount');
			$xfer += $output->writeString($this->prizeAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderCount !== null) {
			
			$xfer += $output->writeFieldBegin('orderCount');
			$xfer += $output->writeI32($this->orderCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commissionCost !== null) {
			
			$xfer += $output->writeFieldBegin('commissionCost');
			$xfer += $output->writeString($this->commissionCost);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->checkStatus !== null) {
			
			$xfer += $output->writeFieldBegin('checkStatus');
			$xfer += $output->writeI32($this->checkStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commission !== null) {
			
			$xfer += $output->writeFieldBegin('commission');
			$xfer += $output->writeString($this->commission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->userCount !== null) {
			
			$xfer += $output->writeFieldBegin('userCount');
			$xfer += $output->writeString($this->userCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>