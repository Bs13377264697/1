<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class TopicInfo {
	
	static $_TSPEC;
	public $adCode = null;
	public $brandId = null;
	public $productId = null;
	public $productImage = null;
	public $mreTitle = null;
	public $mreSubTitle = null;
	public $brandSnLogo = null;
	public $promotionIcon = null;
	public $ruleTag = null;
	public $topicAtmImageInfo = null;
	public $productSquareImage = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'adCode'
			),
			2 => array(
			'var' => 'brandId'
			),
			3 => array(
			'var' => 'productId'
			),
			4 => array(
			'var' => 'productImage'
			),
			5 => array(
			'var' => 'mreTitle'
			),
			6 => array(
			'var' => 'mreSubTitle'
			),
			7 => array(
			'var' => 'brandSnLogo'
			),
			8 => array(
			'var' => 'promotionIcon'
			),
			9 => array(
			'var' => 'ruleTag'
			),
			10 => array(
			'var' => 'topicAtmImageInfo'
			),
			11 => array(
			'var' => 'productSquareImage'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['adCode'])){
				
				$this->adCode = $vals['adCode'];
			}
			
			
			if (isset($vals['brandId'])){
				
				$this->brandId = $vals['brandId'];
			}
			
			
			if (isset($vals['productId'])){
				
				$this->productId = $vals['productId'];
			}
			
			
			if (isset($vals['productImage'])){
				
				$this->productImage = $vals['productImage'];
			}
			
			
			if (isset($vals['mreTitle'])){
				
				$this->mreTitle = $vals['mreTitle'];
			}
			
			
			if (isset($vals['mreSubTitle'])){
				
				$this->mreSubTitle = $vals['mreSubTitle'];
			}
			
			
			if (isset($vals['brandSnLogo'])){
				
				$this->brandSnLogo = $vals['brandSnLogo'];
			}
			
			
			if (isset($vals['promotionIcon'])){
				
				$this->promotionIcon = $vals['promotionIcon'];
			}
			
			
			if (isset($vals['ruleTag'])){
				
				$this->ruleTag = $vals['ruleTag'];
			}
			
			
			if (isset($vals['topicAtmImageInfo'])){
				
				$this->topicAtmImageInfo = $vals['topicAtmImageInfo'];
			}
			
			
			if (isset($vals['productSquareImage'])){
				
				$this->productSquareImage = $vals['productSquareImage'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'TopicInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("adCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adCode);
				
			}
			
			
			
			
			if ("brandId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandId);
				
			}
			
			
			
			
			if ("productId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->productId);
				
			}
			
			
			
			
			if ("productImage" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->productImage);
				
			}
			
			
			
			
			if ("mreTitle" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mreTitle);
				
			}
			
			
			
			
			if ("mreSubTitle" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mreSubTitle);
				
			}
			
			
			
			
			if ("brandSnLogo" == $schemeField){
				
				$needSkip = false;
				
				$this->brandSnLogo = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\adp\api\open\service\TopicBrandSnLogo();
						$elem0->read($input);
						
						$this->brandSnLogo[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("promotionIcon" == $schemeField){
				
				$needSkip = false;
				
				$this->promotionIcon = new \com\vip\adp\api\open\service\TopicPromotionIcon();
				$this->promotionIcon->read($input);
				
			}
			
			
			
			
			if ("ruleTag" == $schemeField){
				
				$needSkip = false;
				
				$this->ruleTag = new \com\vip\adp\api\open\service\TopicRuleTag();
				$this->ruleTag->read($input);
				
			}
			
			
			
			
			if ("topicAtmImageInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->topicAtmImageInfo = new \com\vip\adp\api\open\service\TopicAtmImageInfo();
				$this->topicAtmImageInfo->read($input);
				
			}
			
			
			
			
			if ("productSquareImage" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->productSquareImage);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->adCode !== null) {
			
			$xfer += $output->writeFieldBegin('adCode');
			$xfer += $output->writeString($this->adCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandId !== null) {
			
			$xfer += $output->writeFieldBegin('brandId');
			$xfer += $output->writeString($this->brandId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->productId !== null) {
			
			$xfer += $output->writeFieldBegin('productId');
			$xfer += $output->writeString($this->productId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->productImage !== null) {
			
			$xfer += $output->writeFieldBegin('productImage');
			$xfer += $output->writeString($this->productImage);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->mreTitle !== null) {
			
			$xfer += $output->writeFieldBegin('mreTitle');
			$xfer += $output->writeString($this->mreTitle);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->mreSubTitle !== null) {
			
			$xfer += $output->writeFieldBegin('mreSubTitle');
			$xfer += $output->writeString($this->mreSubTitle);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandSnLogo !== null) {
			
			$xfer += $output->writeFieldBegin('brandSnLogo');
			
			if (!is_array($this->brandSnLogo)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->brandSnLogo as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->promotionIcon !== null) {
			
			$xfer += $output->writeFieldBegin('promotionIcon');
			
			if (!is_object($this->promotionIcon)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->promotionIcon->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->ruleTag !== null) {
			
			$xfer += $output->writeFieldBegin('ruleTag');
			
			if (!is_object($this->ruleTag)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->ruleTag->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->topicAtmImageInfo !== null) {
			
			$xfer += $output->writeFieldBegin('topicAtmImageInfo');
			
			if (!is_object($this->topicAtmImageInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->topicAtmImageInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->productSquareImage !== null) {
			
			$xfer += $output->writeFieldBegin('productSquareImage');
			$xfer += $output->writeString($this->productSquareImage);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>