<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;
final class GetChannelUrlByTypeEnum{
	
	
	const PROMOTE_PAGE = 0;
	
	const PROMOTE_PAGE_REBATE = 7;
	
	const PROMOTE_PAGE_BUYER = 8;
	
	const RANK_CHANNEL = 1;
	
	const RANK_USER = 2;
	
	const CHANNEL_SUBSIDY = 3;
	
	const CHANNEL_SUBSIDY_USER = 4;
	
	const HIDDEN_COUPON_GOODS_LIST = 5;
	
	const HIDDEN_COUPON_GOODS_LIST_USER = 6;
	
	const BEST_PRICE_PAGE = 9;
	
	const BEST_PRICE_PAGE_REBATE = 10;
	
	const BEST_PRICE_PAGE_BUYER = 11;
	
	const GOODS_LIST_H5_PAGE = 12;
	
	const GOODS_LIST_H5_PAGE_REBATE = 13;
	
	const GOODS_LIST_H5_PAGE_BUYER = 14;
	
	const CHANNEL_SUBSIDY_REBATE = 15;
	
	const BIND_FILING_LINK = 16;
	
	const ACTIVITY_PAGE = 17;
	
	const ACTIVITY_PAGE_REBATE = 18;
	
	static public $__names = array(
	
	0 => 'PROMOTE_PAGE',
	
	7 => 'PROMOTE_PAGE_REBATE',
	
	8 => 'PROMOTE_PAGE_BUYER',
	
	1 => 'RANK_CHANNEL',
	
	2 => 'RANK_USER',
	
	3 => 'CHANNEL_SUBSIDY',
	
	4 => 'CHANNEL_SUBSIDY_USER',
	
	5 => 'HIDDEN_COUPON_GOODS_LIST',
	
	6 => 'HIDDEN_COUPON_GOODS_LIST_USER',
	
	9 => 'BEST_PRICE_PAGE',
	
	10 => 'BEST_PRICE_PAGE_REBATE',
	
	11 => 'BEST_PRICE_PAGE_BUYER',
	
	12 => 'GOODS_LIST_H5_PAGE',
	
	13 => 'GOODS_LIST_H5_PAGE_REBATE',
	
	14 => 'GOODS_LIST_H5_PAGE_BUYER',
	
	15 => 'CHANNEL_SUBSIDY_REBATE',
	
	16 => 'BIND_FILING_LINK',
	
	17 => 'ACTIVITY_PAGE',
	
	18 => 'ACTIVITY_PAGE_REBATE',
	
	);
}

?>