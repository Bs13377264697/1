<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class TopicBrandSnLogo {
	
	static $_TSPEC;
	public $primary = null;
	public $white = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'primary'
			),
			2 => array(
			'var' => 'white'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['primary'])){
				
				$this->primary = $vals['primary'];
			}
			
			
			if (isset($vals['white'])){
				
				$this->white = $vals['white'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'TopicBrandSnLogo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("primary" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->primary);
				
			}
			
			
			
			
			if ("white" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->white);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->primary !== null) {
			
			$xfer += $output->writeFieldBegin('primary');
			$xfer += $output->writeString($this->primary);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->white !== null) {
			
			$xfer += $output->writeFieldBegin('white');
			$xfer += $output->writeString($this->white);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>