<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class UnionDistributionInfo {
	
	static $_TSPEC;
	public $giftCode = null;
	public $giftName = null;
	public $amount = null;
	public $goodsId = null;
	public $totalCount = null;
	public $receiveCount = null;
	public $useCount = null;
	public $estimatedCommission = null;
	public $expiredCount = null;
	public $useAmount = null;
	public $targetedType = null;
	public $targetedValues = null;
	public $returnedCount = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'giftCode'
			),
			2 => array(
			'var' => 'giftName'
			),
			3 => array(
			'var' => 'amount'
			),
			4 => array(
			'var' => 'goodsId'
			),
			5 => array(
			'var' => 'totalCount'
			),
			6 => array(
			'var' => 'receiveCount'
			),
			7 => array(
			'var' => 'useCount'
			),
			8 => array(
			'var' => 'estimatedCommission'
			),
			9 => array(
			'var' => 'expiredCount'
			),
			10 => array(
			'var' => 'useAmount'
			),
			11 => array(
			'var' => 'targetedType'
			),
			12 => array(
			'var' => 'targetedValues'
			),
			13 => array(
			'var' => 'returnedCount'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['giftCode'])){
				
				$this->giftCode = $vals['giftCode'];
			}
			
			
			if (isset($vals['giftName'])){
				
				$this->giftName = $vals['giftName'];
			}
			
			
			if (isset($vals['amount'])){
				
				$this->amount = $vals['amount'];
			}
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['totalCount'])){
				
				$this->totalCount = $vals['totalCount'];
			}
			
			
			if (isset($vals['receiveCount'])){
				
				$this->receiveCount = $vals['receiveCount'];
			}
			
			
			if (isset($vals['useCount'])){
				
				$this->useCount = $vals['useCount'];
			}
			
			
			if (isset($vals['estimatedCommission'])){
				
				$this->estimatedCommission = $vals['estimatedCommission'];
			}
			
			
			if (isset($vals['expiredCount'])){
				
				$this->expiredCount = $vals['expiredCount'];
			}
			
			
			if (isset($vals['useAmount'])){
				
				$this->useAmount = $vals['useAmount'];
			}
			
			
			if (isset($vals['targetedType'])){
				
				$this->targetedType = $vals['targetedType'];
			}
			
			
			if (isset($vals['targetedValues'])){
				
				$this->targetedValues = $vals['targetedValues'];
			}
			
			
			if (isset($vals['returnedCount'])){
				
				$this->returnedCount = $vals['returnedCount'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'UnionDistributionInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("giftCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftCode);
				
			}
			
			
			
			
			if ("giftName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftName);
				
			}
			
			
			
			
			if ("amount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->amount);
				
			}
			
			
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("totalCount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->totalCount);
				
			}
			
			
			
			
			if ("receiveCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->receiveCount); 
				
			}
			
			
			
			
			if ("useCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->useCount); 
				
			}
			
			
			
			
			if ("estimatedCommission" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->estimatedCommission);
				
			}
			
			
			
			
			if ("expiredCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->expiredCount); 
				
			}
			
			
			
			
			if ("useAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useAmount);
				
			}
			
			
			
			
			if ("targetedType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->targetedType); 
				
			}
			
			
			
			
			if ("targetedValues" == $schemeField){
				
				$needSkip = false;
				
				$this->targetedValues = array();
				$_size0 = 0;
				$input->readSetBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->targetedValues[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readSetEnd();
				
			}
			
			
			
			
			if ("returnedCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->returnedCount); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->giftCode !== null) {
			
			$xfer += $output->writeFieldBegin('giftCode');
			$xfer += $output->writeString($this->giftCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->giftName !== null) {
			
			$xfer += $output->writeFieldBegin('giftName');
			$xfer += $output->writeString($this->giftName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->amount !== null) {
			
			$xfer += $output->writeFieldBegin('amount');
			$xfer += $output->writeString($this->amount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsId');
			$xfer += $output->writeString($this->goodsId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->totalCount !== null) {
			
			$xfer += $output->writeFieldBegin('totalCount');
			$xfer += $output->writeString($this->totalCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveCount !== null) {
			
			$xfer += $output->writeFieldBegin('receiveCount');
			$xfer += $output->writeI32($this->receiveCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useCount !== null) {
			
			$xfer += $output->writeFieldBegin('useCount');
			$xfer += $output->writeI32($this->useCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->estimatedCommission !== null) {
			
			$xfer += $output->writeFieldBegin('estimatedCommission');
			$xfer += $output->writeString($this->estimatedCommission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->expiredCount !== null) {
			
			$xfer += $output->writeFieldBegin('expiredCount');
			$xfer += $output->writeI32($this->expiredCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useAmount !== null) {
			
			$xfer += $output->writeFieldBegin('useAmount');
			$xfer += $output->writeString($this->useAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedType !== null) {
			
			$xfer += $output->writeFieldBegin('targetedType');
			$xfer += $output->writeI32($this->targetedType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedValues !== null) {
			
			$xfer += $output->writeFieldBegin('targetedValues');
			
			if (!is_array($this->targetedValues)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeSetBegin();
			foreach ($this->targetedValues as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeSetEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->returnedCount !== null) {
			
			$xfer += $output->writeFieldBegin('returnedCount');
			$xfer += $output->writeI32($this->returnedCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>