<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class VirtualOrderInfo {
	
	static $_TSPEC;
	public $orderSn = null;
	public $status = null;
	public $channelTag = null;
	public $orderTime = null;
	public $settledTime = null;
	public $goodsId = null;
	public $goodsName = null;
	public $goodsThumb = null;
	public $goodsType = null;
	public $lastUpdateTime = null;
	public $settled = null;
	public $selfBuy = null;
	public $orderSubStatusName = null;
	public $commissionTotalCost = null;
	public $commission = null;
	public $commissionRate = null;
	public $commissionEnterTime = null;
	public $orderSource = null;
	public $totalCost = null;
	public $afterSaleChangeCommission = null;
	public $pid = null;
	public $statParam = null;
	public $orderTrackReason = null;
	public $appKey = null;
	public $openId = null;
	public $adCode = null;
	public $refundOrderDetails = null;
	public $fdsBlackOrder = null;
	public $svipOpenType = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderSn'
			),
			2 => array(
			'var' => 'status'
			),
			3 => array(
			'var' => 'channelTag'
			),
			4 => array(
			'var' => 'orderTime'
			),
			5 => array(
			'var' => 'settledTime'
			),
			6 => array(
			'var' => 'goodsId'
			),
			7 => array(
			'var' => 'goodsName'
			),
			8 => array(
			'var' => 'goodsThumb'
			),
			9 => array(
			'var' => 'goodsType'
			),
			10 => array(
			'var' => 'lastUpdateTime'
			),
			11 => array(
			'var' => 'settled'
			),
			12 => array(
			'var' => 'selfBuy'
			),
			13 => array(
			'var' => 'orderSubStatusName'
			),
			14 => array(
			'var' => 'commissionTotalCost'
			),
			15 => array(
			'var' => 'commission'
			),
			16 => array(
			'var' => 'commissionRate'
			),
			17 => array(
			'var' => 'commissionEnterTime'
			),
			18 => array(
			'var' => 'orderSource'
			),
			19 => array(
			'var' => 'totalCost'
			),
			20 => array(
			'var' => 'afterSaleChangeCommission'
			),
			21 => array(
			'var' => 'pid'
			),
			22 => array(
			'var' => 'statParam'
			),
			23 => array(
			'var' => 'orderTrackReason'
			),
			24 => array(
			'var' => 'appKey'
			),
			25 => array(
			'var' => 'openId'
			),
			26 => array(
			'var' => 'adCode'
			),
			27 => array(
			'var' => 'refundOrderDetails'
			),
			28 => array(
			'var' => 'fdsBlackOrder'
			),
			29 => array(
			'var' => 'svipOpenType'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
			if (isset($vals['channelTag'])){
				
				$this->channelTag = $vals['channelTag'];
			}
			
			
			if (isset($vals['orderTime'])){
				
				$this->orderTime = $vals['orderTime'];
			}
			
			
			if (isset($vals['settledTime'])){
				
				$this->settledTime = $vals['settledTime'];
			}
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['goodsName'])){
				
				$this->goodsName = $vals['goodsName'];
			}
			
			
			if (isset($vals['goodsThumb'])){
				
				$this->goodsThumb = $vals['goodsThumb'];
			}
			
			
			if (isset($vals['goodsType'])){
				
				$this->goodsType = $vals['goodsType'];
			}
			
			
			if (isset($vals['lastUpdateTime'])){
				
				$this->lastUpdateTime = $vals['lastUpdateTime'];
			}
			
			
			if (isset($vals['settled'])){
				
				$this->settled = $vals['settled'];
			}
			
			
			if (isset($vals['selfBuy'])){
				
				$this->selfBuy = $vals['selfBuy'];
			}
			
			
			if (isset($vals['orderSubStatusName'])){
				
				$this->orderSubStatusName = $vals['orderSubStatusName'];
			}
			
			
			if (isset($vals['commissionTotalCost'])){
				
				$this->commissionTotalCost = $vals['commissionTotalCost'];
			}
			
			
			if (isset($vals['commission'])){
				
				$this->commission = $vals['commission'];
			}
			
			
			if (isset($vals['commissionRate'])){
				
				$this->commissionRate = $vals['commissionRate'];
			}
			
			
			if (isset($vals['commissionEnterTime'])){
				
				$this->commissionEnterTime = $vals['commissionEnterTime'];
			}
			
			
			if (isset($vals['orderSource'])){
				
				$this->orderSource = $vals['orderSource'];
			}
			
			
			if (isset($vals['totalCost'])){
				
				$this->totalCost = $vals['totalCost'];
			}
			
			
			if (isset($vals['afterSaleChangeCommission'])){
				
				$this->afterSaleChangeCommission = $vals['afterSaleChangeCommission'];
			}
			
			
			if (isset($vals['pid'])){
				
				$this->pid = $vals['pid'];
			}
			
			
			if (isset($vals['statParam'])){
				
				$this->statParam = $vals['statParam'];
			}
			
			
			if (isset($vals['orderTrackReason'])){
				
				$this->orderTrackReason = $vals['orderTrackReason'];
			}
			
			
			if (isset($vals['appKey'])){
				
				$this->appKey = $vals['appKey'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['adCode'])){
				
				$this->adCode = $vals['adCode'];
			}
			
			
			if (isset($vals['refundOrderDetails'])){
				
				$this->refundOrderDetails = $vals['refundOrderDetails'];
			}
			
			
			if (isset($vals['fdsBlackOrder'])){
				
				$this->fdsBlackOrder = $vals['fdsBlackOrder'];
			}
			
			
			if (isset($vals['svipOpenType'])){
				
				$this->svipOpenType = $vals['svipOpenType'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'VirtualOrderInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readI16($this->status); 
				
			}
			
			
			
			
			if ("channelTag" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->channelTag);
				
			}
			
			
			
			
			if ("orderTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->orderTime); 
				
			}
			
			
			
			
			if ("settledTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->settledTime); 
				
			}
			
			
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("goodsName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsName);
				
			}
			
			
			
			
			if ("goodsThumb" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsThumb);
				
			}
			
			
			
			
			if ("goodsType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->goodsType); 
				
			}
			
			
			
			
			if ("lastUpdateTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->lastUpdateTime); 
				
			}
			
			
			
			
			if ("settled" == $schemeField){
				
				$needSkip = false;
				$input->readI16($this->settled); 
				
			}
			
			
			
			
			if ("selfBuy" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->selfBuy); 
				
			}
			
			
			
			
			if ("orderSubStatusName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSubStatusName);
				
			}
			
			
			
			
			if ("commissionTotalCost" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commissionTotalCost);
				
			}
			
			
			
			
			if ("commission" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commission);
				
			}
			
			
			
			
			if ("commissionRate" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commissionRate);
				
			}
			
			
			
			
			if ("commissionEnterTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->commissionEnterTime); 
				
			}
			
			
			
			
			if ("orderSource" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSource);
				
			}
			
			
			
			
			if ("totalCost" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->totalCost);
				
			}
			
			
			
			
			if ("afterSaleChangeCommission" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->afterSaleChangeCommission);
				
			}
			
			
			
			
			if ("pid" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->pid);
				
			}
			
			
			
			
			if ("statParam" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->statParam);
				
			}
			
			
			
			
			if ("orderTrackReason" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderTrackReason); 
				
			}
			
			
			
			
			if ("appKey" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->appKey);
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("adCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->adCode);
				
			}
			
			
			
			
			if ("refundOrderDetails" == $schemeField){
				
				$needSkip = false;
				
				$this->refundOrderDetails = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\adp\api\open\service\RefundOrderDetail();
						$elem0->read($input);
						
						$this->refundOrderDetails[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("fdsBlackOrder" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->fdsBlackOrder); 
				
			}
			
			
			
			
			if ("svipOpenType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->svipOpenType); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeI16($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->channelTag !== null) {
			
			$xfer += $output->writeFieldBegin('channelTag');
			$xfer += $output->writeString($this->channelTag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderTime !== null) {
			
			$xfer += $output->writeFieldBegin('orderTime');
			$xfer += $output->writeI64($this->orderTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->settledTime !== null) {
			
			$xfer += $output->writeFieldBegin('settledTime');
			$xfer += $output->writeI64($this->settledTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsId');
			$xfer += $output->writeString($this->goodsId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsName !== null) {
			
			$xfer += $output->writeFieldBegin('goodsName');
			$xfer += $output->writeString($this->goodsName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsThumb !== null) {
			
			$xfer += $output->writeFieldBegin('goodsThumb');
			$xfer += $output->writeString($this->goodsThumb);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsType !== null) {
			
			$xfer += $output->writeFieldBegin('goodsType');
			$xfer += $output->writeI32($this->goodsType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->lastUpdateTime !== null) {
			
			$xfer += $output->writeFieldBegin('lastUpdateTime');
			$xfer += $output->writeI64($this->lastUpdateTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->settled !== null) {
			
			$xfer += $output->writeFieldBegin('settled');
			$xfer += $output->writeI16($this->settled);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->selfBuy !== null) {
			
			$xfer += $output->writeFieldBegin('selfBuy');
			$xfer += $output->writeI32($this->selfBuy);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderSubStatusName !== null) {
			
			$xfer += $output->writeFieldBegin('orderSubStatusName');
			$xfer += $output->writeString($this->orderSubStatusName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commissionTotalCost !== null) {
			
			$xfer += $output->writeFieldBegin('commissionTotalCost');
			$xfer += $output->writeString($this->commissionTotalCost);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commission !== null) {
			
			$xfer += $output->writeFieldBegin('commission');
			$xfer += $output->writeString($this->commission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commissionRate !== null) {
			
			$xfer += $output->writeFieldBegin('commissionRate');
			$xfer += $output->writeString($this->commissionRate);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commissionEnterTime !== null) {
			
			$xfer += $output->writeFieldBegin('commissionEnterTime');
			$xfer += $output->writeI64($this->commissionEnterTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderSource !== null) {
			
			$xfer += $output->writeFieldBegin('orderSource');
			$xfer += $output->writeString($this->orderSource);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->totalCost !== null) {
			
			$xfer += $output->writeFieldBegin('totalCost');
			$xfer += $output->writeString($this->totalCost);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleChangeCommission !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleChangeCommission');
			$xfer += $output->writeString($this->afterSaleChangeCommission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->pid !== null) {
			
			$xfer += $output->writeFieldBegin('pid');
			$xfer += $output->writeString($this->pid);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->statParam !== null) {
			
			$xfer += $output->writeFieldBegin('statParam');
			$xfer += $output->writeString($this->statParam);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderTrackReason !== null) {
			
			$xfer += $output->writeFieldBegin('orderTrackReason');
			$xfer += $output->writeI32($this->orderTrackReason);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->appKey !== null) {
			
			$xfer += $output->writeFieldBegin('appKey');
			$xfer += $output->writeString($this->appKey);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->adCode !== null) {
			
			$xfer += $output->writeFieldBegin('adCode');
			$xfer += $output->writeString($this->adCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundOrderDetails !== null) {
			
			$xfer += $output->writeFieldBegin('refundOrderDetails');
			
			if (!is_array($this->refundOrderDetails)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->refundOrderDetails as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->fdsBlackOrder !== null) {
			
			$xfer += $output->writeFieldBegin('fdsBlackOrder');
			$xfer += $output->writeI32($this->fdsBlackOrder);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->svipOpenType !== null) {
			
			$xfer += $output->writeFieldBegin('svipOpenType');
			$xfer += $output->writeI32($this->svipOpenType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>