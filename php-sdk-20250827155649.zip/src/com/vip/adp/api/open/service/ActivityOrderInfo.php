<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class ActivityOrderInfo {
	
	static $_TSPEC;
	public $ucode = null;
	public $openId = null;
	public $orderTime = null;
	public $orderSn = null;
	public $goodsId = null;
	public $goodsSizeId = null;
	public $checkStatus = null;
	public $orderStatus = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'ucode'
			),
			2 => array(
			'var' => 'openId'
			),
			3 => array(
			'var' => 'orderTime'
			),
			4 => array(
			'var' => 'orderSn'
			),
			5 => array(
			'var' => 'goodsId'
			),
			6 => array(
			'var' => 'goodsSizeId'
			),
			7 => array(
			'var' => 'checkStatus'
			),
			8 => array(
			'var' => 'orderStatus'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['ucode'])){
				
				$this->ucode = $vals['ucode'];
			}
			
			
			if (isset($vals['openId'])){
				
				$this->openId = $vals['openId'];
			}
			
			
			if (isset($vals['orderTime'])){
				
				$this->orderTime = $vals['orderTime'];
			}
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['goodsSizeId'])){
				
				$this->goodsSizeId = $vals['goodsSizeId'];
			}
			
			
			if (isset($vals['checkStatus'])){
				
				$this->checkStatus = $vals['checkStatus'];
			}
			
			
			if (isset($vals['orderStatus'])){
				
				$this->orderStatus = $vals['orderStatus'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ActivityOrderInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("ucode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->ucode);
				
			}
			
			
			
			
			if ("openId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->openId);
				
			}
			
			
			
			
			if ("orderTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->orderTime); 
				
			}
			
			
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("goodsSizeId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsSizeId);
				
			}
			
			
			
			
			if ("checkStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->checkStatus); 
				
			}
			
			
			
			
			if ("orderStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderStatus); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->ucode !== null) {
			
			$xfer += $output->writeFieldBegin('ucode');
			$xfer += $output->writeString($this->ucode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->openId !== null) {
			
			$xfer += $output->writeFieldBegin('openId');
			$xfer += $output->writeString($this->openId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderTime !== null) {
			
			$xfer += $output->writeFieldBegin('orderTime');
			$xfer += $output->writeI64($this->orderTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsId');
			$xfer += $output->writeString($this->goodsId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->goodsSizeId !== null) {
			
			$xfer += $output->writeFieldBegin('goodsSizeId');
			$xfer += $output->writeString($this->goodsSizeId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->checkStatus !== null) {
			
			$xfer += $output->writeFieldBegin('checkStatus');
			$xfer += $output->writeI32($this->checkStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderStatus !== null) {
			
			$xfer += $output->writeFieldBegin('orderStatus');
			$xfer += $output->writeI32($this->orderStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>