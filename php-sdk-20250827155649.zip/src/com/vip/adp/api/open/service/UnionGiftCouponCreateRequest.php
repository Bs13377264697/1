<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class UnionGiftCouponCreateRequest {
	
	static $_TSPEC;
	public $requestId = null;
	public $giftName = null;
	public $goodsId = null;
	public $amount = null;
	public $totalCount = null;
	public $activityStartTime = null;
	public $activityEndTime = null;
	public $useTimeType = null;
	public $useStartTime = null;
	public $useEndTime = null;
	public $targetUserTypes = null;
	public $singleClaimPerLink = null;
	public $allSkusUnderProduct = null;
	public $relativeNumber = null;
	public $targetedType = null;
	public $targetedValues = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'requestId'
			),
			2 => array(
			'var' => 'giftName'
			),
			3 => array(
			'var' => 'goodsId'
			),
			4 => array(
			'var' => 'amount'
			),
			5 => array(
			'var' => 'totalCount'
			),
			6 => array(
			'var' => 'activityStartTime'
			),
			7 => array(
			'var' => 'activityEndTime'
			),
			8 => array(
			'var' => 'useTimeType'
			),
			9 => array(
			'var' => 'useStartTime'
			),
			10 => array(
			'var' => 'useEndTime'
			),
			11 => array(
			'var' => 'targetUserTypes'
			),
			12 => array(
			'var' => 'singleClaimPerLink'
			),
			13 => array(
			'var' => 'allSkusUnderProduct'
			),
			14 => array(
			'var' => 'relativeNumber'
			),
			15 => array(
			'var' => 'targetedType'
			),
			16 => array(
			'var' => 'targetedValues'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['requestId'])){
				
				$this->requestId = $vals['requestId'];
			}
			
			
			if (isset($vals['giftName'])){
				
				$this->giftName = $vals['giftName'];
			}
			
			
			if (isset($vals['goodsId'])){
				
				$this->goodsId = $vals['goodsId'];
			}
			
			
			if (isset($vals['amount'])){
				
				$this->amount = $vals['amount'];
			}
			
			
			if (isset($vals['totalCount'])){
				
				$this->totalCount = $vals['totalCount'];
			}
			
			
			if (isset($vals['activityStartTime'])){
				
				$this->activityStartTime = $vals['activityStartTime'];
			}
			
			
			if (isset($vals['activityEndTime'])){
				
				$this->activityEndTime = $vals['activityEndTime'];
			}
			
			
			if (isset($vals['useTimeType'])){
				
				$this->useTimeType = $vals['useTimeType'];
			}
			
			
			if (isset($vals['useStartTime'])){
				
				$this->useStartTime = $vals['useStartTime'];
			}
			
			
			if (isset($vals['useEndTime'])){
				
				$this->useEndTime = $vals['useEndTime'];
			}
			
			
			if (isset($vals['targetUserTypes'])){
				
				$this->targetUserTypes = $vals['targetUserTypes'];
			}
			
			
			if (isset($vals['singleClaimPerLink'])){
				
				$this->singleClaimPerLink = $vals['singleClaimPerLink'];
			}
			
			
			if (isset($vals['allSkusUnderProduct'])){
				
				$this->allSkusUnderProduct = $vals['allSkusUnderProduct'];
			}
			
			
			if (isset($vals['relativeNumber'])){
				
				$this->relativeNumber = $vals['relativeNumber'];
			}
			
			
			if (isset($vals['targetedType'])){
				
				$this->targetedType = $vals['targetedType'];
			}
			
			
			if (isset($vals['targetedValues'])){
				
				$this->targetedValues = $vals['targetedValues'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'UnionGiftCouponCreateRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("requestId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->requestId);
				
			}
			
			
			
			
			if ("giftName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->giftName);
				
			}
			
			
			
			
			if ("goodsId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsId);
				
			}
			
			
			
			
			if ("amount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->amount);
				
			}
			
			
			
			
			if ("totalCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->totalCount); 
				
			}
			
			
			
			
			if ("activityStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->activityStartTime);
				
			}
			
			
			
			
			if ("activityEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->activityEndTime);
				
			}
			
			
			
			
			if ("useTimeType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->useTimeType); 
				
			}
			
			
			
			
			if ("useStartTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useStartTime);
				
			}
			
			
			
			
			if ("useEndTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useEndTime);
				
			}
			
			
			
			
			if ("targetUserTypes" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->targetUserTypes);
				
			}
			
			
			
			
			if ("singleClaimPerLink" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->singleClaimPerLink); 
				
			}
			
			
			
			
			if ("allSkusUnderProduct" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->allSkusUnderProduct); 
				
			}
			
			
			
			
			if ("relativeNumber" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->relativeNumber); 
				
			}
			
			
			
			
			if ("targetedType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->targetedType); 
				
			}
			
			
			
			
			if ("targetedValues" == $schemeField){
				
				$needSkip = false;
				
				$this->targetedValues = array();
				$_size0 = 0;
				$input->readSetBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						$input->readString($elem0);
						
						$this->targetedValues[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readSetEnd();
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('requestId');
		$xfer += $output->writeString($this->requestId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('giftName');
		$xfer += $output->writeString($this->giftName);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('goodsId');
		$xfer += $output->writeString($this->goodsId);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('amount');
		$xfer += $output->writeString($this->amount);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('totalCount');
		$xfer += $output->writeI32($this->totalCount);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('activityStartTime');
		$xfer += $output->writeString($this->activityStartTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('activityEndTime');
		$xfer += $output->writeString($this->activityEndTime);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('useTimeType');
		$xfer += $output->writeI32($this->useTimeType);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->useStartTime !== null) {
			
			$xfer += $output->writeFieldBegin('useStartTime');
			$xfer += $output->writeString($this->useStartTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useEndTime !== null) {
			
			$xfer += $output->writeFieldBegin('useEndTime');
			$xfer += $output->writeString($this->useEndTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetUserTypes !== null) {
			
			$xfer += $output->writeFieldBegin('targetUserTypes');
			$xfer += $output->writeString($this->targetUserTypes);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->singleClaimPerLink !== null) {
			
			$xfer += $output->writeFieldBegin('singleClaimPerLink');
			$xfer += $output->writeI32($this->singleClaimPerLink);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('allSkusUnderProduct');
		$xfer += $output->writeI32($this->allSkusUnderProduct);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->relativeNumber !== null) {
			
			$xfer += $output->writeFieldBegin('relativeNumber');
			$xfer += $output->writeI32($this->relativeNumber);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedType !== null) {
			
			$xfer += $output->writeFieldBegin('targetedType');
			$xfer += $output->writeI32($this->targetedType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->targetedValues !== null) {
			
			$xfer += $output->writeFieldBegin('targetedValues');
			
			if (!is_array($this->targetedValues)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeSetBegin();
			foreach ($this->targetedValues as $iter0){
				
				$xfer += $output->writeString($iter0);
				
			}
			
			$output->writeSetEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>