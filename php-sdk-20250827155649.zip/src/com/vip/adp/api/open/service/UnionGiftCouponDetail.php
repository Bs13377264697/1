<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\api\open\service;

class UnionGiftCouponDetail {
	
	static $_TSPEC;
	public $giftInfo = null;
	public $distributionInfo = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'giftInfo'
			),
			2 => array(
			'var' => 'distributionInfo'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['giftInfo'])){
				
				$this->giftInfo = $vals['giftInfo'];
			}
			
			
			if (isset($vals['distributionInfo'])){
				
				$this->distributionInfo = $vals['distributionInfo'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'UnionGiftCouponDetail';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("giftInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->giftInfo = new \com\vip\adp\api\open\service\UnionGiftInfo();
				$this->giftInfo->read($input);
				
			}
			
			
			
			
			if ("distributionInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->distributionInfo = new \com\vip\adp\api\open\service\UnionDistributionInfo();
				$this->distributionInfo->read($input);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->giftInfo !== null) {
			
			$xfer += $output->writeFieldBegin('giftInfo');
			
			if (!is_object($this->giftInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->giftInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->distributionInfo !== null) {
			
			$xfer += $output->writeFieldBegin('distributionInfo');
			
			if (!is_object($this->distributionInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->distributionInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>