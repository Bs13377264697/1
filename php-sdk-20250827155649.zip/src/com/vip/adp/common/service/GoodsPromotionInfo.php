<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\common\service;

class GoodsPromotionInfo {
	
	static $_TSPEC;
	public $salePrice = null;
	public $marketPrice = null;
	public $discount = null;
	public $svip = null;
	public $salePriceDetail = null;
	public $salePriceDesc = null;
	public $lowPriceTag = null;
	public $pgNewUser = null;
	public $onWayActInfo = null;
	public $futureActInfo = null;
	public $allowancePrice = null;
	public $couponInfos = null;
	public $hiddenCouponInfo = null;
	public $newUserSubsidyFav = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'salePrice'
			),
			2 => array(
			'var' => 'marketPrice'
			),
			3 => array(
			'var' => 'discount'
			),
			4 => array(
			'var' => 'svip'
			),
			5 => array(
			'var' => 'salePriceDetail'
			),
			6 => array(
			'var' => 'salePriceDesc'
			),
			7 => array(
			'var' => 'lowPriceTag'
			),
			8 => array(
			'var' => 'pgNewUser'
			),
			9 => array(
			'var' => 'onWayActInfo'
			),
			10 => array(
			'var' => 'futureActInfo'
			),
			11 => array(
			'var' => 'allowancePrice'
			),
			12 => array(
			'var' => 'couponInfos'
			),
			13 => array(
			'var' => 'hiddenCouponInfo'
			),
			14 => array(
			'var' => 'newUserSubsidyFav'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['salePrice'])){
				
				$this->salePrice = $vals['salePrice'];
			}
			
			
			if (isset($vals['marketPrice'])){
				
				$this->marketPrice = $vals['marketPrice'];
			}
			
			
			if (isset($vals['discount'])){
				
				$this->discount = $vals['discount'];
			}
			
			
			if (isset($vals['svip'])){
				
				$this->svip = $vals['svip'];
			}
			
			
			if (isset($vals['salePriceDetail'])){
				
				$this->salePriceDetail = $vals['salePriceDetail'];
			}
			
			
			if (isset($vals['salePriceDesc'])){
				
				$this->salePriceDesc = $vals['salePriceDesc'];
			}
			
			
			if (isset($vals['lowPriceTag'])){
				
				$this->lowPriceTag = $vals['lowPriceTag'];
			}
			
			
			if (isset($vals['pgNewUser'])){
				
				$this->pgNewUser = $vals['pgNewUser'];
			}
			
			
			if (isset($vals['onWayActInfo'])){
				
				$this->onWayActInfo = $vals['onWayActInfo'];
			}
			
			
			if (isset($vals['futureActInfo'])){
				
				$this->futureActInfo = $vals['futureActInfo'];
			}
			
			
			if (isset($vals['allowancePrice'])){
				
				$this->allowancePrice = $vals['allowancePrice'];
			}
			
			
			if (isset($vals['couponInfos'])){
				
				$this->couponInfos = $vals['couponInfos'];
			}
			
			
			if (isset($vals['hiddenCouponInfo'])){
				
				$this->hiddenCouponInfo = $vals['hiddenCouponInfo'];
			}
			
			
			if (isset($vals['newUserSubsidyFav'])){
				
				$this->newUserSubsidyFav = $vals['newUserSubsidyFav'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'GoodsPromotionInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("salePrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->salePrice);
				
			}
			
			
			
			
			if ("marketPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->marketPrice);
				
			}
			
			
			
			
			if ("discount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->discount);
				
			}
			
			
			
			
			if ("svip" == $schemeField){
				
				$needSkip = false;
				$input->readBool($this->svip);
				
			}
			
			
			
			
			if ("salePriceDetail" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->salePriceDetail);
				
			}
			
			
			
			
			if ("salePriceDesc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->salePriceDesc);
				
			}
			
			
			
			
			if ("lowPriceTag" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->lowPriceTag);
				
			}
			
			
			
			
			if ("pgNewUser" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->pgNewUser);
				
			}
			
			
			
			
			if ("onWayActInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->onWayActInfo = new \com\vip\adp\common\service\OnWayActInfo();
				$this->onWayActInfo->read($input);
				
			}
			
			
			
			
			if ("futureActInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->futureActInfo = new \com\vip\adp\common\service\FutureActInfo();
				$this->futureActInfo->read($input);
				
			}
			
			
			
			
			if ("allowancePrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->allowancePrice);
				
			}
			
			
			
			
			if ("couponInfos" == $schemeField){
				
				$needSkip = false;
				
				$this->couponInfos = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\adp\common\service\PMSCouponInfo();
						$elem0->read($input);
						
						$this->couponInfos[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("hiddenCouponInfo" == $schemeField){
				
				$needSkip = false;
				
				$this->hiddenCouponInfo = new \com\vip\adp\common\service\PMSCouponInfo();
				$this->hiddenCouponInfo->read($input);
				
			}
			
			
			
			
			if ("newUserSubsidyFav" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->newUserSubsidyFav);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->salePrice !== null) {
			
			$xfer += $output->writeFieldBegin('salePrice');
			$xfer += $output->writeString($this->salePrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->marketPrice !== null) {
			
			$xfer += $output->writeFieldBegin('marketPrice');
			$xfer += $output->writeString($this->marketPrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->discount !== null) {
			
			$xfer += $output->writeFieldBegin('discount');
			$xfer += $output->writeString($this->discount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->svip !== null) {
			
			$xfer += $output->writeFieldBegin('svip');
			$xfer += $output->writeBool($this->svip);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->salePriceDetail !== null) {
			
			$xfer += $output->writeFieldBegin('salePriceDetail');
			$xfer += $output->writeString($this->salePriceDetail);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->salePriceDesc !== null) {
			
			$xfer += $output->writeFieldBegin('salePriceDesc');
			$xfer += $output->writeString($this->salePriceDesc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->lowPriceTag !== null) {
			
			$xfer += $output->writeFieldBegin('lowPriceTag');
			$xfer += $output->writeString($this->lowPriceTag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->pgNewUser !== null) {
			
			$xfer += $output->writeFieldBegin('pgNewUser');
			$xfer += $output->writeString($this->pgNewUser);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->onWayActInfo !== null) {
			
			$xfer += $output->writeFieldBegin('onWayActInfo');
			
			if (!is_object($this->onWayActInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->onWayActInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->futureActInfo !== null) {
			
			$xfer += $output->writeFieldBegin('futureActInfo');
			
			if (!is_object($this->futureActInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->futureActInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->allowancePrice !== null) {
			
			$xfer += $output->writeFieldBegin('allowancePrice');
			$xfer += $output->writeString($this->allowancePrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->couponInfos !== null) {
			
			$xfer += $output->writeFieldBegin('couponInfos');
			
			if (!is_array($this->couponInfos)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->couponInfos as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->hiddenCouponInfo !== null) {
			
			$xfer += $output->writeFieldBegin('hiddenCouponInfo');
			
			if (!is_object($this->hiddenCouponInfo)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->hiddenCouponInfo->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->newUserSubsidyFav !== null) {
			
			$xfer += $output->writeFieldBegin('newUserSubsidyFav');
			$xfer += $output->writeString($this->newUserSubsidyFav);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>