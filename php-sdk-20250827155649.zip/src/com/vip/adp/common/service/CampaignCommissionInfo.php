<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\adp\common\service;

class CampaignCommissionInfo {
	
	static $_TSPEC;
	public $isCampaignCommission = null;
	public $campaignCommissionRate = null;
	public $startTime = null;
	public $endTime = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'isCampaignCommission'
			),
			2 => array(
			'var' => 'campaignCommissionRate'
			),
			3 => array(
			'var' => 'startTime'
			),
			4 => array(
			'var' => 'endTime'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['isCampaignCommission'])){
				
				$this->isCampaignCommission = $vals['isCampaignCommission'];
			}
			
			
			if (isset($vals['campaignCommissionRate'])){
				
				$this->campaignCommissionRate = $vals['campaignCommissionRate'];
			}
			
			
			if (isset($vals['startTime'])){
				
				$this->startTime = $vals['startTime'];
			}
			
			
			if (isset($vals['endTime'])){
				
				$this->endTime = $vals['endTime'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CampaignCommissionInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("isCampaignCommission" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isCampaignCommission); 
				
			}
			
			
			
			
			if ("campaignCommissionRate" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->campaignCommissionRate);
				
			}
			
			
			
			
			if ("startTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->startTime); 
				
			}
			
			
			
			
			if ("endTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->endTime); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->isCampaignCommission !== null) {
			
			$xfer += $output->writeFieldBegin('isCampaignCommission');
			$xfer += $output->writeI32($this->isCampaignCommission);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->campaignCommissionRate !== null) {
			
			$xfer += $output->writeFieldBegin('campaignCommissionRate');
			$xfer += $output->writeString($this->campaignCommissionRate);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->startTime !== null) {
			
			$xfer += $output->writeFieldBegin('startTime');
			$xfer += $output->writeI64($this->startTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->endTime !== null) {
			
			$xfer += $output->writeFieldBegin('endTime');
			$xfer += $output->writeI64($this->endTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>