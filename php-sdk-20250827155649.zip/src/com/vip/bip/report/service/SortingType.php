<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\bip\report\service;
final class SortingType{
	
	
	const ASC = 1;
	
	const DESC = 2;
	
	static public $__names = array(
	
	1 => 'ASC',
	
	2 => 'DESC',
	
	);
}

?>