<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class LuckyLotteryCountDataModel {
	
	static $_TSPEC;
	public $currDrawTotalCount = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'currDrawTotalCount'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['currDrawTotalCount'])){
				
				$this->currDrawTotalCount = $vals['currDrawTotalCount'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'LuckyLotteryCountDataModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("currDrawTotalCount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->currDrawTotalCount); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->currDrawTotalCount !== null) {
			
			$xfer += $output->writeFieldBegin('currDrawTotalCount');
			$xfer += $output->writeI32($this->currDrawTotalCount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>