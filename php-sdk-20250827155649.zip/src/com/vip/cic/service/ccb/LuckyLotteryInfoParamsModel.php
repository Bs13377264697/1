<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class LuckyLotteryInfoParamsModel {
	
	static $_TSPEC;
	public $outUId = null;
	public $lotteryLogo = null;
	public $mars_cid = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'outUId'
			),
			2 => array(
			'var' => 'lotteryLogo'
			),
			3 => array(
			'var' => 'mars_cid'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['outUId'])){
				
				$this->outUId = $vals['outUId'];
			}
			
			
			if (isset($vals['lotteryLogo'])){
				
				$this->lotteryLogo = $vals['lotteryLogo'];
			}
			
			
			if (isset($vals['mars_cid'])){
				
				$this->mars_cid = $vals['mars_cid'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'LuckyLotteryInfoParamsModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("outUId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outUId);
				
			}
			
			
			
			
			if ("lotteryLogo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->lotteryLogo);
				
			}
			
			
			
			
			if ("mars_cid" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mars_cid);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->outUId !== null) {
			
			$xfer += $output->writeFieldBegin('outUId');
			$xfer += $output->writeString($this->outUId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->lotteryLogo !== null) {
			
			$xfer += $output->writeFieldBegin('lotteryLogo');
			$xfer += $output->writeString($this->lotteryLogo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->mars_cid !== null) {
			
			$xfer += $output->writeFieldBegin('mars_cid');
			$xfer += $output->writeString($this->mars_cid);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>