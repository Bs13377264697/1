<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class QueryCardStatusDataModel {
	
	static $_TSPEC;
	public $isBind = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'isBind'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['isBind'])){
				
				$this->isBind = $vals['isBind'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'QueryCardStatusDataModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("isBind" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isBind); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->isBind !== null) {
			
			$xfer += $output->writeFieldBegin('isBind');
			$xfer += $output->writeI32($this->isBind);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>