<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class CCBCouponBusinessRequest {
	
	static $_TSPEC;
	public $userId = null;
	public $productId = null;
	public $orderId = null;
	public $retryCnt = null;
	public $num = null;
	public $dccpAvyId = null;
	public $latitude = null;
	public $longitude = null;
	public $userRealIp = null;
	public $paySummary = null;
	public $extrBsnData = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'userId'
			),
			2 => array(
			'var' => 'productId'
			),
			3 => array(
			'var' => 'orderId'
			),
			4 => array(
			'var' => 'retryCnt'
			),
			5 => array(
			'var' => 'num'
			),
			6 => array(
			'var' => 'dccpAvyId'
			),
			7 => array(
			'var' => 'latitude'
			),
			8 => array(
			'var' => 'longitude'
			),
			9 => array(
			'var' => 'userRealIp'
			),
			10 => array(
			'var' => 'paySummary'
			),
			11 => array(
			'var' => 'extrBsnData'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['userId'])){
				
				$this->userId = $vals['userId'];
			}
			
			
			if (isset($vals['productId'])){
				
				$this->productId = $vals['productId'];
			}
			
			
			if (isset($vals['orderId'])){
				
				$this->orderId = $vals['orderId'];
			}
			
			
			if (isset($vals['retryCnt'])){
				
				$this->retryCnt = $vals['retryCnt'];
			}
			
			
			if (isset($vals['num'])){
				
				$this->num = $vals['num'];
			}
			
			
			if (isset($vals['dccpAvyId'])){
				
				$this->dccpAvyId = $vals['dccpAvyId'];
			}
			
			
			if (isset($vals['latitude'])){
				
				$this->latitude = $vals['latitude'];
			}
			
			
			if (isset($vals['longitude'])){
				
				$this->longitude = $vals['longitude'];
			}
			
			
			if (isset($vals['userRealIp'])){
				
				$this->userRealIp = $vals['userRealIp'];
			}
			
			
			if (isset($vals['paySummary'])){
				
				$this->paySummary = $vals['paySummary'];
			}
			
			
			if (isset($vals['extrBsnData'])){
				
				$this->extrBsnData = $vals['extrBsnData'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CCBCouponBusinessRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("userId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->userId);
				
			}
			
			
			
			
			if ("productId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->productId);
				
			}
			
			
			
			
			if ("orderId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderId);
				
			}
			
			
			
			
			if ("retryCnt" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->retryCnt); 
				
			}
			
			
			
			
			if ("num" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->num); 
				
			}
			
			
			
			
			if ("dccpAvyId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->dccpAvyId);
				
			}
			
			
			
			
			if ("latitude" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->latitude);
				
			}
			
			
			
			
			if ("longitude" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->longitude);
				
			}
			
			
			
			
			if ("userRealIp" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->userRealIp);
				
			}
			
			
			
			
			if ("paySummary" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->paySummary);
				
			}
			
			
			
			
			if ("extrBsnData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extrBsnData);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->userId !== null) {
			
			$xfer += $output->writeFieldBegin('userId');
			$xfer += $output->writeString($this->userId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->productId !== null) {
			
			$xfer += $output->writeFieldBegin('productId');
			$xfer += $output->writeString($this->productId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderId !== null) {
			
			$xfer += $output->writeFieldBegin('orderId');
			$xfer += $output->writeString($this->orderId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->retryCnt !== null) {
			
			$xfer += $output->writeFieldBegin('retryCnt');
			$xfer += $output->writeI32($this->retryCnt);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->num !== null) {
			
			$xfer += $output->writeFieldBegin('num');
			$xfer += $output->writeI32($this->num);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->dccpAvyId !== null) {
			
			$xfer += $output->writeFieldBegin('dccpAvyId');
			$xfer += $output->writeString($this->dccpAvyId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->latitude !== null) {
			
			$xfer += $output->writeFieldBegin('latitude');
			$xfer += $output->writeString($this->latitude);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->longitude !== null) {
			
			$xfer += $output->writeFieldBegin('longitude');
			$xfer += $output->writeString($this->longitude);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->userRealIp !== null) {
			
			$xfer += $output->writeFieldBegin('userRealIp');
			$xfer += $output->writeString($this->userRealIp);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->paySummary !== null) {
			
			$xfer += $output->writeFieldBegin('paySummary');
			$xfer += $output->writeString($this->paySummary);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extrBsnData !== null) {
			
			$xfer += $output->writeFieldBegin('extrBsnData');
			$xfer += $output->writeString($this->extrBsnData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>