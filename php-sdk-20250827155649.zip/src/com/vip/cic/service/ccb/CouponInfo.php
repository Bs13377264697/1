<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class CouponInfo {
	
	static $_TSPEC;
	public $couponCode = null;
	public $password = null;
	public $verfCode = null;
	public $link = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'couponCode'
			),
			2 => array(
			'var' => 'password'
			),
			3 => array(
			'var' => 'verfCode'
			),
			4 => array(
			'var' => 'link'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['couponCode'])){
				
				$this->couponCode = $vals['couponCode'];
			}
			
			
			if (isset($vals['password'])){
				
				$this->password = $vals['password'];
			}
			
			
			if (isset($vals['verfCode'])){
				
				$this->verfCode = $vals['verfCode'];
			}
			
			
			if (isset($vals['link'])){
				
				$this->link = $vals['link'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CouponInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("couponCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->couponCode);
				
			}
			
			
			
			
			if ("password" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->password);
				
			}
			
			
			
			
			if ("verfCode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->verfCode);
				
			}
			
			
			
			
			if ("link" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->link);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->couponCode !== null) {
			
			$xfer += $output->writeFieldBegin('couponCode');
			$xfer += $output->writeString($this->couponCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->password !== null) {
			
			$xfer += $output->writeFieldBegin('password');
			$xfer += $output->writeString($this->password);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->verfCode !== null) {
			
			$xfer += $output->writeFieldBegin('verfCode');
			$xfer += $output->writeString($this->verfCode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->link !== null) {
			
			$xfer += $output->writeFieldBegin('link');
			$xfer += $output->writeString($this->link);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>