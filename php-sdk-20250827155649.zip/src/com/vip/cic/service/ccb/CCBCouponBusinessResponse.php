<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\ccb;

class CCBCouponBusinessResponse {
	
	static $_TSPEC;
	public $code = null;
	public $msg = null;
	public $orderId = null;
	public $asynFlag = null;
	public $respFlag = null;
	public $useType = null;
	public $completeTm = null;
	public $coupons = null;
	public $status = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'code'
			),
			2 => array(
			'var' => 'msg'
			),
			4 => array(
			'var' => 'orderId'
			),
			5 => array(
			'var' => 'asynFlag'
			),
			6 => array(
			'var' => 'respFlag'
			),
			7 => array(
			'var' => 'useType'
			),
			8 => array(
			'var' => 'completeTm'
			),
			9 => array(
			'var' => 'coupons'
			),
			10 => array(
			'var' => 'status'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['code'])){
				
				$this->code = $vals['code'];
			}
			
			
			if (isset($vals['msg'])){
				
				$this->msg = $vals['msg'];
			}
			
			
			if (isset($vals['orderId'])){
				
				$this->orderId = $vals['orderId'];
			}
			
			
			if (isset($vals['asynFlag'])){
				
				$this->asynFlag = $vals['asynFlag'];
			}
			
			
			if (isset($vals['respFlag'])){
				
				$this->respFlag = $vals['respFlag'];
			}
			
			
			if (isset($vals['useType'])){
				
				$this->useType = $vals['useType'];
			}
			
			
			if (isset($vals['completeTm'])){
				
				$this->completeTm = $vals['completeTm'];
			}
			
			
			if (isset($vals['coupons'])){
				
				$this->coupons = $vals['coupons'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CCBCouponBusinessResponse';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("code" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->code);
				
			}
			
			
			
			
			if ("msg" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->msg);
				
			}
			
			
			
			
			if ("orderId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderId);
				
			}
			
			
			
			
			if ("asynFlag" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->asynFlag);
				
			}
			
			
			
			
			if ("respFlag" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->respFlag);
				
			}
			
			
			
			
			if ("useType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->useType);
				
			}
			
			
			
			
			if ("completeTm" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->completeTm);
				
			}
			
			
			
			
			if ("coupons" == $schemeField){
				
				$needSkip = false;
				
				$this->coupons = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cic\service\ccb\CouponInfo();
						$elem0->read($input);
						
						$this->coupons[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->status);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->code !== null) {
			
			$xfer += $output->writeFieldBegin('code');
			$xfer += $output->writeString($this->code);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->msg !== null) {
			
			$xfer += $output->writeFieldBegin('msg');
			$xfer += $output->writeString($this->msg);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderId !== null) {
			
			$xfer += $output->writeFieldBegin('orderId');
			$xfer += $output->writeString($this->orderId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->asynFlag !== null) {
			
			$xfer += $output->writeFieldBegin('asynFlag');
			$xfer += $output->writeString($this->asynFlag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->respFlag !== null) {
			
			$xfer += $output->writeFieldBegin('respFlag');
			$xfer += $output->writeString($this->respFlag);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->useType !== null) {
			
			$xfer += $output->writeFieldBegin('useType');
			$xfer += $output->writeString($this->useType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->completeTm !== null) {
			
			$xfer += $output->writeFieldBegin('completeTm');
			$xfer += $output->writeString($this->completeTm);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->coupons !== null) {
			
			$xfer += $output->writeFieldBegin('coupons');
			
			if (!is_array($this->coupons)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->coupons as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeString($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>