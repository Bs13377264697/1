<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\tradeIn;

class TradeInNotifyOrderStatusChangeRequest {
	
	static $_TSPEC;
	public $act_id = null;
	public $mobile = null;
	public $order_no = null;
	public $status = null;
	public $enum_status = null;
	public $user_id = null;
	public $created_at = null;
	public $updated_at = null;
	public $completed_at = null;
	public $submited_amount = null;
	public $inspection_amount = null;
	public $final_amount = null;
	public $coop_coupon_price = null;
	public $payment_type = null;
	public $product_name = null;
	public $sku_name = null;
	public $category_name = null;
	public $brand_name = null;
	public $coop_subsidy = null;
	public $request_id = null;
	public $timestamp = null;
	public $sign = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'act_id'
			),
			2 => array(
			'var' => 'mobile'
			),
			3 => array(
			'var' => 'order_no'
			),
			4 => array(
			'var' => 'status'
			),
			5 => array(
			'var' => 'enum_status'
			),
			6 => array(
			'var' => 'user_id'
			),
			7 => array(
			'var' => 'created_at'
			),
			8 => array(
			'var' => 'updated_at'
			),
			9 => array(
			'var' => 'completed_at'
			),
			10 => array(
			'var' => 'submited_amount'
			),
			11 => array(
			'var' => 'inspection_amount'
			),
			12 => array(
			'var' => 'final_amount'
			),
			13 => array(
			'var' => 'coop_coupon_price'
			),
			14 => array(
			'var' => 'payment_type'
			),
			15 => array(
			'var' => 'product_name'
			),
			16 => array(
			'var' => 'sku_name'
			),
			17 => array(
			'var' => 'category_name'
			),
			18 => array(
			'var' => 'brand_name'
			),
			19 => array(
			'var' => 'coop_subsidy'
			),
			20 => array(
			'var' => 'request_id'
			),
			21 => array(
			'var' => 'timestamp'
			),
			22 => array(
			'var' => 'sign'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['act_id'])){
				
				$this->act_id = $vals['act_id'];
			}
			
			
			if (isset($vals['mobile'])){
				
				$this->mobile = $vals['mobile'];
			}
			
			
			if (isset($vals['order_no'])){
				
				$this->order_no = $vals['order_no'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
			if (isset($vals['enum_status'])){
				
				$this->enum_status = $vals['enum_status'];
			}
			
			
			if (isset($vals['user_id'])){
				
				$this->user_id = $vals['user_id'];
			}
			
			
			if (isset($vals['created_at'])){
				
				$this->created_at = $vals['created_at'];
			}
			
			
			if (isset($vals['updated_at'])){
				
				$this->updated_at = $vals['updated_at'];
			}
			
			
			if (isset($vals['completed_at'])){
				
				$this->completed_at = $vals['completed_at'];
			}
			
			
			if (isset($vals['submited_amount'])){
				
				$this->submited_amount = $vals['submited_amount'];
			}
			
			
			if (isset($vals['inspection_amount'])){
				
				$this->inspection_amount = $vals['inspection_amount'];
			}
			
			
			if (isset($vals['final_amount'])){
				
				$this->final_amount = $vals['final_amount'];
			}
			
			
			if (isset($vals['coop_coupon_price'])){
				
				$this->coop_coupon_price = $vals['coop_coupon_price'];
			}
			
			
			if (isset($vals['payment_type'])){
				
				$this->payment_type = $vals['payment_type'];
			}
			
			
			if (isset($vals['product_name'])){
				
				$this->product_name = $vals['product_name'];
			}
			
			
			if (isset($vals['sku_name'])){
				
				$this->sku_name = $vals['sku_name'];
			}
			
			
			if (isset($vals['category_name'])){
				
				$this->category_name = $vals['category_name'];
			}
			
			
			if (isset($vals['brand_name'])){
				
				$this->brand_name = $vals['brand_name'];
			}
			
			
			if (isset($vals['coop_subsidy'])){
				
				$this->coop_subsidy = $vals['coop_subsidy'];
			}
			
			
			if (isset($vals['request_id'])){
				
				$this->request_id = $vals['request_id'];
			}
			
			
			if (isset($vals['timestamp'])){
				
				$this->timestamp = $vals['timestamp'];
			}
			
			
			if (isset($vals['sign'])){
				
				$this->sign = $vals['sign'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'TradeInNotifyOrderStatusChangeRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("act_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->act_id);
				
			}
			
			
			
			
			if ("mobile" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mobile);
				
			}
			
			
			
			
			if ("order_no" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->order_no);
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->status);
				
			}
			
			
			
			
			if ("enum_status" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->enum_status); 
				
			}
			
			
			
			
			if ("user_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->user_id);
				
			}
			
			
			
			
			if ("created_at" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->created_at);
				
			}
			
			
			
			
			if ("updated_at" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->updated_at);
				
			}
			
			
			
			
			if ("completed_at" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->completed_at);
				
			}
			
			
			
			
			if ("submited_amount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->submited_amount); 
				
			}
			
			
			
			
			if ("inspection_amount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->inspection_amount); 
				
			}
			
			
			
			
			if ("final_amount" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->final_amount); 
				
			}
			
			
			
			
			if ("coop_coupon_price" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->coop_coupon_price); 
				
			}
			
			
			
			
			if ("payment_type" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->payment_type); 
				
			}
			
			
			
			
			if ("product_name" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->product_name);
				
			}
			
			
			
			
			if ("sku_name" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->sku_name);
				
			}
			
			
			
			
			if ("category_name" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->category_name);
				
			}
			
			
			
			
			if ("brand_name" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_name);
				
			}
			
			
			
			
			if ("coop_subsidy" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->coop_subsidy); 
				
			}
			
			
			
			
			if ("request_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->request_id);
				
			}
			
			
			
			
			if ("timestamp" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->timestamp); 
				
			}
			
			
			
			
			if ("sign" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->sign);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->act_id !== null) {
			
			$xfer += $output->writeFieldBegin('act_id');
			$xfer += $output->writeString($this->act_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->mobile !== null) {
			
			$xfer += $output->writeFieldBegin('mobile');
			$xfer += $output->writeString($this->mobile);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->order_no !== null) {
			
			$xfer += $output->writeFieldBegin('order_no');
			$xfer += $output->writeString($this->order_no);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeString($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->enum_status !== null) {
			
			$xfer += $output->writeFieldBegin('enum_status');
			$xfer += $output->writeI32($this->enum_status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->user_id !== null) {
			
			$xfer += $output->writeFieldBegin('user_id');
			$xfer += $output->writeString($this->user_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->created_at !== null) {
			
			$xfer += $output->writeFieldBegin('created_at');
			$xfer += $output->writeI64($this->created_at);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->updated_at !== null) {
			
			$xfer += $output->writeFieldBegin('updated_at');
			$xfer += $output->writeI64($this->updated_at);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->completed_at !== null) {
			
			$xfer += $output->writeFieldBegin('completed_at');
			$xfer += $output->writeI64($this->completed_at);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->submited_amount !== null) {
			
			$xfer += $output->writeFieldBegin('submited_amount');
			$xfer += $output->writeI32($this->submited_amount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->inspection_amount !== null) {
			
			$xfer += $output->writeFieldBegin('inspection_amount');
			$xfer += $output->writeI32($this->inspection_amount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->final_amount !== null) {
			
			$xfer += $output->writeFieldBegin('final_amount');
			$xfer += $output->writeI32($this->final_amount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->coop_coupon_price !== null) {
			
			$xfer += $output->writeFieldBegin('coop_coupon_price');
			$xfer += $output->writeI32($this->coop_coupon_price);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->payment_type !== null) {
			
			$xfer += $output->writeFieldBegin('payment_type');
			$xfer += $output->writeI32($this->payment_type);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->product_name !== null) {
			
			$xfer += $output->writeFieldBegin('product_name');
			$xfer += $output->writeString($this->product_name);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sku_name !== null) {
			
			$xfer += $output->writeFieldBegin('sku_name');
			$xfer += $output->writeString($this->sku_name);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->category_name !== null) {
			
			$xfer += $output->writeFieldBegin('category_name');
			$xfer += $output->writeString($this->category_name);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brand_name !== null) {
			
			$xfer += $output->writeFieldBegin('brand_name');
			$xfer += $output->writeString($this->brand_name);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->coop_subsidy !== null) {
			
			$xfer += $output->writeFieldBegin('coop_subsidy');
			$xfer += $output->writeI32($this->coop_subsidy);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->request_id !== null) {
			
			$xfer += $output->writeFieldBegin('request_id');
			$xfer += $output->writeString($this->request_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->timestamp !== null) {
			
			$xfer += $output->writeFieldBegin('timestamp');
			$xfer += $output->writeI32($this->timestamp);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->sign !== null) {
			
			$xfer += $output->writeFieldBegin('sign');
			$xfer += $output->writeString($this->sign);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>