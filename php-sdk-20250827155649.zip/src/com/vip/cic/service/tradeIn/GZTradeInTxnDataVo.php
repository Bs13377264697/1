<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\tradeIn;

class GZTradeInTxnDataVo {
	
	static $_TSPEC;
	public $orderSn = null;
	public $txnNumber = null;
	public $merchantName = null;
	public $txnTm = null;
	public $txnType = null;
	public $txnAmt = null;
	public $goodsCategory = null;
	public $goodsEnergyLevel = null;
	public $subsidyAmt = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderSn'
			),
			2 => array(
			'var' => 'txnNumber'
			),
			3 => array(
			'var' => 'merchantName'
			),
			4 => array(
			'var' => 'txnTm'
			),
			5 => array(
			'var' => 'txnType'
			),
			6 => array(
			'var' => 'txnAmt'
			),
			7 => array(
			'var' => 'goodsCategory'
			),
			8 => array(
			'var' => 'goodsEnergyLevel'
			),
			9 => array(
			'var' => 'subsidyAmt'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['txnNumber'])){
				
				$this->txnNumber = $vals['txnNumber'];
			}
			
			
			if (isset($vals['merchantName'])){
				
				$this->merchantName = $vals['merchantName'];
			}
			
			
			if (isset($vals['txnTm'])){
				
				$this->txnTm = $vals['txnTm'];
			}
			
			
			if (isset($vals['txnType'])){
				
				$this->txnType = $vals['txnType'];
			}
			
			
			if (isset($vals['txnAmt'])){
				
				$this->txnAmt = $vals['txnAmt'];
			}
			
			
			if (isset($vals['goodsCategory'])){
				
				$this->goodsCategory = $vals['goodsCategory'];
			}
			
			
			if (isset($vals['goodsEnergyLevel'])){
				
				$this->goodsEnergyLevel = $vals['goodsEnergyLevel'];
			}
			
			
			if (isset($vals['subsidyAmt'])){
				
				$this->subsidyAmt = $vals['subsidyAmt'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'GZTradeInTxnDataVo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("txnNumber" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->txnNumber);
				
			}
			
			
			
			
			if ("merchantName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->merchantName);
				
			}
			
			
			
			
			if ("txnTm" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->txnTm);
				
			}
			
			
			
			
			if ("txnType" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->txnType);
				
			}
			
			
			
			
			if ("txnAmt" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->txnAmt);
				
			}
			
			
			
			
			if ("goodsCategory" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsCategory);
				
			}
			
			
			
			
			if ("goodsEnergyLevel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->goodsEnergyLevel);
				
			}
			
			
			
			
			if ("subsidyAmt" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->subsidyAmt);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('orderSn');
		$xfer += $output->writeString($this->orderSn);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('txnNumber');
		$xfer += $output->writeString($this->txnNumber);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('merchantName');
		$xfer += $output->writeString($this->merchantName);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('txnTm');
		$xfer += $output->writeString($this->txnTm);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('txnType');
		$xfer += $output->writeString($this->txnType);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('txnAmt');
		$xfer += $output->writeString($this->txnAmt);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('goodsCategory');
		$xfer += $output->writeString($this->goodsCategory);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('goodsEnergyLevel');
		$xfer += $output->writeString($this->goodsEnergyLevel);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('subsidyAmt');
		$xfer += $output->writeString($this->subsidyAmt);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>