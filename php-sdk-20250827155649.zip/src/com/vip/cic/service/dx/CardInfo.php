<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class CardInfo {
	
	static $_TSPEC;
	public $cardNo = null;
	public $cardPwd = null;
	public $codeUrl = null;
	public $expireTime = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'cardNo'
			),
			2 => array(
			'var' => 'cardPwd'
			),
			3 => array(
			'var' => 'codeUrl'
			),
			4 => array(
			'var' => 'expireTime'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['cardNo'])){
				
				$this->cardNo = $vals['cardNo'];
			}
			
			
			if (isset($vals['cardPwd'])){
				
				$this->cardPwd = $vals['cardPwd'];
			}
			
			
			if (isset($vals['codeUrl'])){
				
				$this->codeUrl = $vals['codeUrl'];
			}
			
			
			if (isset($vals['expireTime'])){
				
				$this->expireTime = $vals['expireTime'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CardInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("cardNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->cardNo);
				
			}
			
			
			
			
			if ("cardPwd" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->cardPwd);
				
			}
			
			
			
			
			if ("codeUrl" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->codeUrl);
				
			}
			
			
			
			
			if ("expireTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->expireTime);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->cardNo !== null) {
			
			$xfer += $output->writeFieldBegin('cardNo');
			$xfer += $output->writeString($this->cardNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cardPwd !== null) {
			
			$xfer += $output->writeFieldBegin('cardPwd');
			$xfer += $output->writeString($this->cardPwd);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->codeUrl !== null) {
			
			$xfer += $output->writeFieldBegin('codeUrl');
			$xfer += $output->writeString($this->codeUrl);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->expireTime !== null) {
			
			$xfer += $output->writeFieldBegin('expireTime');
			$xfer += $output->writeString($this->expireTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>