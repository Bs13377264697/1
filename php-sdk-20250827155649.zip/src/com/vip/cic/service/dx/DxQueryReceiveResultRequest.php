<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class DxQueryReceiveResultRequest {
	
	static $_TSPEC;
	public $appId = null;
	public $reqMilTime = null;
	public $orderId = null;
	public $buyNum = null;
	public $extendAttrs = null;
	public $signData = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'appId'
			),
			2 => array(
			'var' => 'reqMilTime'
			),
			3 => array(
			'var' => 'orderId'
			),
			4 => array(
			'var' => 'buyNum'
			),
			5 => array(
			'var' => 'extendAttrs'
			),
			6 => array(
			'var' => 'signData'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['appId'])){
				
				$this->appId = $vals['appId'];
			}
			
			
			if (isset($vals['reqMilTime'])){
				
				$this->reqMilTime = $vals['reqMilTime'];
			}
			
			
			if (isset($vals['orderId'])){
				
				$this->orderId = $vals['orderId'];
			}
			
			
			if (isset($vals['buyNum'])){
				
				$this->buyNum = $vals['buyNum'];
			}
			
			
			if (isset($vals['extendAttrs'])){
				
				$this->extendAttrs = $vals['extendAttrs'];
			}
			
			
			if (isset($vals['signData'])){
				
				$this->signData = $vals['signData'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'DxQueryReceiveResultRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("appId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->appId);
				
			}
			
			
			
			
			if ("reqMilTime" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->reqMilTime);
				
			}
			
			
			
			
			if ("orderId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderId);
				
			}
			
			
			
			
			if ("buyNum" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->buyNum);
				
			}
			
			
			
			
			if ("extendAttrs" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->extendAttrs);
				
			}
			
			
			
			
			if ("signData" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->signData);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->appId !== null) {
			
			$xfer += $output->writeFieldBegin('appId');
			$xfer += $output->writeString($this->appId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->reqMilTime !== null) {
			
			$xfer += $output->writeFieldBegin('reqMilTime');
			$xfer += $output->writeString($this->reqMilTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderId !== null) {
			
			$xfer += $output->writeFieldBegin('orderId');
			$xfer += $output->writeString($this->orderId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->buyNum !== null) {
			
			$xfer += $output->writeFieldBegin('buyNum');
			$xfer += $output->writeString($this->buyNum);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->extendAttrs !== null) {
			
			$xfer += $output->writeFieldBegin('extendAttrs');
			$xfer += $output->writeString($this->extendAttrs);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->signData !== null) {
			
			$xfer += $output->writeFieldBegin('signData');
			$xfer += $output->writeString($this->signData);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>