<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class DxReceiveAwardResponse {
	
	static $_TSPEC;
	public $code = null;
	public $errorcode = null;
	public $errormsg = null;
	public $data = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'code'
			),
			2 => array(
			'var' => 'errorcode'
			),
			3 => array(
			'var' => 'errormsg'
			),
			4 => array(
			'var' => 'data'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['code'])){
				
				$this->code = $vals['code'];
			}
			
			
			if (isset($vals['errorcode'])){
				
				$this->errorcode = $vals['errorcode'];
			}
			
			
			if (isset($vals['errormsg'])){
				
				$this->errormsg = $vals['errormsg'];
			}
			
			
			if (isset($vals['data'])){
				
				$this->data = $vals['data'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'DxReceiveAwardResponse';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("code" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->code);
				
			}
			
			
			
			
			if ("errorcode" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->errorcode);
				
			}
			
			
			
			
			if ("errormsg" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->errormsg);
				
			}
			
			
			
			
			if ("data" == $schemeField){
				
				$needSkip = false;
				
				$this->data = new \com\vip\cic\service\dx\ExpressResult();
				$this->data->read($input);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->code !== null) {
			
			$xfer += $output->writeFieldBegin('code');
			$xfer += $output->writeString($this->code);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->errorcode !== null) {
			
			$xfer += $output->writeFieldBegin('errorcode');
			$xfer += $output->writeString($this->errorcode);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->errormsg !== null) {
			
			$xfer += $output->writeFieldBegin('errormsg');
			$xfer += $output->writeString($this->errormsg);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->data !== null) {
			
			$xfer += $output->writeFieldBegin('data');
			
			if (!is_object($this->data)) {
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$xfer += $this->data->write($output);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>