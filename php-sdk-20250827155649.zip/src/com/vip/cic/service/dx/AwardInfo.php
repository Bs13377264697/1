<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class AwardInfo {
	
	static $_TSPEC;
	public $awardNo = null;
	public $isHaveStock = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'awardNo'
			),
			2 => array(
			'var' => 'isHaveStock'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['awardNo'])){
				
				$this->awardNo = $vals['awardNo'];
			}
			
			
			if (isset($vals['isHaveStock'])){
				
				$this->isHaveStock = $vals['isHaveStock'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'AwardInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("awardNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->awardNo);
				
			}
			
			
			
			
			if ("isHaveStock" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isHaveStock); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->awardNo !== null) {
			
			$xfer += $output->writeFieldBegin('awardNo');
			$xfer += $output->writeString($this->awardNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isHaveStock !== null) {
			
			$xfer += $output->writeFieldBegin('isHaveStock');
			$xfer += $output->writeI32($this->isHaveStock);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>