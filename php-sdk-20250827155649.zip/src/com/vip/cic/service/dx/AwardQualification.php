<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class AwardQualification {
	
	static $_TSPEC;
	public $awardType = null;
	public $isFds = null;
	public $isAlreadyGet = null;
	public $awardInfoList = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'awardType'
			),
			2 => array(
			'var' => 'isFds'
			),
			3 => array(
			'var' => 'isAlreadyGet'
			),
			4 => array(
			'var' => 'awardInfoList'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['awardType'])){
				
				$this->awardType = $vals['awardType'];
			}
			
			
			if (isset($vals['isFds'])){
				
				$this->isFds = $vals['isFds'];
			}
			
			
			if (isset($vals['isAlreadyGet'])){
				
				$this->isAlreadyGet = $vals['isAlreadyGet'];
			}
			
			
			if (isset($vals['awardInfoList'])){
				
				$this->awardInfoList = $vals['awardInfoList'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'AwardQualification';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("awardType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->awardType); 
				
			}
			
			
			
			
			if ("isFds" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isFds); 
				
			}
			
			
			
			
			if ("isAlreadyGet" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->isAlreadyGet); 
				
			}
			
			
			
			
			if ("awardInfoList" == $schemeField){
				
				$needSkip = false;
				
				$this->awardInfoList = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cic\service\dx\AwardInfo();
						$elem0->read($input);
						
						$this->awardInfoList[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->awardType !== null) {
			
			$xfer += $output->writeFieldBegin('awardType');
			$xfer += $output->writeI32($this->awardType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isFds !== null) {
			
			$xfer += $output->writeFieldBegin('isFds');
			$xfer += $output->writeI32($this->isFds);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isAlreadyGet !== null) {
			
			$xfer += $output->writeFieldBegin('isAlreadyGet');
			$xfer += $output->writeI32($this->isAlreadyGet);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->awardInfoList !== null) {
			
			$xfer += $output->writeFieldBegin('awardInfoList');
			
			if (!is_array($this->awardInfoList)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->awardInfoList as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>