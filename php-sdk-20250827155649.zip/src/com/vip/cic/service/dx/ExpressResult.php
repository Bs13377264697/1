<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\dx;

class ExpressResult {
	
	static $_TSPEC;
	public $orderId = null;
	public $resultId = null;
	public $cardInfos = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderId'
			),
			2 => array(
			'var' => 'resultId'
			),
			3 => array(
			'var' => 'cardInfos'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderId'])){
				
				$this->orderId = $vals['orderId'];
			}
			
			
			if (isset($vals['resultId'])){
				
				$this->resultId = $vals['resultId'];
			}
			
			
			if (isset($vals['cardInfos'])){
				
				$this->cardInfos = $vals['cardInfos'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ExpressResult';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderId);
				
			}
			
			
			
			
			if ("resultId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->resultId);
				
			}
			
			
			
			
			if ("cardInfos" == $schemeField){
				
				$needSkip = false;
				
				$this->cardInfos = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cic\service\dx\CardInfo();
						$elem0->read($input);
						
						$this->cardInfos[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderId !== null) {
			
			$xfer += $output->writeFieldBegin('orderId');
			$xfer += $output->writeString($this->orderId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->resultId !== null) {
			
			$xfer += $output->writeFieldBegin('resultId');
			$xfer += $output->writeString($this->resultId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->cardInfos !== null) {
			
			$xfer += $output->writeFieldBegin('cardInfos');
			
			if (!is_array($this->cardInfos)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->cardInfos as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>