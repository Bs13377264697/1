<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\df;

class QueryRefundOrderDetailParamsModel {
	
	static $_TSPEC;
	public $outRefundNo = null;
	public $channel = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'outRefundNo'
			),
			2 => array(
			'var' => 'channel'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['outRefundNo'])){
				
				$this->outRefundNo = $vals['outRefundNo'];
			}
			
			
			if (isset($vals['channel'])){
				
				$this->channel = $vals['channel'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'QueryRefundOrderDetailParamsModel';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("outRefundNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outRefundNo);
				
			}
			
			
			
			
			if ("channel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->channel);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('outRefundNo');
		$xfer += $output->writeString($this->outRefundNo);
		
		$xfer += $output->writeFieldEnd();
		
		if($this->channel !== null) {
			
			$xfer += $output->writeFieldBegin('channel');
			$xfer += $output->writeString($this->channel);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>