<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\df;

class RefundCommodityInfo {
	
	static $_TSPEC;
	public $commoditySizeId = null;
	public $commodityName = null;
	public $commodityPictureUrl = null;
	public $commodityPrice = null;
	public $commodityRefundAmount = null;
	public $refundNum = null;
	public $commodityTotalRefundAmount = null;
	public $firstCategoryName = null;
	public $secondCategoryName = null;
	public $thirdCategoryName = null;
	public $brandNameCn = null;
	public $brandNameEn = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'commoditySizeId'
			),
			2 => array(
			'var' => 'commodityName'
			),
			3 => array(
			'var' => 'commodityPictureUrl'
			),
			4 => array(
			'var' => 'commodityPrice'
			),
			5 => array(
			'var' => 'commodityRefundAmount'
			),
			6 => array(
			'var' => 'refundNum'
			),
			7 => array(
			'var' => 'commodityTotalRefundAmount'
			),
			8 => array(
			'var' => 'firstCategoryName'
			),
			9 => array(
			'var' => 'secondCategoryName'
			),
			10 => array(
			'var' => 'thirdCategoryName'
			),
			11 => array(
			'var' => 'brandNameCn'
			),
			12 => array(
			'var' => 'brandNameEn'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['commoditySizeId'])){
				
				$this->commoditySizeId = $vals['commoditySizeId'];
			}
			
			
			if (isset($vals['commodityName'])){
				
				$this->commodityName = $vals['commodityName'];
			}
			
			
			if (isset($vals['commodityPictureUrl'])){
				
				$this->commodityPictureUrl = $vals['commodityPictureUrl'];
			}
			
			
			if (isset($vals['commodityPrice'])){
				
				$this->commodityPrice = $vals['commodityPrice'];
			}
			
			
			if (isset($vals['commodityRefundAmount'])){
				
				$this->commodityRefundAmount = $vals['commodityRefundAmount'];
			}
			
			
			if (isset($vals['refundNum'])){
				
				$this->refundNum = $vals['refundNum'];
			}
			
			
			if (isset($vals['commodityTotalRefundAmount'])){
				
				$this->commodityTotalRefundAmount = $vals['commodityTotalRefundAmount'];
			}
			
			
			if (isset($vals['firstCategoryName'])){
				
				$this->firstCategoryName = $vals['firstCategoryName'];
			}
			
			
			if (isset($vals['secondCategoryName'])){
				
				$this->secondCategoryName = $vals['secondCategoryName'];
			}
			
			
			if (isset($vals['thirdCategoryName'])){
				
				$this->thirdCategoryName = $vals['thirdCategoryName'];
			}
			
			
			if (isset($vals['brandNameCn'])){
				
				$this->brandNameCn = $vals['brandNameCn'];
			}
			
			
			if (isset($vals['brandNameEn'])){
				
				$this->brandNameEn = $vals['brandNameEn'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'RefundCommodityInfo';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("commoditySizeId" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commoditySizeId);
				
			}
			
			
			
			
			if ("commodityName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityName);
				
			}
			
			
			
			
			if ("commodityPictureUrl" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityPictureUrl);
				
			}
			
			
			
			
			if ("commodityPrice" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityPrice);
				
			}
			
			
			
			
			if ("commodityRefundAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityRefundAmount);
				
			}
			
			
			
			
			if ("refundNum" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundNum);
				
			}
			
			
			
			
			if ("commodityTotalRefundAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->commodityTotalRefundAmount);
				
			}
			
			
			
			
			if ("firstCategoryName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->firstCategoryName);
				
			}
			
			
			
			
			if ("secondCategoryName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->secondCategoryName);
				
			}
			
			
			
			
			if ("thirdCategoryName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->thirdCategoryName);
				
			}
			
			
			
			
			if ("brandNameCn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandNameCn);
				
			}
			
			
			
			
			if ("brandNameEn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandNameEn);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->commoditySizeId !== null) {
			
			$xfer += $output->writeFieldBegin('commoditySizeId');
			$xfer += $output->writeString($this->commoditySizeId);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityName !== null) {
			
			$xfer += $output->writeFieldBegin('commodityName');
			$xfer += $output->writeString($this->commodityName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityPictureUrl !== null) {
			
			$xfer += $output->writeFieldBegin('commodityPictureUrl');
			$xfer += $output->writeString($this->commodityPictureUrl);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityPrice !== null) {
			
			$xfer += $output->writeFieldBegin('commodityPrice');
			$xfer += $output->writeString($this->commodityPrice);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityRefundAmount !== null) {
			
			$xfer += $output->writeFieldBegin('commodityRefundAmount');
			$xfer += $output->writeString($this->commodityRefundAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundNum !== null) {
			
			$xfer += $output->writeFieldBegin('refundNum');
			$xfer += $output->writeString($this->refundNum);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityTotalRefundAmount !== null) {
			
			$xfer += $output->writeFieldBegin('commodityTotalRefundAmount');
			$xfer += $output->writeString($this->commodityTotalRefundAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->firstCategoryName !== null) {
			
			$xfer += $output->writeFieldBegin('firstCategoryName');
			$xfer += $output->writeString($this->firstCategoryName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->secondCategoryName !== null) {
			
			$xfer += $output->writeFieldBegin('secondCategoryName');
			$xfer += $output->writeString($this->secondCategoryName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->thirdCategoryName !== null) {
			
			$xfer += $output->writeFieldBegin('thirdCategoryName');
			$xfer += $output->writeString($this->thirdCategoryName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandNameCn !== null) {
			
			$xfer += $output->writeFieldBegin('brandNameCn');
			$xfer += $output->writeString($this->brandNameCn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandNameEn !== null) {
			
			$xfer += $output->writeFieldBegin('brandNameEn');
			$xfer += $output->writeString($this->brandNameEn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>