<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\df;

class QueryOrderDetail {
	
	static $_TSPEC;
	public $orderSn = null;
	public $rootOrderSn = null;
	public $originalOrderSn = null;
	public $outPaySn = null;
	public $actualPaymentAmount = null;
	public $freight = null;
	public $status = null;
	public $parentOrderSn = null;
	public $orderStatus = null;
	public $subChannel = null;
	public $receiveName = null;
	public $receiveTel = null;
	public $receiveAddress = null;
	public $commodityInfoList = null;
	public $outRefundNo = null;
	public $receiveNameEnc = null;
	public $receiveTelEnc = null;
	public $receiveAddressEnc = null;
	public $areaNameEnc = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'orderSn'
			),
			2 => array(
			'var' => 'rootOrderSn'
			),
			3 => array(
			'var' => 'originalOrderSn'
			),
			4 => array(
			'var' => 'outPaySn'
			),
			5 => array(
			'var' => 'actualPaymentAmount'
			),
			6 => array(
			'var' => 'freight'
			),
			7 => array(
			'var' => 'status'
			),
			8 => array(
			'var' => 'parentOrderSn'
			),
			9 => array(
			'var' => 'orderStatus'
			),
			10 => array(
			'var' => 'subChannel'
			),
			11 => array(
			'var' => 'receiveName'
			),
			12 => array(
			'var' => 'receiveTel'
			),
			13 => array(
			'var' => 'receiveAddress'
			),
			14 => array(
			'var' => 'commodityInfoList'
			),
			15 => array(
			'var' => 'outRefundNo'
			),
			16 => array(
			'var' => 'receiveNameEnc'
			),
			17 => array(
			'var' => 'receiveTelEnc'
			),
			18 => array(
			'var' => 'receiveAddressEnc'
			),
			19 => array(
			'var' => 'areaNameEnc'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['rootOrderSn'])){
				
				$this->rootOrderSn = $vals['rootOrderSn'];
			}
			
			
			if (isset($vals['originalOrderSn'])){
				
				$this->originalOrderSn = $vals['originalOrderSn'];
			}
			
			
			if (isset($vals['outPaySn'])){
				
				$this->outPaySn = $vals['outPaySn'];
			}
			
			
			if (isset($vals['actualPaymentAmount'])){
				
				$this->actualPaymentAmount = $vals['actualPaymentAmount'];
			}
			
			
			if (isset($vals['freight'])){
				
				$this->freight = $vals['freight'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
			if (isset($vals['parentOrderSn'])){
				
				$this->parentOrderSn = $vals['parentOrderSn'];
			}
			
			
			if (isset($vals['orderStatus'])){
				
				$this->orderStatus = $vals['orderStatus'];
			}
			
			
			if (isset($vals['subChannel'])){
				
				$this->subChannel = $vals['subChannel'];
			}
			
			
			if (isset($vals['receiveName'])){
				
				$this->receiveName = $vals['receiveName'];
			}
			
			
			if (isset($vals['receiveTel'])){
				
				$this->receiveTel = $vals['receiveTel'];
			}
			
			
			if (isset($vals['receiveAddress'])){
				
				$this->receiveAddress = $vals['receiveAddress'];
			}
			
			
			if (isset($vals['commodityInfoList'])){
				
				$this->commodityInfoList = $vals['commodityInfoList'];
			}
			
			
			if (isset($vals['outRefundNo'])){
				
				$this->outRefundNo = $vals['outRefundNo'];
			}
			
			
			if (isset($vals['receiveNameEnc'])){
				
				$this->receiveNameEnc = $vals['receiveNameEnc'];
			}
			
			
			if (isset($vals['receiveTelEnc'])){
				
				$this->receiveTelEnc = $vals['receiveTelEnc'];
			}
			
			
			if (isset($vals['receiveAddressEnc'])){
				
				$this->receiveAddressEnc = $vals['receiveAddressEnc'];
			}
			
			
			if (isset($vals['areaNameEnc'])){
				
				$this->areaNameEnc = $vals['areaNameEnc'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'QueryOrderDetail';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("rootOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->rootOrderSn);
				
			}
			
			
			
			
			if ("originalOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->originalOrderSn);
				
			}
			
			
			
			
			if ("outPaySn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outPaySn);
				
			}
			
			
			
			
			if ("actualPaymentAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->actualPaymentAmount);
				
			}
			
			
			
			
			if ("freight" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->freight);
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->status); 
				
			}
			
			
			
			
			if ("parentOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->parentOrderSn);
				
			}
			
			
			
			
			if ("orderStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderStatus); 
				
			}
			
			
			
			
			if ("subChannel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->subChannel);
				
			}
			
			
			
			
			if ("receiveName" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveName);
				
			}
			
			
			
			
			if ("receiveTel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveTel);
				
			}
			
			
			
			
			if ("receiveAddress" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveAddress);
				
			}
			
			
			
			
			if ("commodityInfoList" == $schemeField){
				
				$needSkip = false;
				
				$this->commodityInfoList = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cic\service\df\CommodityInfo();
						$elem0->read($input);
						
						$this->commodityInfoList[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("outRefundNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outRefundNo);
				
			}
			
			
			
			
			if ("receiveNameEnc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveNameEnc);
				
			}
			
			
			
			
			if ("receiveTelEnc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveTelEnc);
				
			}
			
			
			
			
			if ("receiveAddressEnc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->receiveAddressEnc);
				
			}
			
			
			
			
			if ("areaNameEnc" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->areaNameEnc);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->rootOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('rootOrderSn');
			$xfer += $output->writeString($this->rootOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->originalOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('originalOrderSn');
			$xfer += $output->writeString($this->originalOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->outPaySn !== null) {
			
			$xfer += $output->writeFieldBegin('outPaySn');
			$xfer += $output->writeString($this->outPaySn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->actualPaymentAmount !== null) {
			
			$xfer += $output->writeFieldBegin('actualPaymentAmount');
			$xfer += $output->writeString($this->actualPaymentAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->freight !== null) {
			
			$xfer += $output->writeFieldBegin('freight');
			$xfer += $output->writeString($this->freight);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeI32($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->parentOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('parentOrderSn');
			$xfer += $output->writeString($this->parentOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderStatus !== null) {
			
			$xfer += $output->writeFieldBegin('orderStatus');
			$xfer += $output->writeI32($this->orderStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->subChannel !== null) {
			
			$xfer += $output->writeFieldBegin('subChannel');
			$xfer += $output->writeString($this->subChannel);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveName !== null) {
			
			$xfer += $output->writeFieldBegin('receiveName');
			$xfer += $output->writeString($this->receiveName);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveTel !== null) {
			
			$xfer += $output->writeFieldBegin('receiveTel');
			$xfer += $output->writeString($this->receiveTel);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveAddress !== null) {
			
			$xfer += $output->writeFieldBegin('receiveAddress');
			$xfer += $output->writeString($this->receiveAddress);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->commodityInfoList !== null) {
			
			$xfer += $output->writeFieldBegin('commodityInfoList');
			
			if (!is_array($this->commodityInfoList)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->commodityInfoList as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->outRefundNo !== null) {
			
			$xfer += $output->writeFieldBegin('outRefundNo');
			$xfer += $output->writeString($this->outRefundNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveNameEnc !== null) {
			
			$xfer += $output->writeFieldBegin('receiveNameEnc');
			$xfer += $output->writeString($this->receiveNameEnc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveTelEnc !== null) {
			
			$xfer += $output->writeFieldBegin('receiveTelEnc');
			$xfer += $output->writeString($this->receiveTelEnc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->receiveAddressEnc !== null) {
			
			$xfer += $output->writeFieldBegin('receiveAddressEnc');
			$xfer += $output->writeString($this->receiveAddressEnc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->areaNameEnc !== null) {
			
			$xfer += $output->writeFieldBegin('areaNameEnc');
			$xfer += $output->writeString($this->areaNameEnc);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>