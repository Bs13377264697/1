<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\cic\service\df;

class QueryRefundOrderDetail {
	
	static $_TSPEC;
	public $refundOrderSn = null;
	public $orderSn = null;
	public $outRefundNo = null;
	public $refundAmount = null;
	public $refundStatus = null;
	public $subChannel = null;
	public $afterSaleType = null;
	public $refundCommodityInfoList = null;
	public $freight = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'refundOrderSn'
			),
			2 => array(
			'var' => 'orderSn'
			),
			3 => array(
			'var' => 'outRefundNo'
			),
			4 => array(
			'var' => 'refundAmount'
			),
			5 => array(
			'var' => 'refundStatus'
			),
			6 => array(
			'var' => 'subChannel'
			),
			7 => array(
			'var' => 'afterSaleType'
			),
			8 => array(
			'var' => 'refundCommodityInfoList'
			),
			9 => array(
			'var' => 'freight'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['refundOrderSn'])){
				
				$this->refundOrderSn = $vals['refundOrderSn'];
			}
			
			
			if (isset($vals['orderSn'])){
				
				$this->orderSn = $vals['orderSn'];
			}
			
			
			if (isset($vals['outRefundNo'])){
				
				$this->outRefundNo = $vals['outRefundNo'];
			}
			
			
			if (isset($vals['refundAmount'])){
				
				$this->refundAmount = $vals['refundAmount'];
			}
			
			
			if (isset($vals['refundStatus'])){
				
				$this->refundStatus = $vals['refundStatus'];
			}
			
			
			if (isset($vals['subChannel'])){
				
				$this->subChannel = $vals['subChannel'];
			}
			
			
			if (isset($vals['afterSaleType'])){
				
				$this->afterSaleType = $vals['afterSaleType'];
			}
			
			
			if (isset($vals['refundCommodityInfoList'])){
				
				$this->refundCommodityInfoList = $vals['refundCommodityInfoList'];
			}
			
			
			if (isset($vals['freight'])){
				
				$this->freight = $vals['freight'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'QueryRefundOrderDetail';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("refundOrderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundOrderSn);
				
			}
			
			
			
			
			if ("orderSn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->orderSn);
				
			}
			
			
			
			
			if ("outRefundNo" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->outRefundNo);
				
			}
			
			
			
			
			if ("refundAmount" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refundAmount);
				
			}
			
			
			
			
			if ("refundStatus" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->refundStatus); 
				
			}
			
			
			
			
			if ("subChannel" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->subChannel);
				
			}
			
			
			
			
			if ("afterSaleType" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->afterSaleType); 
				
			}
			
			
			
			
			if ("refundCommodityInfoList" == $schemeField){
				
				$needSkip = false;
				
				$this->refundCommodityInfoList = array();
				$_size0 = 0;
				$input->readListBegin();
				while(true){
					
					try{
						
						$elem0 = null;
						
						$elem0 = new \com\vip\cic\service\df\RefundCommodityInfo();
						$elem0->read($input);
						
						$this->refundCommodityInfoList[$_size0++] = $elem0;
					}
					catch(\Exception $e){
						
						break;
					}
				}
				
				$input->readListEnd();
				
			}
			
			
			
			
			if ("freight" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->freight);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->refundOrderSn !== null) {
			
			$xfer += $output->writeFieldBegin('refundOrderSn');
			$xfer += $output->writeString($this->refundOrderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderSn !== null) {
			
			$xfer += $output->writeFieldBegin('orderSn');
			$xfer += $output->writeString($this->orderSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->outRefundNo !== null) {
			
			$xfer += $output->writeFieldBegin('outRefundNo');
			$xfer += $output->writeString($this->outRefundNo);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundAmount !== null) {
			
			$xfer += $output->writeFieldBegin('refundAmount');
			$xfer += $output->writeString($this->refundAmount);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundStatus !== null) {
			
			$xfer += $output->writeFieldBegin('refundStatus');
			$xfer += $output->writeI32($this->refundStatus);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->subChannel !== null) {
			
			$xfer += $output->writeFieldBegin('subChannel');
			$xfer += $output->writeString($this->subChannel);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->afterSaleType !== null) {
			
			$xfer += $output->writeFieldBegin('afterSaleType');
			$xfer += $output->writeI32($this->afterSaleType);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refundCommodityInfoList !== null) {
			
			$xfer += $output->writeFieldBegin('refundCommodityInfoList');
			
			if (!is_array($this->refundCommodityInfoList)){
				
				throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
			}
			
			$output->writeListBegin();
			foreach ($this->refundCommodityInfoList as $iter0){
				
				
				if (!is_object($iter0)) {
					
					throw new \Osp\Exception\OspException('Bad type in structure.', \Osp\Exception\OspException::INVALID_DATA);
				}
				
				$xfer += $iter0->write($output);
				
			}
			
			$output->writeListEnd();
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->freight !== null) {
			
			$xfer += $output->writeFieldBegin('freight');
			$xfer += $output->writeString($this->freight);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>