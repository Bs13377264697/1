<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\branduser\facade\order;

class SyncOrderResultRequest {
	
	static $_TSPEC;
	public $order_sn = null;
	public $refund_order_sn = null;
	public $order_goods_state = null;
	public $open_id = null;
	public $brand_member_card_id = null;
	public $status = null;
	public $points = null;
	public $reason = null;
	public $brand_identify = null;
	public $isv_identity = null;
	public $timestamp = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'order_sn'
			),
			2 => array(
			'var' => 'refund_order_sn'
			),
			3 => array(
			'var' => 'order_goods_state'
			),
			4 => array(
			'var' => 'open_id'
			),
			5 => array(
			'var' => 'brand_member_card_id'
			),
			6 => array(
			'var' => 'status'
			),
			7 => array(
			'var' => 'points'
			),
			8 => array(
			'var' => 'reason'
			),
			9 => array(
			'var' => 'brand_identify'
			),
			10 => array(
			'var' => 'isv_identity'
			),
			11 => array(
			'var' => 'timestamp'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['order_sn'])){
				
				$this->order_sn = $vals['order_sn'];
			}
			
			
			if (isset($vals['refund_order_sn'])){
				
				$this->refund_order_sn = $vals['refund_order_sn'];
			}
			
			
			if (isset($vals['order_goods_state'])){
				
				$this->order_goods_state = $vals['order_goods_state'];
			}
			
			
			if (isset($vals['open_id'])){
				
				$this->open_id = $vals['open_id'];
			}
			
			
			if (isset($vals['brand_member_card_id'])){
				
				$this->brand_member_card_id = $vals['brand_member_card_id'];
			}
			
			
			if (isset($vals['status'])){
				
				$this->status = $vals['status'];
			}
			
			
			if (isset($vals['points'])){
				
				$this->points = $vals['points'];
			}
			
			
			if (isset($vals['reason'])){
				
				$this->reason = $vals['reason'];
			}
			
			
			if (isset($vals['brand_identify'])){
				
				$this->brand_identify = $vals['brand_identify'];
			}
			
			
			if (isset($vals['isv_identity'])){
				
				$this->isv_identity = $vals['isv_identity'];
			}
			
			
			if (isset($vals['timestamp'])){
				
				$this->timestamp = $vals['timestamp'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'SyncOrderResultRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("order_sn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->order_sn);
				
			}
			
			
			
			
			if ("refund_order_sn" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->refund_order_sn);
				
			}
			
			
			
			
			if ("order_goods_state" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->order_goods_state);
				
			}
			
			
			
			
			if ("open_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->open_id);
				
			}
			
			
			
			
			if ("brand_member_card_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_member_card_id);
				
			}
			
			
			
			
			if ("status" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->status);
				
			}
			
			
			
			
			if ("points" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->points);
				
			}
			
			
			
			
			if ("reason" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->reason);
				
			}
			
			
			
			
			if ("brand_identify" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_identify);
				
			}
			
			
			
			
			if ("isv_identity" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->isv_identity);
				
			}
			
			
			
			
			if ("timestamp" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->timestamp); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->order_sn !== null) {
			
			$xfer += $output->writeFieldBegin('order_sn');
			$xfer += $output->writeString($this->order_sn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->refund_order_sn !== null) {
			
			$xfer += $output->writeFieldBegin('refund_order_sn');
			$xfer += $output->writeString($this->refund_order_sn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->order_goods_state !== null) {
			
			$xfer += $output->writeFieldBegin('order_goods_state');
			$xfer += $output->writeString($this->order_goods_state);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->open_id !== null) {
			
			$xfer += $output->writeFieldBegin('open_id');
			$xfer += $output->writeString($this->open_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brand_member_card_id !== null) {
			
			$xfer += $output->writeFieldBegin('brand_member_card_id');
			$xfer += $output->writeString($this->brand_member_card_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->status !== null) {
			
			$xfer += $output->writeFieldBegin('status');
			$xfer += $output->writeString($this->status);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->points !== null) {
			
			$xfer += $output->writeFieldBegin('points');
			$xfer += $output->writeString($this->points);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->reason !== null) {
			
			$xfer += $output->writeFieldBegin('reason');
			$xfer += $output->writeString($this->reason);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brand_identify !== null) {
			
			$xfer += $output->writeFieldBegin('brand_identify');
			$xfer += $output->writeString($this->brand_identify);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->isv_identity !== null) {
			
			$xfer += $output->writeFieldBegin('isv_identity');
			$xfer += $output->writeString($this->isv_identity);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('timestamp');
		$xfer += $output->writeI64($this->timestamp);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>