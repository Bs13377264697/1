<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\branduser\facade\order;

class OrderNotPullInfoResp {
	
	static $_TSPEC;
	public $brandSn = null;
	public $brandIdentity = null;
	public $lastOrderPullTime = null;
	public $orderNotPullNum = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'brandSn'
			),
			2 => array(
			'var' => 'brandIdentity'
			),
			3 => array(
			'var' => 'lastOrderPullTime'
			),
			4 => array(
			'var' => 'orderNotPullNum'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['brandSn'])){
				
				$this->brandSn = $vals['brandSn'];
			}
			
			
			if (isset($vals['brandIdentity'])){
				
				$this->brandIdentity = $vals['brandIdentity'];
			}
			
			
			if (isset($vals['lastOrderPullTime'])){
				
				$this->lastOrderPullTime = $vals['lastOrderPullTime'];
			}
			
			
			if (isset($vals['orderNotPullNum'])){
				
				$this->orderNotPullNum = $vals['orderNotPullNum'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'OrderNotPullInfoResp';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("brandSn" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->brandSn); 
				
			}
			
			
			
			
			if ("brandIdentity" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brandIdentity);
				
			}
			
			
			
			
			if ("lastOrderPullTime" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->lastOrderPullTime);
				
			}
			
			
			
			
			if ("orderNotPullNum" == $schemeField){
				
				$needSkip = false;
				$input->readI32($this->orderNotPullNum); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->brandSn !== null) {
			
			$xfer += $output->writeFieldBegin('brandSn');
			$xfer += $output->writeI64($this->brandSn);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->brandIdentity !== null) {
			
			$xfer += $output->writeFieldBegin('brandIdentity');
			$xfer += $output->writeString($this->brandIdentity);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->lastOrderPullTime !== null) {
			
			$xfer += $output->writeFieldBegin('lastOrderPullTime');
			$xfer += $output->writeI64($this->lastOrderPullTime);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->orderNotPullNum !== null) {
			
			$xfer += $output->writeFieldBegin('orderNotPullNum');
			$xfer += $output->writeI32($this->orderNotPullNum);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>