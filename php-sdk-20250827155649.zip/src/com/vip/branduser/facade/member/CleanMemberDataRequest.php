<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\branduser\facade\member;

class CleanMemberDataRequest {
	
	static $_TSPEC;
	public $brand_member_card_id = null;
	public $mix_mobile = null;
	public $open_id = null;
	public $brand_identify = null;
	public $operate_type = null;
	public $timestamp = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'brand_member_card_id'
			),
			2 => array(
			'var' => 'mix_mobile'
			),
			3 => array(
			'var' => 'open_id'
			),
			4 => array(
			'var' => 'brand_identify'
			),
			5 => array(
			'var' => 'operate_type'
			),
			6 => array(
			'var' => 'timestamp'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['brand_member_card_id'])){
				
				$this->brand_member_card_id = $vals['brand_member_card_id'];
			}
			
			
			if (isset($vals['mix_mobile'])){
				
				$this->mix_mobile = $vals['mix_mobile'];
			}
			
			
			if (isset($vals['open_id'])){
				
				$this->open_id = $vals['open_id'];
			}
			
			
			if (isset($vals['brand_identify'])){
				
				$this->brand_identify = $vals['brand_identify'];
			}
			
			
			if (isset($vals['operate_type'])){
				
				$this->operate_type = $vals['operate_type'];
			}
			
			
			if (isset($vals['timestamp'])){
				
				$this->timestamp = $vals['timestamp'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'CleanMemberDataRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("brand_member_card_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_member_card_id);
				
			}
			
			
			
			
			if ("mix_mobile" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->mix_mobile);
				
			}
			
			
			
			
			if ("open_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->open_id);
				
			}
			
			
			
			
			if ("brand_identify" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_identify);
				
			}
			
			
			
			
			if ("operate_type" == $schemeField){
				
				$needSkip = false;
				$input->readByte($this->operate_type); 
				
			}
			
			
			
			
			if ("timestamp" == $schemeField){
				
				$needSkip = false;
				$input->readI64($this->timestamp); 
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		if($this->brand_member_card_id !== null) {
			
			$xfer += $output->writeFieldBegin('brand_member_card_id');
			$xfer += $output->writeString($this->brand_member_card_id);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		if($this->mix_mobile !== null) {
			
			$xfer += $output->writeFieldBegin('mix_mobile');
			$xfer += $output->writeString($this->mix_mobile);
			
			$xfer += $output->writeFieldEnd();
		}
		
		
		$xfer += $output->writeFieldBegin('open_id');
		$xfer += $output->writeString($this->open_id);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('brand_identify');
		$xfer += $output->writeString($this->brand_identify);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('operate_type');
		$xfer += $output->writeByte($this->operate_type);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('timestamp');
		$xfer += $output->writeI64($this->timestamp);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>