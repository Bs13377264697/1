<?php


/*
* Copyright (c) 2008-2016 vip.com, All Rights Reserved.
*
* Powered by com.vip.osp.osp-idlc-2.5.11.
*
*/

namespace com\vip\branduser\facade\member;

class ConvertMemberCardRequest {
	
	static $_TSPEC;
	public $open_id = null;
	public $origin_brand_member_card_id = null;
	public $new_brand_member_card_id = null;
	public $brand_identify = null;
	
	public function __construct($vals=null){
		
		if (!isset(self::$_TSPEC)){
			
			self::$_TSPEC = array(
			1 => array(
			'var' => 'open_id'
			),
			2 => array(
			'var' => 'origin_brand_member_card_id'
			),
			3 => array(
			'var' => 'new_brand_member_card_id'
			),
			4 => array(
			'var' => 'brand_identify'
			),
			
			);
			
		}
		
		if (is_array($vals)){
			
			
			if (isset($vals['open_id'])){
				
				$this->open_id = $vals['open_id'];
			}
			
			
			if (isset($vals['origin_brand_member_card_id'])){
				
				$this->origin_brand_member_card_id = $vals['origin_brand_member_card_id'];
			}
			
			
			if (isset($vals['new_brand_member_card_id'])){
				
				$this->new_brand_member_card_id = $vals['new_brand_member_card_id'];
			}
			
			
			if (isset($vals['brand_identify'])){
				
				$this->brand_identify = $vals['brand_identify'];
			}
			
			
		}
		
	}
	
	
	public function getName(){
		
		return 'ConvertMemberCardRequest';
	}
	
	public function read($input){
		
		$input->readStructBegin();
		while(true){
			
			$schemeField = $input->readFieldBegin();
			if ($schemeField == null) break;
			$needSkip = true;
			
			
			if ("open_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->open_id);
				
			}
			
			
			
			
			if ("origin_brand_member_card_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->origin_brand_member_card_id);
				
			}
			
			
			
			
			if ("new_brand_member_card_id" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->new_brand_member_card_id);
				
			}
			
			
			
			
			if ("brand_identify" == $schemeField){
				
				$needSkip = false;
				$input->readString($this->brand_identify);
				
			}
			
			
			
			if($needSkip){
				
				\Osp\Protocol\ProtocolUtil::skip($input);
			}
			
			$input->readFieldEnd();
		}
		
		$input->readStructEnd();
		
		
		
	}
	
	public function write($output){
		
		$xfer = 0;
		$xfer += $output->writeStructBegin();
		
		$xfer += $output->writeFieldBegin('open_id');
		$xfer += $output->writeString($this->open_id);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('origin_brand_member_card_id');
		$xfer += $output->writeString($this->origin_brand_member_card_id);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('new_brand_member_card_id');
		$xfer += $output->writeString($this->new_brand_member_card_id);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldBegin('brand_identify');
		$xfer += $output->writeString($this->brand_identify);
		
		$xfer += $output->writeFieldEnd();
		
		$xfer += $output->writeFieldStop();
		$xfer += $output->writeStructEnd();
		return $xfer;
	}
	
}

?>